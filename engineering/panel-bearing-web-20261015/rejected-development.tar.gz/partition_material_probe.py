from pathlib import Path
import sys,json
R=Path('/home/qian-qi/RAZR-SLIDE-panel-elastic-20261015');O=Path('/tmp/razr-panel-elastic-20261015');sys.path.insert(0,str(R/'integration'));import verify_panel_bearing_web as w
_,before,h=w.n.load('/tmp/razr-thread-validation-20261015/native/manifest.json',w.BODY);_,after,h2=w.n.load(O/'candidate-v3/manifest.json',w.BODY)
a=before['A_BACK_PANEL'];b=after['A_BACK_PANEL'];outside_a=a;outside_b=b;rows=[]
for side,sign in [('L',-1),('R',1)]:
 for i,y in enumerate((14.5,29.6)):
  x=sign*11.6;box=w.v.box((x-1.2,y-1.2,.5),(x+1.2,y+1.2,2.1));p=a.intersect(box);q=b.intersect(box)
  print('LOCAL',side,i,'before',w.v.vol(p),'after',w.v.vol(q),flush=True)
  expected=p
  for key,piece in w.additions().items():
   if key.startswith(f'{side}_{i}_'):expected=expected.fuse(piece).clean()
  eq=w.v.equal(expected,q);print('EQUALITY',eq,flush=True)
  outside_a=outside_a.cut(box).clean();outside_b=outside_b.cut(box).clean();rows.append({'side':side,'index':i,'before_volume':w.v.vol(p),'after_volume':w.v.vol(q),'bidirectional_difference':eq})
print('OUTSIDE',w.v.equal(outside_a,outside_b),flush=True)
report={'local_regions':rows,'original_volume':w.v.vol(a),'new_volume':w.v.vol(b),'outside_old_volume':w.v.vol(outside_a),'outside_new_volume':w.v.vol(outside_b)}
assert abs(sum(x['before_volume'] for x in rows)+report['outside_old_volume']-report['original_volume'])<1e-7
assert abs(sum(x['after_volume'] for x in rows)+report['outside_new_volume']-report['new_volume'])<1e-7
(O/'partition-material-probe.json').write_text(json.dumps(report,indent=2)+'\n');print('PARTITION_PASS',flush=True)
