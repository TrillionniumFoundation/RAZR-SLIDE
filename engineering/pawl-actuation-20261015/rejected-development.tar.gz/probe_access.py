from pathlib import Path
import sys,json
R=Path('/home/qian-qi/RAZR-SLIDE-pawl-actuation-20261015');sys.path.insert(0,str(R/'integration'))
import cam_coupling as c
from verify_cam_coupling import common,vol
p,_,_=c.phone_scene(0.,0.);pawl=c.parent('R_PAWL');p['R_PAWL']=pawl;p['L_PAWL']=c.parent('L_PAWL')
print('PAWL',pawl.BoundingBox().__dict__,flush=True)
for f in pawl.Faces():
 if f.geomType()=='PLANE':
  b=f.BoundingBox();nv=f.normalAt()
  print('FACE',nv.toTuple(),f.Area(),[b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax],flush=True)
hits=[]
for x in (13.9,14.5,16,20,24,28,29.5):
 for y in (16.4,17.,19.,21.,21.7):
  rod=c.cylinder(.3,.15,6.15,x,y)
  joint=common(rod,pawl)
  if joint<1e-7:continue
  bad={k:common(rod,v) for k,v in p.items() if k not in ('A_BACK_PANEL','R_PAWL')}
  bad={k:v for k,v in bad.items() if v>1e-7}
  hits.append({'x':x,'y':y,'joint':joint,'bad':bad});print('ACCESS',hits[-1],flush=True)
Path('/tmp/razr-pawl-actuation-20261015/access-probe.json').write_text(json.dumps(hits,indent=2)+'\n')
