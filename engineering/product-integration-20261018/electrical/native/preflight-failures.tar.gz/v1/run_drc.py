import pcbnew,sys,json
b=pcbnew.LoadBoard(sys.argv[1])
assert b is not None
print(json.dumps({"version":pcbnew.GetBuildVersion(),"tracks":len(list(b.GetTracks())),"footprints":len(list(b.GetFootprints())),"WriteDRCReport_doc":pcbnew.WriteDRCReport.__doc__}))
print("WRITE_RESULT",pcbnew.WriteDRCReport(b,sys.argv[2],pcbnew.EDA_UNITS_MILLIMETRES,True))
