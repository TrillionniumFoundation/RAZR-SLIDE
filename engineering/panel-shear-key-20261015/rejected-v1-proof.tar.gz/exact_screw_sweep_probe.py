from pathlib import Path
import sys,json,math
R=Path('/home/qian-qi/RAZR-SLIDE-panel-shear-20261015');O=Path('/tmp/razr-panel-shear-20261015');sys.path.insert(0,str(R/'integration'))
import verify_panel_shear_key as k
v=k.v


def disk_sweep(radius,x0,x1,y,z0,z1):
    vals=(radius,x0,x1,y,z0,z1)
    if any(type(x) not in (int,float) or not math.isfinite(x) for x in vals) or radius<=0 or x1<x0 or z1<=z0:
        raise ValueError('finite ordered cylinder sweep required')
    a=k.cq.Solid.makeCylinder(radius,z1-z0,k.cq.Vector(x0,y,z0),k.cq.Vector(0,0,1))
    if x0==x1:return v.single(a)
    b=k.cq.Solid.makeCylinder(radius,z1-z0,k.cq.Vector(x1,y,z0),k.cq.Vector(0,0,1))
    return v.single(a.fuse(b).fuse(v.box((x0,y-radius,z0),(x1,y+radius,z1))).clean())


def inverse_screw_sweep(screw,dx):
    if type(dx) not in (int,float) or not math.isfinite(dx):raise ValueError('finite X translation required')
    b=screw.BoundingBox();x=(b.xmin+b.xmax)/2.;y=(b.ymin+b.ymax)/2.
    shank=disk_sweep(.5,x,x,y,.55,3.55);head=disk_sweep(.9,x,x,y,.10,.55)
    expected=v.single(shank.fuse(head).clean());v.equal(screw,expected)
    lo,hi=sorted((x,x-dx))
    return v.single(disk_sweep(.5,lo,hi,y,.55,3.55).fuse(disk_sweep(.9,lo,hi,y,.10,.55)).clean())


if __name__=='__main__':
    _,parts,h=k.w.w.w.load_new(O/'native/manifest.json');parent,prior,old,profiles=k.e.v.parent_native(h)
    slots={s:k.e.native_slot(parts[s+'_TAB']) for s in 'LR'};scene=k.w.scene(parts,parent,prior,old,profiles,slots)
    rows=[]
    for name,screw in scene.items():
        if not name.startswith('FRAME_'):continue
        swept=inverse_screw_sweep(screw,.04);hit=v.common(parts['A_BACK_PANEL'].translate((-.02,0,0)),swept)
        over=v.common(parts['A_BACK_PANEL'].translate((-.06,0,0)),inverse_screw_sweep(screw,.12))
        if hit>v.TOL or over<=v.TOL:raise ValueError('exact inverse proof or overtravel negative failed')
        rows.append({'screw':name,'complete_screw_material_reconstructed':True,'exact_inverse_sweep_common_mm3':hit,'overtravel_0p12mm_common_mm3':over})
        print(rows[-1],flush=True)
    assert len(rows)==4 and all(v.sha(p)==x for p,x in h.items())
    (O/'exact-screw-sweep-probe.json').write_text(json.dumps({'rows':rows,'scope':'exact relative full sweep of the independently matched nominal two-cylinder fastener; neither screw nor panel CAD changed','input_sha256':h},indent=2)+'\n')
