from pathlib import Path
import sys,json,math,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'));import straight_envelope as en;import cam_contact_native as n
from OCP.BRepAdaptor import BRepAdaptor_Surface

def cells(shape,vector):
 en.single(shape);v=n.cq.Vector(vector);out=[('start',shape),('end',shape.translate(v))]
 for i,f in enumerate(shape.Faces()):
  if f.geomType()=='PLANE':
   if f.normalAt().dot(v)>1e-12:out.append((f'plane{i}',en.single(n.cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),v))))
  elif f.geomType()=='CYLINDER':
   a=BRepAdaptor_Surface(f.wrapped);c=a.Cylinder();d=c.Axis().Direction();axis=n.cq.Vector(d.X(),d.Y(),d.Z());p=c.Location();base=n.cq.Vector(p.X(),p.Y(),p.Z()).add(axis.multiply(a.FirstVParameter()))
   sh,_=en.swept_cylinder(base,axis,c.Radius(),a.LastVParameter()-a.FirstVParameter(),v);out.append((f'cylinder{i}',sh))
  else:raise ValueError(f.geomType())
 return out

D=E/'native-inputs/motion';load=lambda k:n.single(n.cq.importers.importStep(str(D/('L_'+k+'.step'))).val());cover=load('OLD_COVER');rows=[]
for name,body,vec in [('PAWL_R_BELOW',load('PARKED_PAWL'),(0,0,-20)),('PAWL_UNPARKED_R_BELOW',load('PAWL'),(0,0,-20))]:
 bad=[]
 for label,cell in cells(body,vec):
  v=n.common(cell,cover)
  if v>1e-7:bad.append({'cell':label,'vol':v})
 row={'name':name,'bad':bad};rows.append(row);print(row,flush=True)
inner=load('ROOT_INNER');slot=n.box('L',-3.16,-2.68,2.98,3.22,-7.25,-6.43);newcover=cover.cut(slot).clean();n.single(newcover);print('INNER_NOTCH_REMOVED',cover.Volume()-newcover.Volume(),flush=True)
bad=[]
for label,cell in cells(inner,(20,0,0)):
 v=n.common(cell,newcover)
 if v>1e-7:bad.append({'cell':label,'vol':v})
rows.append({'name':'INNER_DIRECT_NOTCHED_LOCATOR','bad':bad});print(rows[-1],flush=True)
(E/'locator-and-pawl-probe.json').write_text(json.dumps({'rows':rows,'manufacturing_go':False},indent=2))
n.cq.exporters.export(newcover,str(E/'INNER_LOCATOR_NOTCH_PREFLIGHT.step'))
