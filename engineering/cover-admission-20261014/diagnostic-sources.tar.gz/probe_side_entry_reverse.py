from pathlib import Path
import sys,json,traceback,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'))
import cam_contact_native as n
from straight_envelope import envelope,whole_material
D=E/'native-inputs/motion';out=E/'side-entry-reverse';out.mkdir();load=lambda k:n.single(n.cq.importers.importStep(str(D/('L_'+k+'.step'))).val())
cover=load('OLD_COVER');outer=load('ROOT_OUTER_CONNECTED_ALL_FRAGMENTS');inner=load('ROOT_INNER');pawl=load('PARKED_PAWL');rows=[]
try:
 print('START_FULL_OUTER_E',flush=True);sweep,method=envelope(outer.translate((-20,0,0)),(20,0,0));n.cq.exporters.export(sweep,str(out/'OUTER_POS_E_FULL.step'))
 opened=cover.cut(sweep).clean();leaves,vol=whole_material(opened);cut=whole_material(cover.cut(opened),empty=True)[1]
 report={'parts':len(leaves),'retained_volume_mm3':vol,'removed_mm3':cut,'fragments':[{'vol':x.Volume(),'bounds':n.bounds('L',x)} for x in leaves],'method':method}
 print('COVER_CUT',report,flush=True);n.cq.exporters.export(opened,str(out/'COVER_OUTER_SIDE_ENTRY.brep'))
 if len(leaves)==1:
  print('SINGLE_COVER',flush=True)
  candidates=[('PAWL_E_MINUS',pawl,(20,0,0),{'cover':opened}),('INNER_E_MINUS_BELOW',inner.translate((0,0,-.85)),(20,0,0),{'cover':opened,'pawl':pawl}),('INNER_LIFT',inner.translate((0,0,-.85)),(0,0,.85),{'cover':opened,'pawl':pawl})]
  for name,body,vector,fixed in candidates:
   sw,m=envelope(body,vector);checks={k:n.common(sw,f) for k,f in fixed.items()};rows.append({'stage':name,'checks':checks,'method':m});print(name,checks,flush=True)
  report['preflight_stages']=rows
 (out/'report.json').write_text(json.dumps({'result':report,'manufacturing_go':False},indent=2))
except Exception as exc:
 (out/'failure.json').write_text(json.dumps({'error':str(exc),'traceback':traceback.format_exc(),'manufacturing_go':False},indent=2));raise
