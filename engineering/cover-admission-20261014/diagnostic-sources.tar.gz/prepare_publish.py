from pathlib import Path
import json,gzip,hashlib,tarfile,io,shutil,subprocess,time
E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');base='25a33b90a781f35aa47f15c6b319ac48e18f0b9c'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
for name,code in [('pinned-native-plan',1),('independent-pinned-plan',1),('independent-motion130',0),('closed-locator-negative',1),('independent-closed-negative',1),('final-unit399',0)]:
 status=read(E/'jobs'/name/'exit.json');assert status['exit_code']==code and not status['timed_out'] and status['untruncated'],(name,status)
unit=read(E/'final-unit399/report.json');assert unit['tests_run']==399 and unit['passed'] and unit['source_bytes_unchanged'] and len(unit['suite_results'])==22
for path,h in unit['source_hashes_after'].items():
 if path.endswith('.py'):assert sha(R/path)==h,path
native=read(E/'pinned-native-plan/report.json');ind=read(E/'independent-pinned-plan.json');negative=read(E/'closed-locator-negative/report.json');negind=read(E/'independent-closed-negative.json');motion=read(E/'independent-motion130.json')
assert native['source_bytes_unchanged'] and not native['full_initial_plan_passed'];assert ind['evidence_reproduced_consistently'] and not ind['full_initial_assembly_passed'] and not ind['builder_imported']
assert all(len(r['completed_stages'])==7 and r['first_blocked_stage']=='OUTER_ROOT_CLOSE' for r in native['rows'])
assert all(len(r['completed_stages'])==4 and r['first_blocked_stage']=='INNER_ROOT_SIDE_ENTRY' for r in negative['rows'])
assert negind['evidence_reproduced_consistently'] and motion['pair_count']==130 and motion['positive_pairs']==0
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()==base
assert subprocess.check_output(['git','-C','/home/qian-qi/RAZR-SLIDE-keycover-20261014','rev-parse','HEAD'],text=True).strip()==base
assert not subprocess.check_output(['git','-C','/home/qian-qi/RAZR-SLIDE-keycover-20261014','status','--porcelain'],text=True).strip()
changed=[];checked=0;missing=0
for row in subprocess.check_output(['git','-C',str(R),'ls-tree','-rz',base]).split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t',1);p=p.decode();f=R/p
 if not f.is_file():missing+=1;continue
 b=f.read_bytes();checked+=1
 if hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()!=meta.decode().split()[2]:changed.append(p)
assert changed==['tools/test_suites.json'],changed
P=E/'publish';P.mkdir();index=[]
reports=[('pinned-native-plan/report.json','native/pinned-prefix-plan.json.gz'),('independent-pinned-plan.json','independent/prefix-replay.json.gz'),('closed-locator-negative/report.json','negative/closed-locator-plan.json.gz'),('independent-closed-negative.json','negative/independent-closed-locator.json.gz'),('independent-motion130.json','independent/existing-motion130.json.gz'),('final-unit399/report.json','tests/unit399.json.gz'),('cover-first-preflight.json','diagnostics/cover-first-point-probe.json.gz'),('two-stage-probe.json','diagnostics/two-stage-point-probe.json.gz'),('inner-continuous-precheck.json','diagnostics/two-stage-continuous-rejection.json.gz'),('missed-pose-witnesses.json','diagnostics/actual-between-sample-witnesses.json.gz'),('locator-and-pawl-probe.json','diagnostics/locator-and-pawl.json.gz'),('cell-entry-preflight/report.json','rejected/full-outer-sweep-cover-cut.json.gz'),('native-face-prism-probe.json','rejected/regenerated-face-prism.json.gz'),('first-stateful-plan/report.json','rejected/vertical-clamp-plan.json.gz')]
for src,name in reports:
 b=(E/src).read_bytes();z=gzip.compress(b,mtime=0);p=P/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z)
 index.append({'path':name,'stored_bytes':len(z),'stored_sha256':sha(p),'original_bytes':len(b),'original_sha256':hashlib.sha256(b).hexdigest(),'encoding':'gzip'})
put(P/'raw-receipt-index.json',{'files':index,'exact_original_bytes_preserved':True})
for name in ['BASELINE.json','fixture_revision.json','cell_anchor_revision.json','native_part_source_revision.json','superseded-unit-run.json']:
 shutil.copyfile(E/name,P/name)
for d in sorted((E/'jobs').iterdir()):
 if not (d/'exit.json').exists():continue
 shutil.copytree(d,P/'jobs'/d.name)
for p in (E/'final-unit399').glob('*.log'):shutil.copyfile(p,P/'jobs/final-unit399'/p.name)
for name in ['probe-side-entry.log','probe-side-entry-reverse.log','probe-native-face-prism.log']:
 shutil.copyfile(E/name,P/'jobs'/name)
# Exact project-owned native cells, fixtures and concrete collision witnesses.
files={}
for dirname in ['pinned-native-plan','closed-locator-negative']:
 for f in (E/dirname).glob('*.step'):files[dirname+'/'+f.name]=f
for f in (E/'cell-entry-preflight').glob('*.brep'):files['rejected/'+f.name]=f
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,p in sorted(files.items()):
  b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b))
z=gzip.compress(buf.getvalue(),mtime=0);(P/'native-geometry.tar.gz').write_bytes(z)
put(P/'geometry-manifest.json',{'archive_sha256':sha(P/'native-geometry.tar.gz'),'files':[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(files.items())],'vendor_CAD_included':False,'cell_volumes_must_not_be_summed_as_swept_volume':True})
# Keep diagnostic/rejected source bytes as an archive, not active test modules.
buf=io.BytesIO();scripts=sorted(E.glob('*.py'))
with tarfile.open(fileobj=buf,mode='w') as tar:
 for p in scripts:
  b=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b))
(P/'diagnostic-sources.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0));put(P/'diagnostic-source-manifest.json',{p.name:sha(p) for p in scripts})
completed=[]
for row in native['rows']:
 accepted=[s for s in row['records'] if s['passed']];failed=row['records'][-1];completed.append({'side':row['side'],'accepted_stage_names':row['completed_stages'],'accepted_cell_obstacle_checks':sum(len(s['checks']) for s in accepted),'blocked_stage':row['first_blocked_stage'],'failed_stage_cell_obstacle_checks':len(failed['checks']),'overlapping_positive_cells_not_volume_sum':len(failed['positive_cells']),'last_actual_witness':failed['actual_pose_witnesses'][-1]})
summary={'date_utc':'2026-10-14','base_commit':base,'host':'qian-qi','branch':'work/cover-admission-20261014',
 'operating_geometry_baseline':'integration/keycover_bypass.py (unchanged)',
 'admission_study':'integration/cover_admission_gate.py','native_input_source':'integration/admission_native_inputs.py',
 'scope':'finite native cover-first assembly prefix; not a complete buildable mechanism',
 'unit_tests':{'count':399,'groups':22,'new_tests':30,'passed':True,'source_bytes_unchanged':True,'superseded_run_not_counted':True},
 'assembly_prefix':{'sides':completed,'all_prior_placed_parts_and_finite_fixture_included':True,'first_seven_stages_each_side_passed':True,'full_initial_plan_passed':False,'root_closure_and_downstream_fastening_not_executed_after_failure':True,'exit_code':1},
 'closed_locator_control':{'same_plan_and_fixture':True,'passed_stages_each_side':4,'blocked_stage':'INNER_ROOT_SIDE_ENTRY','exit_code':1,'independent_reproduced':True},
 'cover_locator_change':{'window_eqr_mm':[-3.16,-2.68,2.98,3.22,-7.25,-6.43],'removed_mm3_each_side':.04416,'added_mm3':0.,'each_cover_still_one_positive_solid':True,'external_bounds_unchanged':True,'closed_hole_changed_to_open_side_slot':True,'locator_retention_changed_and_not_qualified':True,'closing_keeper_not_designed':True},
 'fixture':{'native_finite_parts_each_side':2,'base_supports_and_rear_hold_down_fingers':True,'vertical_clamp_interference_rejected_and_retained':True,'real_fixture_built':False,'machine_frame_actuator_holding_force_stability_and_fastening_qualified':False},
 'independent_reimport':{'complete_single_solid_STEPs':ind['whole_positive_single_solid_STEPs'],'prior_phone_parts_compared':46,'same_prefix_and_obstruction_reproduced':True,'no_scene_or_fixture_builder_imported':True,'same_kernel_and_generic_cell_algorithm_not_cross_engine':True},
 'operating_motion_recheck':{'pairs':130,'positive_pairs':0,'only_cover_subtraction':True,'all_other_pinned_parts_unchanged':True,'old_564_184_or_64_506_runs_repeated_this_round':False,'old_results_retained_not_relabelled_new':True},
 'regeneration_limitation':{'generated_root_face_prisms_failed_with_invalid_inner_wires':True,'direct_existing_face_probe_did_not_close_it':True,'pinned_STEP_source_is_byte_verified_not_regenerated_or_healed':True,'regenerated_source_to_assembly_path_qualification_closed':False},
 'rejected_overcut':{'full_outer_sweep_cut_leaves_cover_as_five_solids':True,'all_fragments_retained':True,'not_adopted':True},
 'original_worktree_unchanged':True,'historical_file_bytes_changed':[],'materialized_baseline_git_blobs_checked':checked,'sparse_files_not_rehashed':missing,
 'controlled_phone_cavities_or_OLED_FPC_added':False,'OPEN_continuous_motion_or_complete_electronics_closed':False,'hardware_powered_or_services_restarted':False,'supplier_messages_or_orders':0,
 'candidate_go':False,'fixture_fabrication_go':False,'manufacturing_go':False,
 'next_dependency':'redesign an actually closable outer-root/cover retention interface, including a keeper for the newly opened inner locator; validate closure, screws and fixture release without restarting later stages from invented final poses'}
put(P/'SUMMARY.json',summary)
(P/'README.md').write_text('''# 外盖先定位：装配前段准入研究｜2026-10-14\n\n## 当前结论\n\n当前入装候选在两侧各完成七个连续直线阶段：盖件落到支撑、压头就位、未停放棘爪从下方进入、棘爪停放、内根座侧入、STOP0侧入、STOP1侧入。每一步的所有已放入零件及有限夹具都作为障碍，失败后不得把零件写成已安装。第八步外根座闭合仍失败，整个初始装配计划以退出1保留拒绝，后续紧固和完整夹具退出未执行。\n\n## 实质改动与代价\n\n保留PR5的KEY通道和外盖U形绕接。新的内根座定位口窗口为e=-3.16..-2.68、q=2.98..3.22、r=-7.25..-6.43mm；每侧只移除盖件0.04416mm³，外包络不增、实体仍完整。原闭合定位孔变成侧开槽，其保持/承载边界已改变；关闭后的挡块或压板尚未设计。不得将此改动称为原孔完整不变或已获制造资格。\n\n相同路线和夹具的原闭孔负对照，两侧只通过前四段，随后内根座侧入拒绝；开槽后该段及两个STOP阶段通过。因此不是靠换测试、删除障碍或增加离散采样得到通过。\n\n## 夹具与碰撞检查\n\n每侧加入两个有限CAD实体：底座/支撑柱组件及后置压头组件。初版直立压头在内根座侧入和终位有实际相交，原源文件和失败记录保留；现压头的立柱移至后方，指形横梁避开根座与螺钉包络。它们仍只是几何研究夹具；机架、驱动、夹紧力、保持稳定性、材料和真实紧固未验证，更没有制作或上电。\n\n运动包络由完整端点实体、原生前向平面棱柱和圆柱保守载体组成。各实体单独检查，不依赖全局Boolean融合。它们可能重叠，不能把其体积相加当真实扫掠体积；任一相交实体足以拒绝，所有实体与障碍均不相交才支持所声明名义直线路径。没有把几个姿态的并集当作连续扫掠。\n\n## 保留的实际阻塞\n\n外根座侧向闭合在距终位0.05mm处，左右各与盖件相交约0.02723856mm³；实际双实体STEP与独立复读保留。第八阶段每侧8个相交包络单元存在重叠，不把它们相加报告碰撞总量。按整个外根座横移包络直接削盖件会剩五个实体，全部保留为拒绝候选，没有只挑最大的一块。\n\n## 原生输入与源端限制\n\n本轮也发现，重生成的复杂外根座在构造面棱柱时出现inner wire is not closed；改用直接原生面棱柱也未通过严格拓扑检查。没有把错误当空集。最后的入装证明采用PR5中已独立核验、逐字节绑定的完整STEP零件，不重生成、不修复或过滤其面；只有明确的盖件定位口做减量。源端重新生成对象到该装入证明的闭合仍待解决，不能凭STEP通过宣布源端问题已修好。\n\n## 本轮验证\n\n统一入口最终399项/22组通过，其中新增30项。中途被替代的397项测试运行已停止并保留，不计为最终验证。独立复验读取全部272份单实体STEP，核对46个手机部件与旧版及唯一减量窗口一致，重新构造各阶段包络并复现两侧七段通过/外根座阻断。原闭孔负对照亦独立复现。均为同一CAD内核与通用包络算法，不叫跨引擎或实物证明。\n\n另以旧版已绑定包络和本轮仅减量的盖件重新计算全部130对运行运动检查，结果零正干涉；下向恢复力假设与未知公差保持不变。本轮没有再次运行旧564/184采样或旧64/506检查，不把历史结果写成新实验。\n\n## 复现与下一步\n\n`uv sync --locked` 后，`uv run --locked python -B tools/verify.py` 执行当前单元测试。`integration/cover_admission_gate.py --output NEW_EXTERNAL_DIR` 执行本轮候选，预期退出1且阻断外根座；加`--original-closed-locator`执行原孔负对照。`verify_cover_admission.py`提供不导入零件或夹具生成器的独立复读；`verify_locator_motion.py`重新计算既有130对运动包络。每个入口必须使用新的输出位置。\n\n下一步需要真实可闭合的外根座/盖件保持接口，以及侧开定位口的封闭保持件；完整验证根座闭合、紧固与夹具退出。不应再从假定装好的状态直接跳到后续动作。实际整机内腔、指定OLED/FPC、完整端接/双电池/USB、OPEN连续接触、强度、公差和疲劳仍未闭合。candidate_go、fixture_fabrication_go、manufacturing_go均为false。\n''')
put(P/'SHA256.json',{str(p.relative_to(P)):sha(p) for p in sorted(P.rglob('*')) if p.is_file()})
D=R/'engineering/cover-admission-20261014';assert not D.exists();shutil.copytree(P,D)
(R/'CURRENT_DESIGN.md').write_text('''# 当前研究状态｜盖件先定位的装配前段\n\n本轮证据：`engineering/cover-admission-20261014/SUMMARY.json`及README。\n入装执行器：`integration/cover_admission_gate.py`；原生输入：`integration/admission_native_inputs.py`。\n运行运动基线仍保留`integration/keycover_bypass.py`及PR5原始几何。\n\n两侧各七个装配阶段通过，均包括当时已放入的零件和有限夹具。第八步外根座闭合仍有实际碰撞，计划退出1；后续紧固和完整夹具退出没有执行。侧开定位口每侧移除0.04416mm³，保持/承载边界改变，闭合保持件尚未设计。\n\n399项/22组单元测试通过。独立原生复读复现七段通过与闭合失败；全部130对既有运行包络重新计算仍零相交。旧564/184及64/506本轮未重复，历史结果不冒充本轮。\n\n再生外根座对象构造面棱柱有未闭合线错误；本轮使用已绑定的原始STEP验证入装，没有据此宣布源端再生问题已修复。夹具仅有有限CAD几何，机架/驱动/保持力/材料和实际制作未获资格。\n\n下一步：可闭合外根座/盖件保持接口、侧开定位口保持件、完整紧固和夹具退出；随后公差/载荷与真实整机输入。所有产品、夹具制造、整机制造放行继续为false。\n\n历史：`engineering/keycover-geometry-20261014/`、`engineering/contact-motion-20261014/`、`engineering/stow-installation-closure-20261014/`及`engineering/workplan-execution-20261014/`均保留。\n''')
p=R/'status.json';x=read(p);x['previous_current_execution_summary']=x.get('current_execution_summary');x['current_execution_summary']='engineering/cover-admission-20261014/SUMMARY.json';x['current_unit_tests']={'count':399,'groups':22,'passed':True,'scope':'unit tests only; full assembly remains blocked'};x['current_cover_entry']={'admission_candidate':'integration/cover_admission_gate.py','qualified':False,'passed_prefix_stages_each_side':7,'blocked_stage':'OUTER_ROOT_CLOSE','all_present_parts_and_fixture_checked':True,'side_open_locator_capture_unqualified':True};x['admission_candidate_motion_recheck']={'pairs':130,'positive_pairs':0,'cover_subtraction_only':True,'previous_replays_not_repeated':True};x['latest_engineering_evidence']['cover_admission_prefix']='engineering/cover-admission-20261014';x['previous_current_fresh_verification']=x.get('current_fresh_verification');x['current_fresh_verification']='pending';assert not x['candidate_go'] and not x['manufacturing_go'];p.write_text(json.dumps(x,indent=2)+'\n')
print('READY_TO_COMMIT',json.dumps({'tests':399,'groups':22,'sides_prefix_stages':7,'outer_root_blocked':True,'motion_pairs':130,'manufacturing_go':False}),flush=True)
