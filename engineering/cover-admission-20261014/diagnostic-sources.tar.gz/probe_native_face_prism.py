from pathlib import Path
import sys,json,traceback
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'));import cover_locator_slot as s;import cam_contact_native as n
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
from OCP.gp import gp_Vec
rows=[]
for side in 'LR':
 parts,_=s.scene('STOW',side);root=parts[s.ROOT_NAME];vector=(-20,0,0) if side=='L' else (20,0,0)
 for i,f in enumerate(root.Faces()):
  if f.geomType()!='PLANE' or f.normalAt().dot(n.cq.Vector(vector))<=1e-12:continue
  try:
   old=n.cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),n.cq.Vector(vector));old_cert=n.single(old);old_error=None
  except Exception as exc:old_error=str(exc)
  try:
   maker=BRepPrimAPI_MakePrism(f.wrapped,gp_Vec(*vector),True,True)
   if not maker.IsDone():raise ValueError('direct native prism not completed')
   new=n.single(n.cq.Shape.cast(maker.Shape()));row={'side':side,'face':i,'old_error':old_error,'native_prism_volume_mm3':new.Volume(),'native_face_valid':f.isValid()}
  except Exception as exc:row={'side':side,'face':i,'old_error':old_error,'new_error':str(exc)}
  rows.append(row)
 print(side,'faces',sum(x['side']==side for x in rows),'old_failures',[x for x in rows if x['side']==side and x.get('old_error')],'new_failures',[x for x in rows if x['side']==side and x.get('new_error')],flush=True)
(E/'native-face-prism-probe.json').write_text(json.dumps({'rows':rows,'reference':'Open CASCADE BRepPrimAPI_MakePrism native face -> finite prism','manufacturing_go':False},indent=2))
if any(r.get('new_error') for r in rows):raise SystemExit(1)
