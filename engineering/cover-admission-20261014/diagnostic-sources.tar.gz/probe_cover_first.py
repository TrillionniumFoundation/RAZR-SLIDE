from pathlib import Path
import sys,json,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'))
import cam_contact_native as n
D=E/'native-inputs/motion';side='L';names=['OLD_COVER','ROOT_INNER','ROOT_OUTER_CONNECTED_ALL_FRAGMENTS','PARKED_PAWL','STOP_0','STOP_1','ROOT_JOIN_SCREW_0_M1x3_NOMINAL','ROOT_JOIN_SCREW_1_M1x3_NOMINAL'];p={k:n.single(n.cq.importers.importStep(str(D/(side+'_'+k+'.step'))).val()) for k in names}
print('BOUNDS',{k:n.bounds(side,s) for k,s in p.items()},flush=True)
rows=[]
for moving in names[1:6]:
 for label,vec in [('e+',(-1,0,0)),('e-',(1,0,0)),('q+',(0,-1,0)),('q-',(0,1,0)),('r+',(0,0,1)),('r-',(0,0,-1))]:
  samples=[]
  for distance in [.05,1.,5.,20.]:
   body=p[moving].translate(tuple(distance*x for x in vec));v=n.common(body,p['OLD_COVER']);samples.append({'distance_mm':distance,'common_mm3':v})
  good=all(x['common_mm3']<=1e-7 for x in samples);row={'moving':moving,'direction':label,'vector':vec,'samples':samples,'all_sampled_clear':good};rows.append(row)
  print(moving,label,'CLEAR' if good else [(x['distance_mm'],round(x['common_mm3'],8)) for x in samples if x['common_mm3']>1e-7],flush=True)
 (E/'cover-first-preflight-progress.json').write_text(json.dumps({'rows':rows,'sampled_only':True,'manufacturing_go':False},indent=2))
(E/'cover-first-preflight.json').write_text(json.dumps({'rows':rows,'sampled_only':True,'manufacturing_go':False},indent=2))
