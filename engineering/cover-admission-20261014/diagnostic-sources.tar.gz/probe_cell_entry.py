from pathlib import Path
import sys,json,math,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'));import straight_envelope as en;import cam_contact_native as n
from OCP.BRepAdaptor import BRepAdaptor_Surface

def cells(shape,vector):
 en.single(shape);v=n.cq.Vector(vector);out=[('start',shape),('end',shape.translate(v))]
 for i,f in enumerate(shape.Faces()):
  if f.geomType()=='PLANE':
   if f.normalAt().dot(v)>1e-12:out.append((f'plane{i}',en.single(n.cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),v))))
  elif f.geomType()=='CYLINDER':
   a=BRepAdaptor_Surface(f.wrapped);c=a.Cylinder();d=c.Axis().Direction();axis=n.cq.Vector(d.X(),d.Y(),d.Z());p=c.Location();base=n.cq.Vector(p.X(),p.Y(),p.Z()).add(axis.multiply(a.FirstVParameter()))
   sh,_=en.swept_cylinder(base,axis,c.Radius(),a.LastVParameter()-a.FirstVParameter(),v);out.append((f'cylinder{i}',sh))
  else:raise ValueError(f.geomType())
 return out
D=E/'native-inputs/motion';load=lambda k:n.single(n.cq.importers.importStep(str(D/('L_'+k+'.step'))).val());cover=load('OLD_COVER');outer=load('ROOT_OUTER_CONNECTED_ALL_FRAGMENTS');inner=load('ROOT_INNER');pawl=load('PARKED_PAWL');out=E/'cell-entry-preflight';out.mkdir();data=[]
cs=cells(outer,(-20,0,0));print('CELLS',len(cs),flush=True);opened=cover
for name,body in cs:
 v=n.common(cover,body)
 if v>1e-7:opened=opened.cut(body).clean()
 data.append({'cell':name,'common_before_mm3':v})
leaves,vol=en.whole_material(opened);print('COVER_REMAIN',len(leaves),vol,'REMOVED',cover.Volume()-vol,flush=True);n.cq.exporters.export(opened,str(out/'COVER_ADMISSION_COMPLETE.brep'))
report={'cells':data,'remaining_solids':len(leaves),'remaining_volume_mm3':vol,'removed_cover_mm3':cover.Volume()-vol,'motion_passed':False}
if len(leaves)==1:
 stages=[('PAWL_E_MINUS',pawl,(20,0,0),{'COVER':opened}),('INNER_E_MINUS_BELOW',inner.translate((0,0,-.85)),(20,0,0),{'COVER':opened,'PAWL':pawl}),('INNER_LIFT',inner.translate((0,0,-.85)),(0,0,.85),{'COVER':opened,'PAWL':pawl})]
 checks=[]
 for name,body,vec,fixed in stages:
  cc=cells(body,vec);bad=[]
  for label,cell in cc:
   for part,obstacle in fixed.items():
    v=n.common(cell,obstacle)
    if v>1e-7:bad.append({'cell':label,'fixed':part,'vol':v})
  checks.append({'name':name,'cell_count':len(cc),'bad':bad});print(name,'BAD',bad,flush=True)
 report['stages']=checks
(out/'report.json').write_text(json.dumps(report,indent=2))
