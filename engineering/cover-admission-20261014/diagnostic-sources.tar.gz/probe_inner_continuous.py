from pathlib import Path
import sys,json,math,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'));import straight_envelope as en;import cam_contact_native as n
from OCP.BRepAdaptor import BRepAdaptor_Surface

def cells(shape,vector):
 en.single(shape);v=n.cq.Vector(vector);out=[('start',shape),('end',shape.translate(v))]
 for i,f in enumerate(shape.Faces()):
  if f.geomType()=='PLANE':
   if f.normalAt().dot(v)>1e-12:out.append((f'plane{i}',en.single(n.cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),v))))
  elif f.geomType()=='CYLINDER':
   a=BRepAdaptor_Surface(f.wrapped);c=a.Cylinder();d=c.Axis().Direction();axis=n.cq.Vector(d.X(),d.Y(),d.Z());p=c.Location();base=n.cq.Vector(p.X(),p.Y(),p.Z()).add(axis.multiply(a.FirstVParameter()))
   sh,_=en.swept_cylinder(base,axis,c.Radius(),a.LastVParameter()-a.FirstVParameter(),v);out.append((f'cylinder{i}',sh))
  else:raise ValueError(f.geomType())
 return out

D=E/'native-inputs/motion';rows=[]
for side in 'LR':
 load=lambda k:n.single(n.cq.importers.importStep(str(D/(side+'_'+k+'.step'))).val())
 cover=load('OLD_COVER');inner=load('ROOT_INNER');pawl=load('PARKED_PAWL');toward=(20,0,0) if side=='L' else (-20,0,0)
 stages=[('PAWL_INWARD',pawl,toward,{'COVER':cover}),('INNER_INWARD_BELOW',inner.translate((0,0,-1.)),toward,{'COVER':cover,'PAWL':pawl}),('INNER_UP_TO_LOCATE',inner.translate((0,0,-1.)),(0,0,1.),{'COVER':cover,'PAWL':pawl})]
 for name,body,vec,fixed in stages:
  cc=cells(body,vec);bad=[]
  for label,c in cc:
   for part,obstacle in fixed.items():
    v=n.common(c,obstacle)
    if v>1e-7:bad.append({'cell':label,'part':part,'volume_mm3':v})
  row={'side':side,'stage':name,'cell_count':len(cc),'positive_pairs':bad};rows.append(row);print(row,flush=True)
(E/'inner-continuous-precheck.json').write_text(json.dumps({'rows':rows,'manufacturing_go':False},indent=2))
