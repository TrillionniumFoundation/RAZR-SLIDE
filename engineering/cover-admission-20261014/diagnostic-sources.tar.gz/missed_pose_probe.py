from pathlib import Path
import sys,json,math,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'));import straight_envelope as en;import cam_contact_native as n
from OCP.BRepAdaptor import BRepAdaptor_Surface

def cells(shape,vector):
 en.single(shape);v=n.cq.Vector(vector);out=[('start',shape),('end',shape.translate(v))]
 for i,f in enumerate(shape.Faces()):
  if f.geomType()=='PLANE':
   if f.normalAt().dot(v)>1e-12:out.append((f'plane{i}',en.single(n.cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),v))))
  elif f.geomType()=='CYLINDER':
   a=BRepAdaptor_Surface(f.wrapped);c=a.Cylinder();d=c.Axis().Direction();axis=n.cq.Vector(d.X(),d.Y(),d.Z());p=c.Location();base=n.cq.Vector(p.X(),p.Y(),p.Z()).add(axis.multiply(a.FirstVParameter()))
   sh,_=en.swept_cylinder(base,axis,c.Radius(),a.LastVParameter()-a.FirstVParameter(),v);out.append((f'cylinder{i}',sh))
  else:raise ValueError(f.geomType())
 return out

D=E/'native-inputs/motion';load=lambda k:n.single(n.cq.importers.importStep(str(D/('L_'+k+'.step'))).val());cover=load('OLD_COVER');rows=[]
for name,part,vec in [('PAWL_INWARD',load('PARKED_PAWL'),(20,0,0)),('INNER_INWARD',load('ROOT_INNER').translate((0,0,-1.)),(20,0,0))]:
 for label,cell in cells(part,vec):
  v=n.common(cell,cover)
  if v<=1e-7:continue
  intersection=cell.intersect(cover);bb=n.bounds('L',intersection);index=int(label[5:]);face=part.Faces()[index];norm=face.normalAt();t=(intersection.Center().sub(face.Center())).dot(norm)/n.cq.Vector(vec).dot(norm);moving=part.translate(tuple(t*x for x in vec));actual=n.common(moving,cover)
  row={'part':name,'cell':label,'cell_volume':v,'intersection_eqr':bb,'fraction':t,'distance_mm':t*20,'actual_pose_common_mm3':actual,'face_normal':norm.toTuple(),'face_center':face.Center().toTuple()};rows.append(row);print(row,flush=True)
(E/'missed-pose-witnesses.json').write_text(json.dumps({'rows':rows,'manufacturing_go':False},indent=2))
