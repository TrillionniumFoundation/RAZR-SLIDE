from pathlib import Path
import sys,json,itertools,time
R=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-20261014');E=Path('/home/qian-qi/RAZR-SLIDE-cover-admission-evidence-20261014');sys.path.insert(0,str(R/'integration'));import cam_contact_native as n
D=E/'native-inputs/motion';load=lambda k:n.single(n.cq.importers.importStep(str(D/('L_'+k+'.step'))).val());cover=load('OLD_COVER');inner=load('ROOT_INNER');outer=load('ROOT_OUTER_CONNECTED_ALL_FRAGMENTS');rows=[]
for name,body in [('ROOT_INNER',inner),('ROOT_OUTER',outer)]:
 good=[]
 for vec in itertools.product((-1,0,1),repeat=3):
  if not any(vec):continue
  v=n.common(body.translate(tuple(.05*x for x in vec)),cover)
  rows.append({'moving':name,'initial_vector_mm':[.05*x for x in vec],'volume':v})
  if v<=1e-7:good.append(vec)
 print('INITIAL_CLEAR_VECTORS',name,good,flush=True)
 if name=='ROOT_INNER':
  for drop in [-.85,-1.,-1.2]:
   for vec in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0)]:
    samples=[n.common(body.translate((vec[0]*t,vec[1]*t,drop)),cover) for t in (0,.5,1,3,6,12,20)]
    print('INNER_TWO_STAGE',drop,vec,samples,flush=True)
    rows.append({'moving':name,'drop':drop,'second_vector':vec,'sampled_volumes':samples})
(E/'two-stage-probe.json').write_text(json.dumps({'rows':rows,'diagnostic_only':True,'manufacturing_go':False},indent=2))
