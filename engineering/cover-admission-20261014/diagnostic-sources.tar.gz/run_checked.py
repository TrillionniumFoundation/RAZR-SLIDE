from pathlib import Path
import argparse,subprocess,json,os,signal,time
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('timeout',type=int);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();a.directory.mkdir(parents=True,exist_ok=False);begin=time.monotonic()
with (a.directory/'stdout.log').open('wb') as out,(a.directory/'stderr.log').open('wb') as err:
 proc=subprocess.Popen(a.command,stdout=out,stderr=err,start_new_session=True)
 timed_out=False
 try:code=proc.wait(timeout=a.timeout)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(proc.pid,signal.SIGTERM)
  try:code=proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
(a.directory/'exit.json').write_text(json.dumps({'command':a.command,'exit_code':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-begin,'stdout_bytes':(a.directory/'stdout.log').stat().st_size,'stderr_bytes':(a.directory/'stderr.log').stat().st_size,'untruncated':True},indent=2)+'\n');print('EXIT',code,a.directory,flush=True)
raise SystemExit(code)
