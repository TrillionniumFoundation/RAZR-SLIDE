# Panel probe-only numerical diagnosis — prepared, not yet executed

The previous archive-input run completed all 3,885 response columns in 185.210 seconds, then rejected a genuine full-operator probe because its free-DOF residual was nonfinite or exceeded `1e-7`. The original producer did not record the failing probe index or ratio. The unchanged failure evidence and complete-column candidate are preserved in `../fe_panel_rejection-20261023-v1/quarantine-manifest.json` (SHA256 `6e27b014d034c42c5e45b97b5ed633b34bf234cfa87d6a55420d763340f7f505`). That candidate is **not qualified**.

This new, separately identified adapter reads the same candidate H without changing or copying it. It rebuilds and exactly matches the original ordered C, uses the same complete original K, six original constrained panel coordinates, float64 arithmetic, `MMD_AT_PLUS_A`, `diag_pivot_thresh=0`, and `SymmetricMode=True`. The operator is transported from its exact protected archive; no raw K or Kff file is written.

## Executed preparation

- Ten bounded tests passed, with 512 MiB address-space and 25-second CPU limits. The largest numerical fixture is eight DOFs, and the largest cache has seven response columns.
- Tests include retained initial rejection, a valid residual correction, finite correction and stagnation bounds, explicit nonfinite rejection, the actual original five-action restore interface on a tiny SPD example, unchanged read-only H bytes, and real short-lived child cleanup after injected telemetry failure and interruption.
- Preparation used and rechecked all 43 locked package versions; no production K or H was loaded, no FE factorization ran, and no CAD ran.
- Prepared source manifest SHA256: `e520edc01fd360c19a93dbf42e098771d9545b613d472181570c17cf7af02353`.
- Preparation report SHA256: `e85f0ea7e5c2f837c80f50d464e422accf40e1ab05df9260b6b3358673cd61cb`.

## Proposed actual diagnosis

1. Rehash the original rejection, complete candidate, protected 2,560-column predecessor, original inputs, and every executed source. Check the locked interpreter and all 43 package versions.
2. Read the candidate H to obtain the five exact original `H @ v` vectors, then close its mapping before factorization. No H payload is written.
3. Refactor the identical complete constrained K once. For each of the original five deterministic directions (ones, then four Rademacher vectors from seed 73021), record the initial full-DOF residual numerator, denominator, ratio, finite status, solution SHA, and H-action discrepancy before judging it.
4. When needed, apply at most four corrections `r = b - Kff @ u; u += original_LU.solve(r)`. Stop a rejected probe after two successive steps with less than 0.1% residual improvement. Record every iterate. All five directions are diagnosed even if one is numerically rejected; resource or exceptional failure may interrupt the run.
5. Require the unchanged `1e-7` true residual criterion and `2e-7` H-action criterion. If all five pass, solve and audit the four original panel external loads. Their individual residual checks are at least as strict as the original aggregate external-load norm.
6. Release LU, then call the original `ExactResponseCache.restore(..., probes=5, relative_tolerance=2e-7)` using only the five genuinely solved, full-field, SHA-bound actions. Each replay checks the exact RHS, field bytes, finite values, and original fixed zeros. This callback is not a general solver.
7. Recheck all source/input/candidate hashes and all locked packages after execution. Only a new successful run can qualify the unchanged H as a new linear-response seed. The original rejection and quarantine receipt remain unchanged.

Even success does not qualify a contact QP, unchanged-model restart, mesh/contact convergence, gauge-load admissibility, current EP5 structural performance, or physical hardware.

## Bounds and expected cost

The hard bounds are 600 seconds, 4.25 GiB process address space, shared unreclaimable-memory stop at 6.8 GiB, and 500 MiB nonprivileged available disk throughout. Startup requires 2.9 GiB incremental memory margin and 600 MiB nonprivileged available disk. The lower disk startup requirement is specific to this probe-only run: it does not allocate the 120,745,928-byte H copy required by the previous continuation. Five full fields occupy 13,764,248 bytes; auxiliary data and logs are small. The 500 MiB runtime reserve is unchanged.

Estimated elapsed time is 40–90 seconds, based on the previous same-model factor taking 14.515 seconds, verified archive transport, and at most 45 individual solves for five probes and four loads. The estimate is not an execution result. The supervisor continuously enforces the original hard limits, cleans up its own process group on telemetry/write/interrupt exceptions, and never kills other tasks.

## Exact command, subject to root's heavy-resource slot

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/workspace/scratch/95cd2986fdf2/RAZR-SLIDE/.venv/bin/python -B \
/workspace/scratch/95cd2986fdf2/input_recovery/fe_preflight/supervise_probe_diagnosis.py \
  --quarantine-manifest /workspace/scratch/95cd2986fdf2/input_recovery/fe_panel_rejection-20261023-v1/quarantine-manifest.json \
  --quarantine-sha256 6e27b014d034c42c5e45b97b5ed633b34bf234cfa87d6a55420d763340f7f505 \
  --prepared-manifest /workspace/scratch/95cd2986fdf2/input_recovery/fe_probe_prepared-v1/prepared-source-manifest.json \
  --prepared-sha256 e520edc01fd360c19a93dbf42e098771d9545b613d472181570c17cf7af02353 \
  --attempt-label panel-probe-diagnosis-1
```

For a read-only resource preflight, use a new unique attempt label and append `--preflight-only`; that never starts the worker. Each attempt writes new supervision and output directories beneath `/tmp/razr-fe-20261023`. It must not be started while another agent owns the heavy slot.
