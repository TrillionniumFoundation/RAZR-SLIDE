"""Small real-file provenance tests for the archive-aware partial freezer."""
from __future__ import annotations

import argparse
import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from scipy.sparse import csc_matrix, save_npz

import freeze_partial_response_archive as freeze
from rebuild_l2_only import sha


class PartialArchiveProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='razr-archive-checkpoint-tests-', dir='/tmp')
        self.base = Path(self.temp.name)
        self.output = self.base / 'output'; self.output.mkdir()
        self.work = self.base / 'work'; self.work.mkdir()
        self.worker = self.base / 'bound-worker.py'; self.worker.write_text('# synthetic provenance fixture only\n')
        self.archive = self.base / 'bound-archive'; self.archive.write_bytes(b'synthetic prior verified transport fixture')
        self.loads = self.base / 'loads'; self.loads.write_bytes(b'unchanged load fixture')
        self.raw = self.base / 'K-not-materialized.npz'
        self.partial = self.work / 'H.partial.npy'
        np.save(self.partial, np.array([[2., .25, 0.], [.25, 3., 0.], [.5, .75, 0.]]))
        C = csc_matrix(np.array([[1., 0., 1.], [0., 1., -1.], [0., 0., .5],
                                 [0., 0., .2], [0., 0., 0.], [0., 0., 0.]]))
        save_npz(self.output / 'C.npz', C)
        (self.output / 'points.json').write_text(json.dumps([{'fixture': i} for i in range(3)]))
        member_sha = '1' * 64
        logical = {str(self.raw): member_sha, str(self.loads): sha(self.loads)}
        physical = {str(self.archive): sha(self.archive), str(self.loads): sha(self.loads)}
        transport = {
            'schema': 'razr-exact-sparse-archive-input-v1',
            'archive_path': str(self.archive), 'archive_sha256': sha(self.archive),
            'member_name': 'panel/level-2/K.npz', 'member_sha256': member_sha,
            'member_bytes': 123, 'exact_regular_member_occurrences': 1,
            'logical_raw_path': str(self.raw), 'logical_raw_path_read_by_worker': False,
            'archive_sha256_verified_before_and_after_member_read': True,
        }
        self.progress = {
            'schema': 'razr-new-archive-base-response-progress-v1', 'body': 'panel',
            'completed': False, 'error_type': 'MemoryError',
            'ordered_seed_columns': 3, 'original_vector_dofs': 6,
            'completed_columns': 2, 'C_nnz': C.nnz,
            'private_temporary_directory': str(self.work),
            'source_sha256': {str(self.worker): sha(self.worker)},
            'input_sha256_refers_to_logical_model': True,
            'input_sha256': logical, 'consumed_input_sha256': physical,
            'input_transport': transport, 'linear_solve_residual_max': 1e-9,
        }
        self.progress_path = self.output / 'progress.json'
        self.supervisor_path = self.base / 'supervision.json'
        self.commit_supervision()

    def tearDown(self):
        self.temp.cleanup()

    def commit_supervision(self):
        self.progress_path.write_text(json.dumps(self.progress))
        self.supervisor = {
            'finished': True, 'exit_code': -15, 'output': str(self.output),
            'worker_progress_sha256': sha(self.progress_path),
            'worker_final_progress': copy.deepcopy(self.progress),
            'worker_source': str(self.worker), 'worker_sha256': sha(self.worker),
        }
        self.supervisor_path.write_text(json.dumps(self.supervisor))

    def run_freezer(self):
        with contextlib.redirect_stdout(io.StringIO()):
            freeze.main(argparse.Namespace(supervisor_report=self.supervisor_path))
        return json.loads((self.output / 'partial-linear-response-manifest.json').read_text())

    def test_actual_files_freeze_without_pretending_raw_operator_exists(self):
        record = self.run_freezer()
        self.assertEqual(record['schema'], 'razr-partial-archive-linear-response-v1')
        self.assertEqual(record['completed_columns'], 2)
        self.assertEqual(record['partial_H_sha256'], sha(self.partial))
        self.assertEqual(record['consumed_input_sha256'][str(self.archive)], sha(self.archive))
        self.assertFalse(self.raw.exists())
        self.assertFalse(record['logical_raw_K_path_read_or_materialized_by_worker'])
        self.assertFalse(record['complete_H'])
        self.assertFalse(record['accepted_finite_QP'])

    def test_stale_or_edited_progress_cannot_raise_committed_column_count(self):
        self.progress['completed_columns'] = 3
        self.progress_path.write_text(json.dumps(self.progress))
        with self.assertRaises(AssertionError):
            self.run_freezer()
        self.assertFalse((self.output / 'partial-linear-response-manifest.json').exists())

    def test_complete_columns_survive_atomic_publication_interruption_without_qualification(self):
        self.progress['completed_columns'] = 3
        self.commit_supervision()
        self.partial.rename(self.output / 'H.npy')
        record = self.run_freezer()
        self.assertEqual(record['partial_H_path'], str(self.output / 'H.npy'))
        self.assertTrue(record['publication_interrupted_after_all_columns_committed'])
        self.assertFalse(record['complete_H'])
        self.assertFalse(record['bearing_restart_checkpoint'])

    def test_actual_input_mutation_and_missing_unchanged_load_fail(self):
        self.archive.write_bytes(b'changed after supervised exit')
        with self.assertRaises(AssertionError):
            self.run_freezer()
        self.archive.write_bytes(b'synthetic prior verified transport fixture')
        del self.progress['consumed_input_sha256'][str(self.loads)]
        self.commit_supervision()
        with self.assertRaises(ValueError):
            self.run_freezer()
        self.assertFalse((self.output / 'partial-linear-response-manifest.json').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
