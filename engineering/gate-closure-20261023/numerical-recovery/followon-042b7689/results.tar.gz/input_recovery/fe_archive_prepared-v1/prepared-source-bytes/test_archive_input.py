"""Bounded regressions for exact archive transport, with no large FE work."""
from __future__ import annotations

import hashlib
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

import numpy as np
from scipy.sparse import csc_matrix, save_npz

from archive_input import file_sha256, load_sparse_archive_member, validate_transport_binding


class ArchiveTransportTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='razr-archive-transport-tests-', dir='/tmp')
        self.folder = Path(self.temporary.name)
        self.K = csc_matrix(np.array([[4., -1., 0.], [-1., 3., -.5], [0., -.5, 2.]]))
        self.member = 'panel/level-2/K.npz'
        buffer = io.BytesIO(); save_npz(buffer, self.K, compressed=False)
        self.payload = buffer.getvalue()
        self.member_sha = hashlib.sha256(self.payload).hexdigest()
        self.archive = self.folder / 'operator.tar.xz'

    def tearDown(self):
        self.temporary.cleanup()

    def pack(self, names=None, symlink=False):
        with tarfile.open(self.archive, 'w:xz') as archive:
            for name in names or [self.member]:
                info = tarfile.TarInfo(name)
                if symlink:
                    info.type = tarfile.SYMTYPE; info.linkname = 'other.npz'
                    archive.addfile(info)
                else:
                    info.size = len(self.payload)
                    archive.addfile(info, io.BytesIO(self.payload))

    def load(self, **overrides):
        kwargs = dict(archive_path=self.archive, archive_sha256=file_sha256(self.archive),
                      member_name=self.member, member_sha256=self.member_sha,
                      member_bytes=len(self.payload), logical_raw_path=self.folder / 'not-materialized.npz')
        kwargs.update(overrides)
        return load_sparse_archive_member(**kwargs)

    def test_exact_arrays_survive_closed_buffer_and_only_archive_is_consumed(self):
        self.pack()
        actual, transport = self.load()
        for name in ('data', 'indices', 'indptr'):
            self.assertTrue(np.array_equal(getattr(actual, name), getattr(self.K, name)))
        self.assertTrue(np.array_equal(actual @ np.array([2., -1., 3.]), self.K @ np.array([2., -1., 3.])))
        logical = {transport['logical_raw_path']: self.member_sha, 'unchanged/loads': 'fixed'}
        consumed = {str(self.archive): file_sha256(self.archive), 'unchanged/loads': 'fixed'}
        self.assertTrue(validate_transport_binding(logical, consumed, transport))
        self.assertFalse(transport['logical_raw_path_materialized_at_transport'])
        self.assertTrue(transport['seekable_NPZ_buffer_released_before_return'])
        self.assertEqual(list(self.folder.iterdir()), [self.archive])

    def test_wrong_archive_member_hash_size_missing_duplicate_or_nonregular_fail(self):
        self.pack()
        for bad in ({'archive_sha256': '0' * 64}, {'member_sha256': '0' * 64},
                    {'member_bytes': len(self.payload) - 1}, {'member_name': '../K.npz'}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.load(**bad)
        for names in (['other.npz'], [self.member, self.member]):
            self.pack(names)
            with self.subTest(names=names), self.assertRaises(ValueError):
                self.load()
        self.pack(symlink=True)
        with self.assertRaises(ValueError):
            self.load()

    def test_binding_rejects_different_operator_or_unrelated_missing_input(self):
        self.pack()
        _, transport = self.load()
        raw, archive = transport['logical_raw_path'], transport['archive_path']
        logical = {raw: self.member_sha, 'unchanged/loads': 'fixed'}
        consumed = {archive: transport['archive_sha256'], 'unchanged/loads': 'fixed'}
        for bad_logical, bad_consumed, bad_transport in (
            ({**logical, raw: '0' * 64}, consumed, transport),
            (logical, {archive: transport['archive_sha256']}, transport),
            (logical, {**consumed, raw: self.member_sha}, transport),
            (logical, consumed, {**transport, 'logical_raw_path_read_by_worker': True}),
            (logical, consumed, {**transport, 'exact_regular_member_occurrences': 2}),
        ):
            with self.subTest(case=bad_transport), self.assertRaises(ValueError):
                validate_transport_binding(bad_logical, bad_consumed, bad_transport)


if __name__ == '__main__':
    unittest.main(verbosity=2)
