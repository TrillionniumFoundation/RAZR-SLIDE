"""Run bounded archive/provenance regressions; never load the research K."""
from __future__ import annotations

import argparse
import datetime as dt
import io
import json
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time
import unittest

import test_archive_input
import test_archive_partial_checkpoint
from archive_input import file_sha256
import supervise_response_archive as supervisor

BASE = Path(__file__).resolve().parent
ROOT = supervisor.ROOT
SOURCE_NAMES = ('archive_input.py', 'rebuild_base_response_archive.py',
                'supervise_response_archive.py', 'freeze_partial_response_archive.py',
                'test_archive_input.py', 'test_archive_partial_checkpoint.py',
                'run_archive_preparation.py')
ORIGINAL_NAMES = ('rebuild_base_response_budgeted.py', 'supervise_response_budgeted.py',
                  'freeze_partial_response.py', 'rebuild_base_response_limited.py', 'rebuild_l2_only.py')


def identities():
    paths = [*(BASE / name for name in SOURCE_NAMES + ORIGINAL_NAMES),
             *(ROOT / name for name in ('integration/contact_exchange.py',
                 'integration/contact_patch_audit.py', 'integration/tetra_bubble_refinement.py',
                 'engineering/volume-convergence-20261017/solve_enriched_contact.py',
                 'tools/check_environment.py', 'pyproject.toml', 'uv.lock'))]
    return {str(path): file_sha256(path) for path in paths}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args(argv)
    output = args.output_directory.resolve()
    if output.exists() or output.is_relative_to(ROOT.resolve()):
        raise ValueError('new scratch output outside repository required')
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    before = identities()
    sys.path.insert(0, str(ROOT / 'tools'))
    import check_environment
    environment = check_environment.inspect_environment(ROOT)
    if environment.get('passed') is not True:
        raise ValueError('existing locked environment required for small regressions')
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module)
                               for module in (test_archive_input, test_archive_partial_checkpoint))
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    log = output / 'small-tests.log'; log.write_text(stream.getvalue())
    after = identities()
    cad = any(name == 'cadquery' or name == 'OCP' or name.startswith('OCP.') for name in sys.modules)
    copies = output / 'prepared-source-bytes'; copies.mkdir()
    manifest = []
    for name in SOURCE_NAMES:
        source, target = BASE / name, copies / name
        shutil.copyfile(source, target)
        if file_sha256(target) != before[str(source)]:
            raise ValueError('prepared source changed during archival copy')
        manifest.append({'source': str(source), 'copy': str(target), 'sha256': before[str(source)]})
    source_manifest = output / 'prepared-source-manifest.json'
    source_manifest.write_text(json.dumps(manifest, indent=2) + '\n')
    disk = supervisor.os.statvfs(supervisor.PRIVATE)
    record = {
        'schema': 'razr-archive-response-code-preparation-v1',
        'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'head_at_preparation': subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
        'test_count': result.testsRun, 'failures': [(str(t), detail) for t, detail in result.failures],
        'errors': [(str(t), detail) for t, detail in result.errors],
        'skipped': [(str(t), why) for t, why in result.skipped],
        'passed': result.wasSuccessful() and before == after and not cad and not result.skipped,
        'source_sha256_before': before, 'source_sha256_after': after,
        'sources_unchanged': before == after,
        'locked_environment': environment,
        'prepared_source_manifest': str(source_manifest),
        'prepared_source_manifest_sha256': file_sha256(source_manifest),
        'test_log': str(log), 'test_log_sha256': file_sha256(log),
        'seconds': time.monotonic() - started,
        'peak_RSS_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'CAD_imported': cad, 'research_K_loaded': False, 'factorization_started': False,
        'original_partial_modified': False, 'new_response_columns_computed': 0,
        'resource_observation_only': {
            'f_bavail_bytes': disk.f_bavail * disk.f_frsize, **supervisor.memory()},
        'required_startup_available_disk_bytes': 700 * 2**20,
        'runtime_available_disk_reserve_bytes': 500 * 2**20,
        'calculated_new_payload_and_slack_plus_reserve_bytes': 3885**2 * 8 + 344103 * 5 * 8 + (500 + 32) * 2**20,
        'planned_incremental_memory_reserve_GiB': 2.9,
        'worker_address_space_limit_GiB': 4.25, 'shared_unreclaimable_limit_GiB': 6.8,
        'external_wall_limit_seconds': 600,
        'code_preparation_is_not_resource_or_numerical_pass': True,
        'original_full_five_inverse_probes_passed': False,
        'full_H_completed': False, 'QP_checkpoint': False,
        'current_product_structural_or_physical_qualification': False,
    }
    target = output / 'preparation-report.json'
    target.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: record[key] for key in ('test_count', 'passed', 'seconds', 'peak_RSS_KiB',
          'CAD_imported', 'research_K_loaded', 'factorization_started')}))
    return 0 if record['passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
