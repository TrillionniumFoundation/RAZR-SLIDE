"""Verified in-memory transport for an exact sparse NPZ tar member.

This changes transport only: no extraction is published and no solver is
selected. The returned sparse arrays outlive the closed seekable byte buffer.
"""
from __future__ import annotations

import hashlib
import io
from pathlib import Path, PurePosixPath
import tarfile


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(2**20):
            digest.update(block)
    return digest.hexdigest()


def load_sparse_archive_member(archive_path, archive_sha256, member_name,
                               member_sha256, member_bytes, logical_raw_path):
    """Verify the full archive and exactly one regular member, then load CSC.

    The member size is bounded before reading, hashed during transport, and
    never duplicated with BytesIO.getvalue(). Every archive entry is visited
    so duplicate exact member names fail closed. Whole archive identity is
    rechecked after reading. Peak transport includes one complete NPZ buffer;
    the caller must budget that independently of the later factorization.
    """
    from scipy.sparse import load_npz

    archive_path = Path(archive_path).resolve()
    requested = PurePosixPath(member_name)
    if requested.is_absolute() or '..' in requested.parts or str(requested) != member_name:
        raise ValueError('a normalized relative exact archive member name is required')
    if type(member_bytes) is not int or member_bytes <= 0:
        raise ValueError('a positive exact member byte count is required')
    if not archive_path.is_file() or file_sha256(archive_path) != archive_sha256:
        raise ValueError('whole archive SHA256 differs from the expected input')
    buffer = io.BytesIO()
    try:
        matches = 0
        with tarfile.open(archive_path, mode='r|xz') as archive:
            for entry in archive:
                if entry.name != member_name:
                    continue
                matches += 1
                if matches != 1 or not entry.isfile() or entry.size != member_bytes:
                    raise ValueError('archive member must be unique, regular and exact-sized')
                stream = archive.extractfile(entry)
                digest = hashlib.sha256()
                count = 0
                while block := stream.read(2**20):
                    count += len(block)
                    if count > member_bytes:
                        raise ValueError('archive member exceeded its bound')
                    buffer.write(block)
                    digest.update(block)
                if count != member_bytes or digest.hexdigest() != member_sha256:
                    raise ValueError('archive member bytes differ from the original operator')
        if matches != 1:
            raise ValueError('the exact archive member is absent')
        if file_sha256(archive_path) != archive_sha256:
            raise ValueError('archive changed during its verified member transport')
        buffer.seek(0)
        operator = load_npz(buffer).tocsc()
    finally:
        buffer.close()
    transport = {
        'schema': 'razr-exact-sparse-archive-input-v1',
        'archive_path': str(archive_path), 'archive_sha256': archive_sha256,
        'archive_bytes': archive_path.stat().st_size,
        'archive_sha256_verified_before_and_after_member_read': True,
        'member_name': member_name, 'member_sha256': member_sha256,
        'member_bytes': member_bytes, 'exact_regular_member_occurrences': 1,
        'logical_raw_path': str(Path(logical_raw_path).resolve()),
        'logical_raw_path_read_by_worker': False,
        'logical_raw_path_materialized_at_transport': Path(logical_raw_path).exists(),
        'raw_operator_or_Kff_file_written': False,
        'seekable_NPZ_buffer_released_before_return': True,
    }
    return operator, transport


def validate_transport_binding(logical_inputs, consumed_inputs, transport):
    """Bind the original logical K identity to one actually consumed archive.

    Only one pathname substitution is allowed. All remaining input filenames
    and hashes must be exactly equal; an absent unrelated original file cannot
    be hidden by the transport declaration.
    """
    if transport.get('schema') != 'razr-exact-sparse-archive-input-v1':
        raise ValueError('unsupported archive input transport schema')
    raw = transport['logical_raw_path']
    archive = transport['archive_path']
    if raw == archive or raw not in logical_inputs or archive in logical_inputs:
        raise ValueError('invalid logical-to-physical operator pathname binding')
    if logical_inputs[raw] != transport['member_sha256']:
        raise ValueError('logical original operator SHA is not the transported member SHA')
    expected = {path: value for path, value in logical_inputs.items() if path != raw}
    expected[archive] = transport['archive_sha256']
    if consumed_inputs != expected:
        raise ValueError('actual input mapping changes more than the declared K transport')
    if transport.get('exact_regular_member_occurrences') != 1:
        raise ValueError('a unique exact member is required')
    if transport.get('archive_sha256_verified_before_and_after_member_read') is not True:
        raise ValueError('archive before/after identity checks are required')
    if transport.get('logical_raw_path_read_by_worker') is not False:
        raise ValueError('this adapter does not consume the raw logical pathname')
    if type(transport.get('member_bytes')) is not int or transport['member_bytes'] <= 0:
        raise ValueError('exact operator member byte count missing')
    return True
