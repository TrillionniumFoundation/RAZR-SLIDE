# Low-disk archive-input panel response continuation — prepared, not executed

This version preserves the existing FE model, original fixed DOFs, ordered
3,885-column force map, MMD_AT_PLUS_A ordering and numerical tolerances. It
changes the input transport and removes avoidable duplicate disk payloads.
The previous 2,560-column response and all its failure/resource-stop receipts
remain immutable. The old 100-file numerical delivery is unchanged.

## Exact transport and numerical identity

The protected local panel archive has SHA256
`96c095334540eaf2aa5ccf918bb2dfb451a7fac343881f4748e794e46aa04364`.
Its unique regular member `panel/level-2/K.npz` contains 285,135,469 bytes with
SHA256 `80f6f50243d421a3b0ab9eeff1324db029677b63febeaad1f023bf9609e9f1cb`.
`archive_input.py` verifies the whole archive before/after a complete streaming
read, verifies the exact member size/hash, loads its unchanged sparse arrays
from a seekable memory buffer, then releases that buffer before factorization.
Neither the raw K path nor a mapped Kff file is written.

The logical original K pathname and actual archive pathname are recorded
separately. Exactly one pathname substitution is permitted; every other
logical input must retain its original filename and SHA. The raw panel K
path is currently not materialized. Reporting its logical identity does not
claim that it was consumed as a physical file.

The complete original Kff remains in memory. The worker uses the original
SuperLU MMD parameters and double precision. It copies the protected old
partial into a new private working file, resumes at committed column 2,560,
and checks every new full free-DOF residual. It then checks complete-H
reciprocity and self-energy, solves the original five deterministic complete-K
actions, releases LU, and calls the original `ExactResponseCache.restore`
through a callback restricted to those five exact solved RHS hashes. That
replay callback is not a general solver.

Kff array hashes are checked before factorization and again before release.
Actual consumed inputs and source bytes are rehashed before publication.
Completed H/probe/auxiliary files move by same-filesystem atomic rename,
without a second full-H copy. If publication is interrupted, the new partial
freezer permits a complete-column H.npy only at the exact own work/output
paths, with a unique file, supervisor-bound progress, finite entries and all
input/source hashes. It still does not declare a qualified H or QP checkpoint.

## Resource contract

- Startup: at least **700 MiB `f_bavail`**, never root-reserved free blocks.
- Runtime disk reserve: **500 MiB**.
- New payload/slack/reserve estimate: **692,352,352 bytes**. It includes a
  separate full H working copy, five complete probe fields, 32 MiB slack and
  the unchanged runtime reserve; the protected old partial is not deleted.
- Worker address-space ceiling: **4.25 GiB**.
- Conservative incremental memory reserve: **2.9 GiB**, compared with the
  previously measured in-memory factor peak of about 2.56 GiB RSS.
- Shared unreclaimable-memory stop: **6.8 GiB**.
- External wall limit: **600 seconds**, including time spent inside SuperLU.
- Existing locked runtime only, with BLAS/OpenMP threads set to one before
  interpreter startup. The model is normalized research FE, not current
  product EP5 structural qualification.

At preparation the available disk was 463,982,592 bytes and estimated shared
unreclaimable memory was 4,903,795,544 bytes. Both startup checks would refuse
the worker. These are timestamped observations, not permanent resource facts.
The new code has **not loaded the research K or started a factorization**.

## Executed small regressions and review

`preparation-report.json` binds seven prepared sources before/after, the
unchanged original workers/math/lock files, and the existing locked runtime.
**7/7** bounded actual-file tests passed in 0.106 seconds, with 77,716 KiB peak
RSS and no CAD import. They cover exact sparse-array transport after buffer
release; wrong archive/member hash/size; missing, duplicate or nonregular
members; unrelated missing inputs; supervisor-bound column counts; changed
physical inputs; and complete-column atomic-publication interruption.

Report SHA256:
`b17f758d01938b98710fb925e15d6a9e3108457e671f67d54b59cd096774ddc4`.
Prepared-source manifest SHA256:
`c4d2a89a48253dd73debc4edceead9fd4bae73479ca47cf85041c01f5f74c12a`.
Independent source reviews are preserved at:

- `/workspace/scratch/95cd2986fdf2/ci_audit/fe-archive-continuation-independent-review.json`
- `/workspace/scratch/95cd2986fdf2/ci_audit/fe-archive-freezer-publication-independent-review.json`

These establish code preparation and review, not demonstrated full-size
resource sufficiency, a completed H, contact convergence or physical release.

## Concrete execution after resource coordination

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/workspace/scratch/95cd2986fdf2/RAZR-SLIDE/.venv/bin/python -B \
/workspace/scratch/95cd2986fdf2/input_recovery/fe_preflight/supervise_response_archive.py \
--body panel --attempt-label panel-archive-resume-1 \
--resume-manifest /tmp/razr-fe-20261023/base-response-425/panel/partial-linear-response-manifest.json \
--resume-sha256 e64d3102eff7239a11d1e512c8711c78e4637e2af851fd7efee0aefe2a7a6520
```

Append `--preflight-only` to produce only a startup-capacity receipt. Choose
a new attempt label on each invocation. If an actual worker stops after
committing more columns, use `freeze_partial_response_archive.py
--supervisor-report <that attempt's report.json>` after the worker exits.
No matrix upload is performed by any of these tools.
