"""Tiny numerical and real-child guard regressions; never load production K/H."""
from pathlib import Path
import contextlib
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import types
import unittest
from unittest import mock

import numpy as np
from scipy.sparse import csc_matrix

from probe_refinement import (diagnose_and_refine, action_diagnosis, original_directions,
                              array_sha, MAX_CORRECTIONS)
import supervise_probe_diagnosis as supervisor

ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
sys.path.insert(0, str(ROOT / 'integration'))
from contact_exchange import ExactResponseCache


class ResidualDiagnostics(unittest.TestCase):
    def test_initial_failure_preserved_then_same_operator_correction_passes(self):
        dense = np.diag(np.arange(1., 9.)) + 0.05 * np.ones((8, 8))
        operator = csc_matrix(dense)
        rhs = np.arange(8.) - 2
        calls = []
        records = []

        def solve(value):
            calls.append(value.copy())
            exact = np.linalg.solve(dense, value)
            return exact * 0.9 if len(calls) == 1 else exact

        solution, result = diagnose_and_refine(operator, solve, rhs,
                                              lambda record, field: records.append(dict(record)))
        self.assertTrue(result['accepted'])
        self.assertGreater(records[0]['relative_residual'], 1e-7)
        self.assertLessEqual(records[-1]['relative_residual'], 1e-7)
        self.assertEqual(result['solve_calls'], 2)
        np.testing.assert_allclose(calls[1], rhs - dense @ (0.9 * np.linalg.solve(dense, rhs)), rtol=1e-13, atol=1e-14)
        np.testing.assert_allclose(dense @ solution, rhs, atol=1e-13)
        self.assertEqual(records[0]['denominator'], 5.0)

    def test_stagnation_stops_after_two_unimproved_corrections(self):
        records = []
        solution, result = diagnose_and_refine(csc_matrix(np.eye(3)), lambda rhs: np.zeros(3),
                                              np.ones(3), lambda row, field: records.append(dict(row)))
        self.assertFalse(result['accepted'])
        self.assertEqual(result['reason'], 'two_steps_without_minimum_residual_improvement')
        self.assertEqual(result['correction_solves'], 2)
        self.assertEqual([r['relative_residual'] for r in records], [1., 1., 1.])

    def test_improving_but_inaccurate_solve_still_has_finite_four_correction_limit(self):
        _, result = diagnose_and_refine(csc_matrix(np.eye(2)), lambda rhs: 0.5 * rhs,
                                       np.ones(2), lambda row, field: None)
        self.assertFalse(result['accepted'])
        self.assertEqual(result['correction_solves'], MAX_CORRECTIONS)
        self.assertEqual(result['reason'], 'bounded_correction_limit_reached')
        self.assertEqual(result['final_residual'], 0.5 ** 5)

    def test_nonfinite_initial_solve_is_recordable_and_rejected(self):
        rows = []
        _, result = diagnose_and_refine(csc_matrix(np.eye(2)), lambda rhs: np.full(2, np.inf),
                                       np.ones(2), lambda row, field: rows.append(dict(row)))
        self.assertFalse(result['accepted'])
        self.assertFalse(rows[0]['finite'])
        self.assertIsNone(rows[0]['relative_residual'])
        json.dumps(result, allow_nan=False)
        self.assertEqual(result['solve_calls'], 1)

    def test_action_contract_explicitly_rejects_nan_and_overflow(self):
        for measured in (np.array([np.nan]), np.array([np.inf])):
            result = action_diagnosis(measured, np.ones(1))
            self.assertFalse(result['accepted'])
            self.assertFalse(result['finite'])
            json.dumps(result, allow_nan=False)
        self.assertTrue(action_diagnosis(np.zeros(2), np.zeros(2))['accepted'])
        self.assertFalse(action_diagnosis(np.ones(2), 1.000001 * np.ones(2))['accepted'])

    def test_observer_receives_every_actual_iterate_and_can_record_action(self):
        observed = []
        calls = 0

        def solve(rhs):
            nonlocal calls
            calls += 1
            return rhs * (0.9 if calls == 1 else 1.)

        def observe(row, field):
            row['H_action'] = action_diagnosis(field, np.ones(2))
            observed.append(field.copy())

        _, result = diagnose_and_refine(csc_matrix(np.eye(2)), solve, np.ones(2), observe)
        self.assertEqual(len(observed), 2)
        self.assertFalse(result['iterations'][0]['H_action']['accepted'])
        self.assertTrue(result['iterations'][1]['H_action']['accepted'])


class OriginalCacheReadOnlyContract(unittest.TestCase):
    def test_real_five_action_restore_uses_same_directions_and_unchanged_mmap(self):
        rng = np.random.default_rng(3105)
        A = rng.normal(size=(8, 8))
        K = A.T @ A + np.eye(8)
        C = csc_matrix(rng.normal(size=(8, 7)))
        H = np.asarray(C.T @ np.linalg.solve(K, C.toarray()))
        H = (H + H.T) / 2
        directions = original_directions(7)
        rhs = [np.asarray(C @ v).ravel() for v in directions]
        fields = [np.linalg.solve(K, value) for value in rhs]
        calls = 0

        def replay(value):
            nonlocal calls
            self.assertEqual(array_sha(value), array_sha(rhs[calls]))
            result = fields[calls].copy()
            calls += 1
            return result

        with tempfile.TemporaryDirectory(prefix='razr-probe-tiny-', dir='/tmp') as directory:
            path = Path(directory) / 'H.npy'
            np.save(path, H)
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            readonly = np.load(path, mmap_mode='r', allow_pickle=False)
            self.assertFalse(readonly.flags.writeable)
            identity = {'tiny_test': True, 'not_original_FE': True}
            result = ExactResponseCache(8, replay, identity).restore(C, readonly, identity, probes=5, relative_tolerance=2e-7)
            self.assertEqual(calls, 5)
            self.assertLess(result.largest_relative_error, 1e-12)
            readonly._mmap.close()
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest)


class SupervisorCleanupContract(unittest.TestCase):
    def run_monitor_exception(self, error):
        real_popen = subprocess.Popen
        children = []

        def launch(_command, **kwargs):
            child = real_popen([sys.executable, '-c', 'import time; time.sleep(30)'], **kwargs)
            children.append(child)
            return child

        low_memory = {'estimated_unreclaimable_bytes': 0}
        locked = {'passed': True, 'checked_package_count': 43}
        with tempfile.TemporaryDirectory(prefix='razr-probe-control-test-', dir='/tmp') as directory:
            private = Path(directory)
            manifest = private / 'manifest.json'
            manifest.write_text('{}')
            args = types.SimpleNamespace(attempt_label='injected-exception', prepared_manifest=manifest,
                prepared_sha256=supervisor.sha(manifest), quarantine_manifest=manifest,
                quarantine_sha256=supervisor.sha(manifest), preflight_only=False)
            try:
                with mock.patch.object(supervisor, 'PRIVATE', private), \
                     mock.patch.object(supervisor, 'verify_prepared', return_value={str(supervisor.BASE / 'diagnose_panel_probes.py'): 'mock-test-only'}), \
                     mock.patch.object(supervisor, 'memory', side_effect=[low_memory, error, low_memory]), \
                     mock.patch.object(supervisor, 'available_disk', return_value=2 * 1024**3), \
                     mock.patch.object(supervisor, 'inspect_environment', return_value=locked), \
                     mock.patch.object(supervisor.subprocess, 'Popen', side_effect=launch), \
                     contextlib.redirect_stdout(io.StringIO()):
                    result = supervisor.main(args)
                self.assertNotEqual(result, 0)
                self.assertEqual(len(children), 1)
                self.assertIsNotNone(children[0].poll(), 'real child must not outlive failed supervision')
                receipt = json.loads((private / 'supervision/injected-exception/report.json').read_text())
                self.assertEqual(receipt['resource_stop_reason'], 'supervisor_exception_cleanup')
                self.assertEqual(receipt['supervisor_exception']['type'], type(error).__name__)
            finally:
                for child in children:
                    if child.poll() is None:
                        os.killpg(child.pid, 9)
                        child.wait()

    def test_memory_telemetry_oserror_reaps_real_child(self):
        self.run_monitor_exception(OSError('injected memory telemetry read failure'))

    def test_keyboardinterrupt_reaps_real_child(self):
        self.run_monitor_exception(KeyboardInterrupt('injected interruption'))

    def test_process_exit_race_still_waits(self):
        child = mock.Mock()
        child.pid = 123456789
        child.poll.return_value = None
        child.wait.return_value = -15
        with mock.patch.object(supervisor.os, 'killpg', side_effect=ProcessLookupError):
            self.assertEqual(supervisor.stop_owned_process(child), -15)
        child.wait.assert_called_once_with(timeout=5)


if __name__ == '__main__':
    unittest.main()
