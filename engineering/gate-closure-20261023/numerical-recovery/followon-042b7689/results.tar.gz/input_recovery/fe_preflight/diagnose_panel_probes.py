"""New bounded probe-only diagnosis of a numerically rejected panel candidate.

The immutable candidate H is never copied or changed. The original five
deterministic whole-operator actions are solved against the identical K/D/C;
each initial residual and each same-LU correction is recorded before judging
it. Qualification requires all original residual and cache-restore criteria.
No historical checkpoint, contact QP, convergence, or hardware is qualified.
"""
from pathlib import Path
import argparse
import gc
import gzip
import hashlib
import json
import os
import resource
import sys
import time
import traceback

import numpy as np
import scipy
from scipy.sparse import coo_matrix, csc_matrix, hstack, load_npz
from scipy.sparse.linalg import splu

ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
BASE = Path(__file__).resolve().parent
PRIVATE = Path('/tmp/razr-fe-20261023')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'integration'))
sys.path.insert(0, str(ROOT / 'tools'))
from contact_patch_audit import triangle_coefficients, evaluate
from contact_exchange import ExactResponseCache
from archive_input import load_sparse_archive_member, validate_transport_binding
from probe_refinement import (diagnose_and_refine, action_diagnosis, original_directions,
                              array_sha, MAX_CORRECTIONS)
from quarantine_probe_rejected_candidate import sha, exact
from check_environment import inspect_environment


def write(path, data):
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def free_bytes():
    stat = os.statvfs(PRIVATE)
    return stat.f_bavail * stat.f_frsize


def source_identity(prepared_path, prepared_sha):
    exact(prepared_path, prepared_sha)
    prepared = json.loads(prepared_path.read_text())
    if prepared['schema'] != 'razr-panel-probe-diagnosis-prepared-v1':
        raise ValueError('unexpected prepared source schema')
    sources = prepared['source_sha256']
    for path in (Path(__file__).resolve(), BASE / 'probe_refinement.py',
                 BASE / 'archive_input.py', BASE / 'quarantine_probe_rejected_candidate.py',
                 ROOT / 'tools/check_environment.py', ROOT / 'pyproject.toml', ROOT / 'uv.lock',
                 ROOT / 'integration/contact_exchange.py', ROOT / 'integration/contact_patch_audit.py'):
        if str(path) not in sources:
            raise ValueError('an executed adapter source is missing from its prepared identity')
    for path, value in sources.items():
        exact(path, value)
    return sources


def load_candidate(path, digest):
    exact(path, digest)
    record = json.loads(path.read_text())
    if not (record['schema'] == 'razr-quarantined-full-column-response-candidate-v1'
            and record['status'] == 'numerically_rejected_pending_new_probe_diagnosis'
            and record['body'] == 'panel'
            and record['completed_columns'] == record['required_columns'] == 3885
            and record['original_vector_dofs'] == 344103
            and record['complete_H_qualified'] is False
            and record['accepted_new_base_response_seed'] is False
            and record['partial_resume_manifest'] is False):
        raise ValueError('expected the unchanged rejected full-column panel candidate')
    validate_transport_binding(record['logical_model_inputs_sha256'],
                               record['actual_consumed_inputs_sha256'], record['input_transport'])
    for name in ('candidate_H', 'C', 'points', 'producer_supervisor', 'producer_progress',
                 'producer_log', 'original_prefix_manifest', 'original_prefix_H'):
        item = record[name]
        if Path(item['path']).stat().st_size != item['bytes']:
            raise ValueError('candidate artifact size differs')
        exact(item['path'], item['sha256'])
    supervisor = json.loads(Path(record['producer_supervisor']['path']).read_text())
    progress = json.loads(Path(record['producer_progress']['path']).read_text())
    if not (supervisor['worker_final_progress'] == progress
            and supervisor['worker_progress_sha256'] == record['producer_progress']['sha256']
            and supervisor['finished'] is True and supervisor['exit_code'] == 1
            and supervisor['resource_stop_reason'] is None
            and progress['error_type'] == 'ValueError'
            and progress['error'] == 'five-probe full free-DOF residual exceeded'
            and progress['completed'] is False and progress['completed_columns'] == 3885):
        raise ValueError('original numerical failure evidence differs')
    for path, value in {**record['actual_consumed_inputs_sha256'],
                        **record['producer_source_sha256'], **record['freeze_source_sha256']}.items():
        exact(path, value)
    return record


def original_maps(record):
    """Rebuild the original sparse C from exact seed/mesh data, then byte-match."""
    transport = record['input_transport']
    folder = Path(transport['logical_raw_path']).parent
    inputs = record['logical_model_inputs_sha256']
    for path in (folder / 'loads.npz', folder / 'report.json', folder / 'mesh.npz'):
        exact(path, inputs[str(path)])
    report = json.loads((folder / 'report.json').read_text())
    if not (report['body'] == 'panel' and report['level'] == 2
            and report['E_normalization'] == 1.0 and report['nu'] == 0.3
            and report['original_faces_and_surface_P2_traces_unchanged'] is True
            and report['body_loads_on_added_internal_DOFs'] is False
            and report['K_sha256'] == transport['member_sha256']):
        raise ValueError('original L2 model contract differs')
    for name, key in [('mesh.npz', 'mesh_sha256'), ('loads.npz', 'loads_sha256')]:
        exact(folder / name, report[key])
    seedpath = ROOT / 'engineering/nested-contact-20261017/level-2/case-6/report.json.gz'
    common = ROOT / 'engineering/contact-field-20261015/common-cell-results.json.gz'
    meta = ROOT / 'engineering/contact-field-20261015/coupled-field-audit.json.gz'
    for path in (seedpath, common, meta):
        exact(path, inputs[str(path)])
    seed = json.loads(gzip.decompress(seedpath.read_bytes()))
    points = seed['contact_points']
    if not (seed['case'] == 6 and seed['volume_level'] == 2 and len(points) == 3885
            and points[:4] == [{'kind': 'bolt', 'index': i} for i in range(4)]
            and points == json.loads(Path(record['points']['path']).read_text())):
        raise ValueError('original ordered seed identity differs')
    with np.load(folder / 'loads.npz', allow_pickle=False) as ld:
        fixed, xyz, bolts, rigid, external = (ld[key] for key in ('D', 'xyz', 'C', 'R', 'F'))
    n = xyz.shape[1]
    if n != 344103 or len(fixed) != 6 or external.shape != (n, 4):
        raise ValueError('original panel vector/fixed/external dimensions differ')
    raw = json.loads(gzip.decompress(common.read_bytes()))
    metas = json.loads(gzip.decompress(meta.read_bytes()))['contact_patches']
    byname = {x['patch']: x for x in metas}
    flat = [(byname[group['patch']], cell) for group in raw for cell in group['cells']]
    if len(flat) != 5255:
        raise ValueError('original full common-cell input count differs')
    cells = []
    for descriptor, cell in flat:
        axis = descriptor['normal_axis']
        tan = [i for i in range(3) if i != axis]
        origin = np.asarray(descriptor['origin_tangent_mm'])
        dofs = np.asarray(cell['panel_P2_dofs'], dtype=int)
        coeff = triangle_coefficients(xyz[tan][:, dofs[:3]].T, np.eye(6), origin)
        cells.append((descriptor, dofs, coeff, origin))
    columns = []
    for point in points:
        if point['kind'] == 'bolt':
            columns.append(csc_matrix(bolts[:, point['index'], None]))
            continue
        descriptor, dofs, coeff, origin = cells[point['cell']]
        if point['patch'] != descriptor['patch'] or point['gap'] != descriptor['initial_gap_mm']:
            raise ValueError('original contact point descriptor differs')
        sign = descriptor['normal_sign']
        weights = sign * evaluate(coeff, np.asarray(point['xy'])[None], origin)[0]
        if abs(weights.sum() - sign) >= 2e-9:
            raise ValueError('original P2 force partition differs')
        columns.append(coo_matrix((weights, (dofs, np.zeros(len(dofs), dtype=int))),
                                  shape=(n, 1)).tocsc())
    regenerated = hstack(columns, format='csc')
    regenerated.sum_duplicates(); regenerated.eliminate_zeros(); regenerated.sort_indices()
    saved = load_npz(record['C']['path']).tocsc()
    if regenerated.shape != saved.shape or any(not np.array_equal(getattr(regenerated, key), getattr(saved, key))
                                               for key in ('data', 'indices', 'indptr')):
        raise ValueError('rebuilt original C differs from candidate byte-bound C arrays')
    G = np.asarray(saved.T @ rigid)
    loadG = rigid.T @ external
    return saved, fixed, external, G, loadG, points


def main(args):
    started = time.monotonic()
    if any(os.environ.get(key) != '1' for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')):
        raise ValueError('single-thread BLAS environment must precede interpreter startup')
    output = args.output.resolve()
    if not output.is_relative_to(PRIVATE.resolve()):
        raise ValueError('all numerical output must stay in the private task directory')
    output.mkdir(parents=True, exist_ok=False)
    if free_bytes() < 600 * 1024**2:
        raise RuntimeError('probe-only start requires 600MiB nonprivileged available disk')
    resource.setrlimit(resource.RLIMIT_AS, (int(4.25 * 1024**3),) * 2)
    state = {'schema': 'razr-panel-probe-only-diagnosis-progress-v1', 'body': 'panel',
             'completed': False, 'new_base_response_seed_qualified': False,
             'finite_QP_checkpoint': False, 'historical_checkpoint_restored': False,
             'contact_or_physical_qualification': False, 'probes': [], 'external_loads': [],
             'candidate_H_is_read_only_and_never_copied': True}

    def progress(phase, **extra):
        state.update(phase=phase, seconds=time.monotonic() - started,
                     peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                     available_disk_bytes=free_bytes(), **extra)
        write(output / 'progress.json', state)
        print(json.dumps({'phase': phase, 'seconds': state['seconds'],
                          'probes_recorded': len(state['probes']), 'completed': state['completed']}, allow_nan=False), flush=True)

    def guard():
        if time.monotonic() - started > 555:
            raise TimeoutError('probe-only internal time guard')
        if free_bytes() < 500 * 1024**2:
            raise RuntimeError('500MiB nonprivileged disk reserve reached')

    try:
        sources = source_identity(args.prepared_manifest, args.prepared_sha256)
        environment_before = inspect_environment(ROOT)
        write(output / 'environment-before.json', environment_before)
        if not (environment_before['passed'] is True and environment_before['checked_package_count'] == 43):
            raise ValueError('original locked interpreter and all 43 package versions must match')
        record = load_candidate(args.quarantine_manifest, args.quarantine_sha256)
        progress('quarantine_source_and_input_identity_verified', source_sha256=sources,
                 quarantine_manifest_path=str(args.quarantine_manifest),
                 quarantine_manifest_sha256=args.quarantine_sha256,
                 candidate_H=record['candidate_H'], original_failure=record['failure'],
                 environment_before=environment_before)
        C, fixed, external, G, loadG, points = original_maps(record)
        n, m = C.shape
        directions = original_directions(m)
        H = np.load(record['candidate_H']['path'], mmap_mode='r', allow_pickle=False)
        if H.shape != (m, m) or H.dtype != np.float64:
            raise ValueError('candidate H shape or dtype differs')
        for lo in range(0, m, 128):
            if not np.isfinite(H[lo:min(lo + 128, m), :]).all():
                raise ValueError('candidate H contains a nonfinite entry')
        saved_actions = [np.asarray(H @ direction) for direction in directions]
        if any(not np.isfinite(value).all() for value in saved_actions):
            raise ValueError('candidate H action is not finite')
        H._mmap.close(); del H
        gc.collect()
        transport = record['input_transport']
        guard()
        K, actual_transport = load_sparse_archive_member(
            transport['archive_path'], transport['archive_sha256'], transport['member_name'],
            transport['member_sha256'], transport['member_bytes'], transport['logical_raw_path'])
        if actual_transport != transport:
            raise ValueError('actual original operator transport identity differs')
        validate_transport_binding(record['logical_model_inputs_sha256'],
                                   record['actual_consumed_inputs_sha256'], actual_transport)
        if K.shape != (n, n):
            raise ValueError('original stiffness dimension differs')
        free = np.setdiff1d(np.arange(n), fixed)
        Kff = K[free][:, free].tocsc()
        del K
        gc.collect()
        Cf = C[free].tocsc()
        kff_sha = {key: hashlib.sha256(memoryview(getattr(Kff, key)).cast('B')).hexdigest()
                   for key in ('data', 'indices', 'indptr')}
        progress('same_complete_original_K_factorization_started', free_dofs=len(free), Kff_nnz=Kff.nnz,
                 original_fixed_dofs=len(fixed), ordered_seed_columns=m,
                 derived_original_Kff_arrays_sha256=kff_sha, maximum_corrections=MAX_CORRECTIONS)
        guard()
        factor_start = time.monotonic()
        factor = splu(Kff, permc_spec='MMD_AT_PLUS_A', diag_pivot_thresh=0., options={'SymmetricMode': True})
        factor_seconds = time.monotonic() - factor_start
        factor_nnz = int(factor.nnz)
        progress('same_complete_original_K_factorization_finished', factor_seconds=factor_seconds,
                 factor_nnz=factor_nnz)
        fields_path = output / 'five-full-probe-fields.npy'
        fields = np.lib.format.open_memmap(fields_path, mode='w+', dtype=np.float64, shape=(n, 5))
        fields[:] = np.nan
        fields.flush()
        rhs_hashes = []
        for index, direction in enumerate(directions):
            guard()
            rhs = np.asarray(C @ direction).ravel()
            item = {'index': index, 'direction': 'ones' if index == 0 else f'Rademacher-{index}',
                    'direction_sha256': array_sha(direction), 'full_rhs_sha256': array_sha(rhs),
                    'original_free_rhs_sha256': array_sha(rhs[free]), 'iterations': [], 'accepted': False}
            state['probes'].append(item)
            rhs_hashes.append(item['full_rhs_sha256'])

            def observe(measurement, solution, item=item, index=index):
                measurement['H_action'] = action_diagnosis(np.asarray(Cf.T @ solution).ravel(), saved_actions[index])
                item['iterations'].append(dict(measurement))
                progress('original_probe_residual_and_action_measured', active_probe=index)
                guard()

            solution, diagnosis = diagnose_and_refine(Kff, factor.solve, rhs[free], observe)
            item.update({key: value for key, value in diagnosis.items() if key != 'iterations'})
            item['final_H_action'] = item['iterations'][-1]['H_action']
            item['residual_criterion_accepted'] = diagnosis['accepted']
            item['action_criterion_accepted'] = item['final_H_action']['accepted']
            item['accepted'] = bool(diagnosis['accepted'] and item['final_H_action']['accepted'])
            full = np.zeros(n)
            full[free] = solution
            if not np.array_equal(full[fixed], np.zeros(len(fixed))):
                raise ValueError('original fixed coordinates were not retained')
            fields[:, index] = full
            fields.flush()
            item['full_field_sha256'] = array_sha(full)
            item['original_fixed_displacements_exact_zero'] = True
            progress('original_probe_diagnosis_finished', completed_probe_fields=index + 1)
        del solution, full, rhs
        probes_passed = all(item['accepted'] for item in state['probes']) and len(state['probes']) == 5
        qfree = np.zeros((m, 4))
        if probes_passed:
            for index in range(4):
                guard()
                rhs = external[:, index]
                item = {'index': index, 'full_rhs_sha256': array_sha(rhs), 'iterations': [], 'accepted': False}
                state['external_loads'].append(item)

                def observe_external(measurement, solution, item=item, index=index):
                    item['iterations'].append(dict(measurement))
                    progress('original_external_load_residual_measured', active_external_load=index)
                    guard()

                solution, diagnosis = diagnose_and_refine(Kff, factor.solve, rhs[free], observe_external)
                item.update({key: value for key, value in diagnosis.items() if key != 'iterations'})
                qfree[:, index] = np.asarray(Cf.T @ solution).ravel()
                item['qfree_column_sha256'] = array_sha(qfree[:, index])
                if not np.isfinite(qfree[:, index]).all():
                    item['accepted'] = False
                    item['reason'] = 'nonfinite_original_external_contact_action'
                progress('original_external_load_diagnosis_finished')
            del solution, rhs
        del factor
        gc.collect()
        progress('all_attempted_genuine_actions_finished_LU_released', full_probe_rhs_sha256=rhs_hashes)
        fields.flush()
        fields._mmap.close(); del fields
        if any(hashlib.sha256(memoryview(getattr(Kff, key)).cast('B')).hexdigest() != digest for key, digest in kff_sha.items()):
            raise ValueError('original Kff arrays changed during execution')
        del Kff
        gc.collect()
        qualified_actions = probes_passed and len(state['external_loads']) == 4 and all(item['accepted'] for item in state['external_loads'])
        restore = None
        restore_called = False
        if qualified_actions:
            fields = np.load(fields_path, mmap_mode='r', allow_pickle=False)
            H = np.load(record['candidate_H']['path'], mmap_mode='r', allow_pickle=False)
            calls = 0

            def replay_solved_action(rhs):
                nonlocal calls
                if calls >= 5 or array_sha(rhs) != rhs_hashes[calls]:
                    raise ValueError('callback accepts only the five actually solved SHA-bound original full RHSs')
                value = np.array(fields[:, calls], copy=True)
                if (not np.isfinite(value).all()
                        or not np.array_equal(value[fixed], np.zeros(len(fixed)))
                        or array_sha(value) != state['probes'][calls]['full_field_sha256']):
                    raise ValueError('replayed field differs from the actual SHA-bound solved full field')
                calls += 1
                return value

            identity = {'body': 'panel', 'space': 'original P2 traces with level-2 internal condensation',
                        'constraints': 'original D, no substituted support or gauge',
                        'inputs_sha256': record['actual_consumed_inputs_sha256'],
                        'logical_model_inputs_sha256': record['logical_model_inputs_sha256'],
                        'K_input_transport': transport, 'points_sha256': record['points']['sha256'],
                        'C_sha256': record['C']['sha256'],
                        'new_explicit_solver_adapter': 'same original float64 Kff and MMD LU, at most four residual corrections'}
            guard()
            cache = ExactResponseCache(n, replay_solved_action, identity)
            restore_called = True
            progress('original_ExactResponseCache_restore_started_after_LU_release')
            checked = cache.restore(C, H, identity, probes=5, relative_tolerance=2e-7)
            if calls != 5 or not np.isfinite(checked.largest_relative_error) or checked.largest_relative_error > 2e-7:
                raise ValueError('original restore did not complete exactly five finite verified actions')
            restore = vars(checked)
            del cache
            H._mmap.close(); fields._mmap.close()
            del H, fields
            np.savez(output / 'auxiliary.npz', G=G, qfree=qfree, loadG=loadG,
                     initialgap=np.asarray([point.get('gap', 0.0) for point in points]))
        else:
            identity = None
        # Full before/after binding includes both the rejected candidate and
        # its protected predecessor. It never mutates their status or bytes.
        load_candidate(args.quarantine_manifest, args.quarantine_sha256)
        source_identity(args.prepared_manifest, args.prepared_sha256)
        environment_after = inspect_environment(ROOT)
        write(output / 'environment-after.json', environment_after)
        if not environment_after['passed'] or environment_after != environment_before:
            raise ValueError('locked environment changed during the actual numerical execution')
        guard()
        artifacts = {'H.npy': record['candidate_H'], 'C.npz': record['C'], 'points.json': record['points'],
                     'five-full-probe-fields.npy': {'path': str(fields_path), 'bytes': fields_path.stat().st_size, 'sha256': sha(fields_path)}}
        if qualified_actions:
            path = output / 'auxiliary.npz'
            artifacts['auxiliary.npz'] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        result = {'schema': 'razr-new-panel-probe-only-diagnosis-v1', 'body': 'panel',
                  'diagnostic_completed': True, 'completed': qualified_actions,
                  'new_base_response_seed_qualified': qualified_actions,
                  'status': 'new_probe_qualified_linear_seed' if qualified_actions else 'numerical_criteria_rejected',
                  'candidate_quarantine_manifest_sha256': args.quarantine_sha256,
                  'candidate_status_unchanged': True, 'candidate_H_read_only_not_copied': True,
                  'response_columns_computed_this_invocation': 0,
                  'original_vector_dofs': n, 'original_fixed_dofs': len(fixed),
                  'ordered_original_seed_columns': m, 'factor_seconds': factor_seconds, 'factor_nnz': factor_nnz,
                  'factorization': {'permc_spec': 'MMD_AT_PLUS_A', 'diag_pivot_thresh': 0.0, 'SymmetricMode': True},
                  'derived_original_Kff_arrays_sha256': kff_sha, 'Kff_arrays_rechecked_unchanged': True,
                  'original_probe_random_seed': 73021, 'full_probe_rhs_sha256': rhs_hashes,
                  'probes': state['probes'], 'external_loads': state['external_loads'],
                  'original_ExactResponseCache_restore_called': restore_called,
                  'original_ExactResponseCache_restore': restore,
                  'identity': identity, 'source_sha256': sources,
                  'environment_before': environment_before, 'environment_after': environment_after,
                  'locked_environment_unchanged': True,
                  'logical_model_inputs_sha256': record['logical_model_inputs_sha256'],
                  'actual_consumed_inputs_sha256': record['actual_consumed_inputs_sha256'],
                  'input_transport': transport, 'artifacts': artifacts,
                  'files_sha256': {name: item['sha256'] for name, item in artifacts.items()},
                  'restore_callback_scope': 'only the five SHA-bound full-K fields genuinely solved before LU release; not a general solver',
                  'auxiliary_convention': 'original panel-only rigid coordinates and panel-only four external loads',
                  'historical_artifact_restored': False, 'new_QP_executed': False, 'finite_QP_checkpoint': False,
                  'contact_or_mesh_convergence_qualified': False, 'hardware_or_EP5_structural_qualification': False,
                  'seconds': time.monotonic() - started,
                  'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  'runtime': {'python': sys.version, 'numpy': np.__version__, 'scipy': scipy.__version__}}
        write(output / 'report.json', result)
        progress('probe_only_diagnosis_completed', completed=qualified_actions, diagnostic_completed=True,
                 new_base_response_seed_qualified=qualified_actions, original_restore=restore,
                 files_sha256=result['files_sha256'])
        return 0 if qualified_actions else 2
    except BaseException as error:
        try:
            environment_after = inspect_environment(ROOT)
            write(output / 'environment-after.json', environment_after)
            state['environment_after_failure'] = environment_after
        except Exception as environment_error:
            state['environment_after_failure_error'] = str(environment_error)
        progress('diagnosis_interrupted_or_failed', completed=False, error_type=type(error).__name__, error=str(error))
        traceback.print_exc()
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quarantine-manifest', type=Path, required=True)
    parser.add_argument('--quarantine-sha256', required=True)
    parser.add_argument('--prepared-manifest', type=Path, required=True)
    parser.add_argument('--prepared-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    raise SystemExit(main(parser.parse_args()))
