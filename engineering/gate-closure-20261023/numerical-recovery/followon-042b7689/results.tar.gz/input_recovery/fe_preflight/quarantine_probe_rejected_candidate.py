"""Preserve the exact rejected panel candidate; never qualify it as a seed.

Read-only numerical inspection is restricted to the already computed H and C.
No stiffness matrix is loaded, factorized, solved, changed, or copied here.
The original partial freezer deliberately rejects this numerical ValueError.
This separate schema records the rejection and cannot be used as its resume
manifest. Any future qualification needs a separately identified real solve.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import sys
import time

import numpy as np
from scipy.sparse import load_npz

from archive_input import validate_transport_binding


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(2**20):
            value.update(block)
    return value.hexdigest()


def exact(path, expected):
    actual = sha(path)
    if actual != expected:
        raise ValueError(f'identity mismatch: {path}')
    return actual


def file_record(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def main(args):
    started = time.monotonic()
    target = args.output.resolve()
    target.mkdir(parents=True, exist_ok=False)
    supervisor_path = args.supervisor.resolve()
    supervisor = json.loads(supervisor_path.read_text())
    output = Path(supervisor['output'])
    progress_path = output / 'progress.json'
    progress = json.loads(progress_path.read_text())
    if not (supervisor['finished'] is True and supervisor['exit_code'] == 1
            and supervisor['resource_stop_reason'] is None
            and supervisor['status'] == 'worker_failed_or_stopped'):
        raise ValueError('this freezer is specific to the observed numerical rejection')
    exact(progress_path, supervisor['worker_progress_sha256'])
    if progress != supervisor['worker_final_progress']:
        raise ValueError('supervised final progress differs')
    if not (progress['schema'] == 'razr-new-archive-base-response-progress-v1'
            and progress['completed'] is False
            and progress['error_type'] == 'ValueError'
            and progress['error'] == 'five-probe full free-DOF residual exceeded'
            and progress['body'] == 'panel'
            and progress['completed_columns'] == progress['ordered_seed_columns'] == 3885):
        raise ValueError('unexpected failure identity or column completion')
    exact(supervisor['worker_source'], supervisor['worker_sha256'])
    if progress['source_sha256'][supervisor['worker_source']] != supervisor['worker_sha256']:
        raise ValueError('worker and its progress source identity differ')
    validate_transport_binding(progress['input_sha256'], progress['consumed_input_sha256'],
                               progress['input_transport'])
    parent_path = args.parent_manifest.resolve()
    exact(parent_path, progress['resumed_manifest_sha256'])
    parent = json.loads(parent_path.read_text())
    if parent['input_sha256'] != progress['input_sha256'] or parent['completed_columns'] != 2560:
        raise ValueError('original protected prefix model identity differs')
    for name in ('progress', 'supervisor_report', 'C', 'points', 'partial_H'):
        exact(parent[name + '_path'], parent[name + '_sha256'])
    verified_sources = {**parent['producer_source_sha256'], **parent['freeze_source_sha256'],
                        **progress['source_sha256']}
    supervisor_source = Path(__file__).parent / 'supervise_response_archive.py'
    exact(supervisor_source, supervisor['supervisor_sha256'])
    verified_sources[str(supervisor_source)] = supervisor['supervisor_sha256']
    for path, expected in {**progress['consumed_input_sha256'], **verified_sources}.items():
        exact(path, expected)
    partial = Path(progress['private_temporary_directory']) / 'H.partial.npy'
    candidate_before = file_record(partial)
    c_before = file_record(output / 'C.npz')
    points_before = file_record(output / 'points.json')
    exact(output / 'C.npz', parent['C_sha256'])
    exact(output / 'points.json', parent['points_sha256'])
    h = np.load(partial, mmap_mode='r', allow_pickle=False)
    if h.shape != (3885, 3885) or h.dtype != np.dtype('float64'):
        raise ValueError('candidate shape or dtype differs')
    scale, asym, finite = 1e-300, 0.0, True
    for lo in range(0, 3885, 128):
        hi = min(lo + 128, 3885)
        block = h[lo:hi, :]
        finite = finite and bool(np.isfinite(block).all())
        scale = max(scale, float(np.max(np.abs(block))))
        asym = max(asym, float(np.max(np.abs(block - h[:, lo:hi].T))))
    diagonal_min = float(np.min(np.diag(h)))
    h._mmap.close()
    del h
    c = load_npz(output / 'C.npz')
    if c.shape != (344103, 3885) or c.nnz != progress['C_nnz'] or not np.isfinite(c.data).all():
        raise ValueError('candidate original force map shape or values differ')
    if len(json.loads((output / 'points.json').read_text())) != 3885:
        raise ValueError('candidate point count differs')
    for record in (candidate_before, c_before, points_before):
        exact(record['path'], record['sha256'])
    with partial.open('rb') as stream:
        os.fsync(stream.fileno())
    evidence = {}
    for name, source in {
        'supervisor-report.json': supervisor_path,
        'worker-progress.json': progress_path,
        'worker.log': supervisor_path.parent / 'worker.log',
        'original-prefix-manifest.json': parent_path,
    }.items():
        destination = target / 'evidence' / name
        destination.parent.mkdir(exist_ok=True)
        shutil.copyfile(source, destination)
        exact(destination, sha(source))
        evidence[name] = {'original': file_record(source), 'copy': file_record(destination)}
    source_copies = {}
    for index, (source, expected) in enumerate(sorted(verified_sources.items())):
        destination = target / 'producer-source-bytes' / f'{index:02d}-{Path(source).name}'
        destination.parent.mkdir(exist_ok=True)
        shutil.copyfile(source, destination)
        exact(destination, expected)
        source_copies[source] = file_record(destination)
    freeze_sources = {str(Path(__file__).resolve()): sha(__file__),
                      str(Path(__file__).parent / 'archive_input.py'): sha(Path(__file__).parent / 'archive_input.py')}
    result = {
        'schema': 'razr-quarantined-full-column-response-candidate-v1',
        'body': 'panel', 'status': 'numerically_rejected_pending_new_probe_diagnosis',
        'completed_columns': 3885, 'required_columns': 3885, 'original_vector_dofs': 344103,
        'candidate_H': candidate_before, 'C': c_before, 'points': points_before,
        'producer_supervisor': file_record(supervisor_path),
        'producer_progress': file_record(progress_path),
        'producer_log': file_record(supervisor_path.parent / 'worker.log'),
        'original_prefix_manifest': file_record(parent_path),
        'original_prefix_H': file_record(parent['partial_H_path']),
        'failure': {'error_type': progress['error_type'], 'message': progress['error'],
                    'resource_stop_reason': None, 'recorded_failed_probe_index': None,
                    'recorded_failed_probe_residual': None,
                    'limitation': 'The executed producer raises before recording the failing probe ratio or index.'},
        'executed_phase': 'all original columns solved; original five-probe full free-DOF residual rejected',
        'original_ExactResponseCache_restore_executed': False,
        'original_probe_criterion': {'free_dof_residual_infinity_ratio_limit': 1e-7,
            'denominator': 'max(max(abs(rhs[original_free_DOFs])), 1.0)'},
        'producer_column_residual_max': progress['linear_solve_residual_max'],
        'readonly_postfailure_candidate_checks': {
            'finite': finite, 'absolute_max': scale, 'symmetry_absolute_max': asym,
            'symmetry_relative_max': asym / scale, 'diagonal_min': diagonal_min,
            'these_are_new_postfailure_checks_not_recorded_original_probe_results': True,
            'H_already_symmetrized_by_failed_producer': True},
        'logical_model_inputs_sha256': progress['input_sha256'],
        'actual_consumed_inputs_sha256': progress['consumed_input_sha256'],
        'input_transport': progress['input_transport'],
        'producer_source_sha256': verified_sources, 'producer_source_copies': source_copies,
        'frozen_evidence': evidence, 'freeze_source_sha256': freeze_sources,
        'file_bytes_unchanged_by_inspection': True, 'candidate_H_copied': False,
        'old_partial_unchanged': True, 'factor_or_solve_executed_by_freezer': False,
        'new_columns_computed_by_failed_producer': 1325,
        'column_solver_and_tolerances_unchanged': True,
        'complete_H_qualified': False, 'accepted_new_base_response_seed': False,
        'partial_resume_manifest': False, 'finite_QP_checkpoint': False,
        'historical_checkpoint_restored': False, 'new_QP_executed': False,
        'contact_or_physical_qualification': False,
        'next_action': 'A separately identified probe-only worker may read this candidate unchanged; qualification requires all five genuine full-K residual checks and the original ExactResponseCache.restore contract at the unchanged tolerances.',
        'seconds': time.monotonic() - started,
    }
    path = target / 'quarantine-manifest.json'
    path.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'manifest': str(path), 'manifest_sha256': sha(path),
                      'candidate_H_sha256': candidate_before['sha256'],
                      'candidate_qualified': False, 'candidate_checks': result['readonly_postfailure_candidate_checks']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--supervisor', type=Path, required=True)
    parser.add_argument('--parent-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    main(parser.parse_args())
