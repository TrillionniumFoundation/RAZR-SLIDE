"""Bounded float64 residual correction, with every measured rejection retained.

This helper changes neither the constrained operator nor its factorization.
The caller supplies the SAME LU.solve for the initial solve and each correction.
It does not certify an FE model, a cache, or a contact/QP solution by itself.
"""
import hashlib
import math

import numpy as np


FREE_RESIDUAL_LIMIT = 1e-7
ACTION_LIMIT = 2e-7
MAX_CORRECTIONS = 4
STAGNANT_STEPS = 2
MIN_RELATIVE_IMPROVEMENT = 1e-3


def array_sha(array):
    return hashlib.sha256(np.asarray(array, dtype=np.float64).tobytes(order='C')).hexdigest()


def original_directions(columns):
    rng = np.random.default_rng(73021)
    return [np.ones(columns)] + [rng.choice([-1., 1.], columns) for _ in range(4)]


def finite_number(value):
    value = float(value)
    return value if math.isfinite(value) else None


def diagnose_and_refine(operator, same_factor_solve, rhs, observe):
    """Return a last iterate plus its explicitly accepted/rejected diagnosis.

    At most four correction solves follow the initial solve. Two consecutive
    steps failing to reduce the residual by 0.1% stop a rejected probe early.
    Each measurement is emitted before its acceptance/rejection is decided.
    The residual is always computed using the full original float64 Kff.
    """
    rhs = np.asarray(rhs, dtype=np.float64)
    if rhs.ndim != 1 or operator.shape != (rhs.size, rhs.size) or not np.isfinite(rhs).all():
        raise ValueError('finite original free-DOF RHS and matching operator required')
    rhs_max = float(np.max(np.abs(rhs)))
    denominator = max(rhs_max, 1.0)
    solution = np.asarray(same_factor_solve(rhs), dtype=np.float64)
    if solution.shape != rhs.shape:
        raise ValueError('factor returned the wrong displacement shape')
    iterations = []
    last_ratio = None
    stagnant = 0
    correction_max = None
    correction_rhs_sha = None
    for iteration in range(MAX_CORRECTIONS + 1):
        with np.errstate(over='ignore', invalid='ignore'):
            residual = rhs - operator @ solution
            numerator = float(np.max(np.abs(residual)))
            solution_max = float(np.max(np.abs(solution)))
            ratio = numerator / denominator
        finite = bool(np.isfinite(solution).all() and np.isfinite(residual).all()
                      and math.isfinite(ratio) and math.isfinite(solution_max))
        record = {
            'iteration': iteration, 'corrections_applied': iteration,
            'residual_infinity_norm': finite_number(numerator),
            'rhs_free_infinity_norm': rhs_max, 'denominator': denominator,
            'relative_residual': finite_number(ratio), 'finite': finite,
            'solution_infinity_norm': finite_number(solution_max),
            'solution_sha256': array_sha(solution),
            'correction_infinity_norm': correction_max,
            'correction_rhs_sha256': correction_rhs_sha,
            'residual_limit': FREE_RESIDUAL_LIMIT,
            'residual_formula': 'rhs_free - original_float64_Kff @ solution_free',
        }
        # The observer may add a measured H-action comparison before writing
        # this same record. It may not change the locally measured criterion.
        observe(record, solution)
        iterations.append(record)
        if not finite:
            reason = 'nonfinite_true_solution_or_full_operator_residual'
            accepted = False
            break
        if ratio <= FREE_RESIDUAL_LIMIT:
            reason = 'original_free_DOF_residual_criterion_passed'
            accepted = True
            break
        if iteration == MAX_CORRECTIONS:
            reason = 'bounded_correction_limit_reached'
            accepted = False
            break
        if last_ratio is not None:
            stagnant = stagnant + 1 if ratio >= last_ratio * (1.0 - MIN_RELATIVE_IMPROVEMENT) else 0
            if stagnant >= STAGNANT_STEPS:
                reason = 'two_steps_without_minimum_residual_improvement'
                accepted = False
                break
        last_ratio = ratio
        correction_rhs_sha = array_sha(residual)
        correction = np.asarray(same_factor_solve(residual), dtype=np.float64)
        if correction.shape != rhs.shape:
            raise ValueError('factor returned the wrong correction shape')
        correction_max = finite_number(np.max(np.abs(correction)))
        with np.errstate(over='ignore', invalid='ignore'):
            solution = solution + correction
    return solution, {
        'accepted': accepted, 'reason': reason, 'iterations': iterations,
        'initial_residual': iterations[0]['relative_residual'],
        'final_residual': iterations[-1]['relative_residual'],
        'correction_solves': iterations[-1]['corrections_applied'],
        'solve_calls': 1 + iterations[-1]['corrections_applied'],
        'unchanged_threshold': FREE_RESIDUAL_LIMIT,
        'maximum_correction_solves': MAX_CORRECTIONS,
    }


def action_diagnosis(measured, saved):
    """Record the original restore norm and explicitly reject nonfinite values."""
    measured = np.asarray(measured, dtype=np.float64)
    saved = np.asarray(saved, dtype=np.float64)
    if measured.shape != saved.shape or measured.ndim != 1:
        raise ValueError('matching action vectors required')
    with np.errstate(over='ignore', invalid='ignore'):
        numerator = float(np.max(np.abs(measured - saved)))
        measured_max = float(np.max(np.abs(measured)))
        saved_max = float(np.max(np.abs(saved)))
        denominator = max(measured_max, saved_max, 1e-300)
        ratio = numerator / denominator
    finite = bool(np.isfinite(measured).all() and np.isfinite(saved).all()
                  and all(math.isfinite(x) for x in (numerator, denominator, ratio)))
    return {
        'finite': finite, 'measured_infinity_norm': finite_number(measured_max),
        'saved_infinity_norm': finite_number(saved_max),
        'difference_infinity_norm': finite_number(numerator),
        'denominator': finite_number(denominator), 'relative_difference': finite_number(ratio),
        'relative_tolerance': ACTION_LIMIT, 'accepted': finite and ratio <= ACTION_LIMIT,
        'measured_sha256': array_sha(measured), 'saved_sha256': array_sha(saved),
    }
