"""Bound one explicitly prepared probe-only panel run, including SuperLU time."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
PRIVATE = Path('/tmp/razr-fe-20261023')
CGROUP = Path('/sys/fs/cgroup')
sys.path.insert(0, str(ROOT / 'tools'))
from check_environment import inspect_environment


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(2**20):
            result.update(block)
    return result.hexdigest()


def memory():
    values = {line.split()[0]: int(line.split()[1]) for line in (CGROUP / 'memory.stat').read_text().splitlines()}
    kernel = max(values.get('kernel', 0) - values.get('slab_reclaimable', 0), 0)
    return {'cgroup_current': int((CGROUP / 'memory.current').read_text()),
            'cgroup_limit': int((CGROUP / 'memory.max').read_text()),
            'anon': values['anon'], 'shmem': values.get('shmem', 0),
            'kernel_excluding_reclaimable_slab': kernel,
            'estimated_unreclaimable_bytes': values['anon'] + values.get('shmem', 0) + kernel + values.get('unevictable', 0)}


def available_disk():
    value = os.statvfs(PRIVATE)
    return value.f_bavail * value.f_frsize


def write(path, value):
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    os.replace(temporary, path)


def verify_prepared(path, expected):
    if sha(path) != expected:
        raise ValueError('prepared manifest SHA differs')
    manifest = json.loads(path.read_text())
    if manifest['schema'] != 'razr-panel-probe-diagnosis-prepared-v1':
        raise ValueError('prepared schema differs')
    paths = manifest['source_sha256']
    for source in (Path(__file__).resolve(), BASE / 'diagnose_panel_probes.py', BASE / 'probe_refinement.py',
                   ROOT / 'tools/check_environment.py', ROOT / 'pyproject.toml', ROOT / 'uv.lock'):
        if str(source) not in paths:
            raise ValueError('the actual controller and worker paths must be bound')
    for source, digest in paths.items():
        if sha(source) != digest:
            raise ValueError('a prepared source changed: ' + source)
    return paths


def stop_owned_process(process):
    """Always reap this controller's own process group, including exit races."""
    if process.poll() is not None:
        return process.wait()
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        return process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return process.wait()


def main(args):
    started = time.monotonic()
    if not args.attempt_label or not all(c.isalnum() or c in '-_' for c in args.attempt_label):
        raise ValueError('simple unique attempt label required')
    sources = verify_prepared(args.prepared_manifest, args.prepared_sha256)
    if sha(args.quarantine_manifest) != args.quarantine_sha256:
        raise ValueError('quarantine manifest identity differs')
    control = PRIVATE / 'supervision' / args.attempt_label
    control.mkdir(parents=True, exist_ok=False)
    output = PRIVATE / 'probe-only' / args.attempt_label
    if output.exists():
        raise ValueError('refusing to reuse an existing worker output')
    limit = int(6.8 * 1024**3)
    increment = int(2.9 * 1024**3)
    snapshot = memory()
    environment_before = inspect_environment(ROOT)
    state = {'schema': 'razr-panel-probe-only-supervisor-v1', 'body': 'panel',
             'worker_source': str(BASE / 'diagnose_panel_probes.py'),
             'worker_sha256': sources[str(BASE / 'diagnose_panel_probes.py')],
             'supervisor_sha256': sha(__file__), 'source_sha256': sources,
             'prepared_manifest_path': str(args.prepared_manifest), 'prepared_manifest_sha256': args.prepared_sha256,
             'quarantine_manifest_path': str(args.quarantine_manifest), 'quarantine_manifest_sha256': args.quarantine_sha256,
             'output': str(output), 'finished': False, 'worker_started': False,
             'address_space_limit_GiB': 4.25, 'wall_time_limit_seconds': 600,
             'cgroup_unreclaimable_stop_bytes': limit, 'initial_incremental_memory_reserve_GiB': 2.9,
             'initial_memory': snapshot, 'initial_nonprivileged_available_disk_bytes': available_disk(),
             'environment_before': environment_before,
             'initial_disk_required_bytes': 600 * 1024**2, 'runtime_disk_reserve_bytes': 500 * 1024**2,
             'disk_budget_uses_nonprivileged_available_blocks': True,
             'H_candidate_copied': False, 'H_candidate_bytes_written': 0,
             'new_full_probe_fields_bytes_including_NPY_header': 344103 * 5 * 8 + 128,
             'disk_plan': 'No H or K/Kff payload written; five full fields 13,764,248B plus small aux/logs; 600MiB startup, 500MiB throughout',
             'numerical_failure_implied_by_resource_stop': False}
    if not (environment_before.get('passed') is True and environment_before.get('checked_package_count') == 43):
        state.update(finished=True, status='not_started_locked_environment_failed')
        write(control / 'report.json', state); print(json.dumps(state)); return 3
    if state['initial_nonprivileged_available_disk_bytes'] < state['initial_disk_required_bytes']:
        state.update(finished=True, status='not_started_insufficient_disk_margin')
        write(control / 'report.json', state); print(json.dumps(state)); return 3
    if snapshot['estimated_unreclaimable_bytes'] + increment > limit:
        state.update(finished=True, status='not_started_insufficient_memory_margin')
        write(control / 'report.json', state); print(json.dumps(state)); return 3
    command = [str(ROOT / '.venv/bin/python'), '-B', str(BASE / 'diagnose_panel_probes.py'),
               '--quarantine-manifest', str(args.quarantine_manifest), '--quarantine-sha256', args.quarantine_sha256,
               '--prepared-manifest', str(args.prepared_manifest), '--prepared-sha256', args.prepared_sha256,
               '--output', str(output)]
    state['command'] = command
    if args.preflight_only:
        state.update(finished=True, preflight_only=True, status='preflight_only_resources_available_worker_not_started')
        write(control / 'report.json', state); print(json.dumps(state)); return 0
    environment = os.environ.copy()
    environment.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    reason = None
    supervision_exception = None
    with (control / 'worker.log').open('wb') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment,
                                   cwd=str(BASE), start_new_session=True)
        state.update(pid=process.pid, worker_started=True)
        maximum = 0
        last_update = -100.0
        try:
            while process.poll() is None:
                seconds = time.monotonic() - started
                current = memory()
                maximum = max(maximum, current['estimated_unreclaimable_bytes'])
                if current['estimated_unreclaimable_bytes'] > limit:
                    reason = 'cgroup_unreclaimable_memory_guard'
                elif seconds > 600:
                    reason = 'wall_time_guard'
                elif available_disk() < 500 * 1024**2:
                    reason = 'disk_reserve_guard'
                if seconds - last_update >= 15 or reason:
                    state.update(seconds=seconds, memory=current, maximum_unreclaimable_bytes=maximum, resource_stop_reason=reason)
                    write(control / 'progress.json', state)
                    print(json.dumps({'seconds': seconds, 'pid': process.pid,
                                      'unreclaimable_bytes': current['estimated_unreclaimable_bytes'], 'stop': reason}), flush=True)
                    last_update = seconds
                if reason:
                    stop_owned_process(process)
                    break
                time.sleep(0.5)
        except BaseException as error:
            supervision_exception = {'type': type(error).__name__, 'message': str(error)}
            reason = 'supervisor_exception_cleanup'
            # Stop first. Disk/memory telemetry or receipt writing can fail;
            # no failure in this controller may leave an unsupervised factor.
            stop_owned_process(process)
        finally:
            if process.poll() is None:
                stop_owned_process(process)
            code = process.wait()
    try:
        final_memory = memory()
    except Exception as error:
        final_memory = {'telemetry_error': type(error).__name__ + ': ' + str(error)}
    state.update(finished=True, exit_code=code, seconds=time.monotonic() - started,
                 final_memory=final_memory, resource_stop_reason=reason,
                 supervisor_exception=supervision_exception,
                 status='worker_completed' if code == 0 else 'worker_numerically_rejected' if code == 2 else 'worker_failed_or_stopped')
    progress = output / 'progress.json'
    if progress.is_file():
        state['worker_progress_sha256'] = sha(progress)
        state['worker_final_progress'] = json.loads(progress.read_text())
    source_guard_error = None
    try:
        verify_prepared(args.prepared_manifest, args.prepared_sha256)
    except Exception as error:
        source_guard_error = str(error)
        state['status'] = 'postflight_source_identity_failed'
    state['source_identity_postflight_error'] = source_guard_error
    environment_after = inspect_environment(ROOT)
    state['environment_after'] = environment_after
    if not environment_after.get('passed') or environment_after != environment_before:
        state['status'] = 'postflight_locked_environment_failed'
        source_guard_error = source_guard_error or 'locked environment changed during supervised execution'
    state['locked_environment_unchanged'] = environment_after == environment_before and environment_after.get('passed') is True
    report = output / 'report.json'
    if report.is_file():
        state['worker_report_sha256'] = sha(report)
    # No zero exit code may qualify without a genuine completed report and
    # both original contracts. This controller never rewrites worker receipts.
    if code == 0:
        result = json.loads(report.read_text()) if report.is_file() else {}
        if not (result.get('completed') is True and result.get('new_base_response_seed_qualified') is True
                and result.get('original_ExactResponseCache_restore_called') is True
                and result.get('original_ExactResponseCache_restore', {}).get('probes') == 5
                and source_guard_error is None and reason is None):
            state['status'] = 'postflight_completion_contract_failed'
            source_guard_error = source_guard_error or 'worker completion contract not satisfied'
    write(control / 'report.json', state)
    print(json.dumps({'status': state['status'], 'exit_code': code, 'seconds': state['seconds'],
                      'resource_stop_reason': reason, 'report': str(control / 'report.json')}), flush=True)
    return 0 if code == 0 and source_guard_error is None and reason is None else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quarantine-manifest', type=Path, required=True)
    parser.add_argument('--quarantine-sha256', required=True)
    parser.add_argument('--prepared-manifest', type=Path, required=True)
    parser.add_argument('--prepared-sha256', required=True)
    parser.add_argument('--attempt-label', required=True)
    parser.add_argument('--preflight-only', action='store_true')
    raise SystemExit(main(parser.parse_args()))
