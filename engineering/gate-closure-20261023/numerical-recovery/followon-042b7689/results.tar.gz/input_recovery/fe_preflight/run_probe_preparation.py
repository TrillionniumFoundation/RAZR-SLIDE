"""Freeze new probe-only source and run bounded tiny tests, without FE/CAD."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import resource
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
from check_environment import inspect_environment


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(2**20):
            value.update(block)
    return value.hexdigest()


def main(args):
    started = time.monotonic()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    paths = [BASE / name for name in ('diagnose_panel_probes.py', 'probe_refinement.py',
        'supervise_probe_diagnosis.py', 'quarantine_probe_rejected_candidate.py',
        'archive_input.py', 'test_probe_diagnosis.py', 'run_probe_preparation.py')]
    paths += [ROOT / name for name in ('integration/contact_exchange.py',
        'integration/contact_patch_audit.py', 'tools/check_environment.py', 'pyproject.toml', 'uv.lock')]
    before = {str(path): sha(path) for path in paths}
    environment_before = inspect_environment(ROOT)
    if not (environment_before['passed'] is True and environment_before['checked_package_count'] == 43):
        raise ValueError('preparation requires the original locked 43-package environment')
    environment = os.environ.copy()
    environment.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')

    def bounded_tiny_test_process():
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2,) * 2)
        resource.setrlimit(resource.RLIMIT_CPU, (25, 25))

    command = [str(ROOT / '.venv/bin/python'), '-B', '-m', 'unittest', '-v', 'test_probe_diagnosis']
    with (output / 'tiny-tests.log').open('wb') as log:
        result = subprocess.run(command, cwd=BASE, env=environment, stdout=log,
                                stderr=subprocess.STDOUT, timeout=30, preexec_fn=bounded_tiny_test_process)
    text = (output / 'tiny-tests.log').read_text()
    found = re.search(r'Ran (\d+) tests? in ([0-9.]+)s', text)
    if result.returncode or found is None or int(found[1]) != 10:
        raise RuntimeError('tiny tests failed; preserved log is the original evidence')
    after = {str(path): sha(path) for path in paths}
    environment_after = inspect_environment(ROOT)
    if after != before or environment_before != environment_after or not environment_after['passed']:
        raise ValueError('source or locked environment changed during preparation')
    copies = {}
    for index, path in enumerate(paths):
        target = output / 'prepared-source-bytes' / f'{index:02d}-{path.name}'
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(path, target)
        if sha(target) != before[str(path)]:
            raise ValueError('prepared source copy differs')
        copies[str(path)] = str(target)
    manifest = {'schema': 'razr-panel-probe-diagnosis-prepared-v1',
                'source_sha256': before, 'prepared_source_copies': copies,
                'original_rejected_candidate_will_remain_unchanged': True,
                'new_FE_factor_or_operator_solve_executed': False,
                'tiny_test_expected_count': 10,
                'resource_bounds': {'address_space_GiB': 4.25, 'shared_unreclaimable_GiB': 6.8,
                    'startup_incremental_memory_GiB': 2.9, 'wall_time_seconds': 600,
                    'startup_disk_MiB': 600, 'runtime_disk_reserve_MiB': 500},
                'numerical_contracts': {'full_free_DOF_residual_limit': 1e-7,
                    'original_restore_relative_tolerance': 2e-7, 'maximum_corrections': 4,
                    'stagnant_steps': 2, 'stagnation_relative_improvement_required': 1e-3,
                    'original_probe_rng_seed': 73021, 'original_probe_count': 5,
                    'original_external_load_count': 4}}
    manifest_path = output / 'prepared-source-manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    report = {'schema': 'razr-panel-probe-diagnosis-preparation-result-v1',
              'passed': True, 'new_FE_factor_or_operator_solve_executed': False,
              'CAD_executed': False, 'production_H_or_K_loaded': False,
              'original_failed_H_candidate_qualified': False,
              'tests': {'passed': 10, 'failed': 0, 'seconds': float(found[2]),
                        'scope': 'tiny SPD corrections/finite checks/original five-action API; real short-lived fake-child supervision failures',
                        'address_space_limit_bytes': 512 * 1024**2,
                        'subprocess_returncode': result.returncode, 'command': command,
                        'log_path': str(output / 'tiny-tests.log'), 'log_sha256': sha(output / 'tiny-tests.log')},
              'prepared_manifest_path': str(manifest_path), 'prepared_manifest_sha256': sha(manifest_path),
              'source_sha256_before': before, 'source_sha256_after': after,
              'environment_before': environment_before, 'environment_after': environment_after,
              'seconds': time.monotonic() - started,
              'children_peak_rss_kib': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
    report_path = output / 'preparation-report.json'
    report_path.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'report': str(report_path), 'report_sha256': sha(report_path),
                      'prepared_manifest_sha256': sha(manifest_path),
                      'tests': report['tests'], 'peak_rss_kib': report['children_peak_rss_kib']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    main(parser.parse_args())
