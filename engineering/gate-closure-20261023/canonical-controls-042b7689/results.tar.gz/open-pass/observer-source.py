"""Read-only sampled process/resource observations for one local runner.

This observer does not launch, stop, edit, or certify the native computation.
Observed maxima are sampled values, never guarantees on between-sample peaks.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import time


def processes():
    result = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = (path/'cmdline').read_bytes().split(b'\0')
            args = [v.decode(errors='replace') for v in args if v]
            status = dict(line.split(':', 1) for line in (path/'status').read_text().splitlines() if ':' in line)
            result[int(path.name)] = {'ppid': int(status['PPid']), 'args': args,
                'rss_bytes': int(status.get('VmRSS', '0 kB').split()[0])*1024}
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runner', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    runner, output = args.runner.resolve(), args.output.resolve()
    spec = importlib.util.spec_from_file_location('observed_runner_resource_contract', runner)
    contract = importlib.util.module_from_spec(spec); spec.loader.exec_module(contract)
    all_processes = processes()
    matches = [pid for pid, row in all_processes.items() if str(runner) in row['args'][:3]
               and str(output) in row['args'] and Path(row['args'][0]).name.startswith('python')]
    if len(matches) != 1:
        raise ValueError('the exact running Python launcher is not unique')
    pid = matches[0]
    source_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    record = {'schema': 'razr-sampled-canonical-control-resource-observation-v1',
        'observer_source_sha256': source_sha, 'runner_pid': pid,
        'runner_source_sha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
        'sample_interval_seconds': 5., 'between_sample_peaks_are_not_bounded': True,
        'observer_changes_computation': False, 'samples': []}
    path = output/'sampled-resources.json'
    while True:
        current = processes()
        if pid not in current:
            break
        descendants = {pid}
        while True:
            expanded = descendants | {p for p, row in current.items() if row['ppid'] in descendants}
            if expanded == descendants:
                break
            descendants = expanded
        children = [{'pid': p, 'rss_bytes': current[p]['rss_bytes'], 'argv': current[p]['args']}
                    for p in sorted(descendants) if p in current]
        observation = {'monotonic_seconds': time.monotonic(), 'resources': contract.resources(output),
            'runner_tree_RSS_bytes': sum(row['rss_bytes'] for row in children), 'processes': children}
        record['samples'].append(observation)
        record.update(sample_count=len(record['samples']),
            maximum_observed_runner_tree_RSS_bytes=max(v['runner_tree_RSS_bytes'] for v in record['samples']),
            maximum_observed_shared_unreclaimable_bytes=max(v['resources']['shared_unreclaimable_memory_bytes'] for v in record['samples']),
            minimum_observed_writeable_disk_bytes=min(v['resources']['writeable_disk_bytes'] for v in record['samples']))
        temporary = path.with_suffix('.partial.json')
        temporary.write_text(json.dumps(record, indent=2)+'\n'); temporary.replace(path)
        time.sleep(5.)
    record['runner_has_exited'] = True
    record['observer_source_unchanged'] = source_sha == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    path.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({k: record.get(k) for k in ('sample_count', 'maximum_observed_runner_tree_RSS_bytes',
        'maximum_observed_shared_unreclaimable_bytes', 'minimum_observed_writeable_disk_bytes', 'runner_has_exited')}))


if __name__ == '__main__': main()
