"""Sequential launcher for three exact-HEAD control-domain jobs and postguards.

The launched repository entry points own source/runtime/CAD validation. This
external runner preserves their exit codes and logs and never invents a hosted
Actions run ID or converts a geometry rejection into a passing job.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time


def resources(folder):
    stat = os.statvfs(folder)
    disk = stat.f_bavail*stat.f_frsize
    info = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    host_available = int(info['MemAvailable'].split()[0])*1024
    maximum = Path('/sys/fs/cgroup/memory.max')
    current = Path('/sys/fs/cgroup/memory.current')
    cap = maximum.read_text().strip() if maximum.exists() else 'max'
    stats = Path('/sys/fs/cgroup/memory.stat')
    values = dict(line.split() for line in stats.read_text().splitlines()) if stats.exists() else {}
    # Clean inactive file cache is reclaimable; tmpfs/shmem is not counted.
    inactive = max(0, int(values.get('inactive_file', 0))-int(values.get('file_dirty', 0))
                   -int(values.get('file_writeback', 0)))
    current_bytes = int(current.read_text()) if current.exists() else 0
    hard_headroom = int(cap)-current_bytes if cap != 'max' else host_available
    memory = min(host_available, hard_headroom+inactive)
    clean_file = max(0, int(values.get('file', 0))-int(values.get('shmem', 0))
                     -int(values.get('file_dirty', 0))-int(values.get('file_writeback', 0)))
    return {'writeable_disk_bytes': disk, 'effective_memory_headroom_bytes': memory,
            'root_reserved_free_bytes_diagnostic_only': stat.f_bfree*stat.f_frsize,
            'shared_unreclaimable_memory_bytes': max(0, current_bytes-clean_file),
            'cgroup_unused_bytes': hard_headroom, 'clean_inactive_file_cache_bytes': inactive,
            'uid': os.geteuid(), 'host_MemAvailable_bytes': host_available}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--minimum-disk-bytes', type=int, default=256*1024**2)
    parser.add_argument('--minimum-memory-bytes', type=int, default=2*1024**3)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(root):
        raise ValueError('new evidence directory outside source required')
    uv = shutil.which('uv')
    if not uv:
        raise ValueError('the installed locked-project uv launcher is absent')
    expected = args.expected_head
    if len(expected) != 40 or any(c not in '0123456789abcdef' for c in expected):
        raise ValueError('full expected HEAD required')
    output.mkdir(parents=True)
    record = {'schema': 'razr-local-sequential-canonical-controls-v1', 'expected_head': expected,
              'runner_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'hosted_Actions_execution_claimed': False, 'jobs': [], 'all_three_jobs_passed': False}
    prefix = [uv, 'run', '--locked', 'python', '-B']
    def stop(process, deadline):
        if process.poll() is not None:
            return
        grace = max(0., min(2., deadline-time.monotonic()))
        os.killpg(process.pid, signal.SIGTERM if grace else signal.SIGKILL)
        try:
            process.wait(timeout=grace if grace else 1.)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=1.)
    def run(command, log, environment, deadline):
        start = time.perf_counter()
        event = None
        if time.monotonic() >= deadline:
            raise ValueError('the shared 1200-second pose budget was exhausted before '+str(command))
        with log.open('x') as stream:
            process = subprocess.Popen(command, cwd=root, env=environment, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            while True:
                available = resources(output)
                remaining = deadline-time.monotonic()
                if remaining <= 0:
                    event = {'kind': 'shared_pose_timeout', 'resources': available}; stop(process, deadline); code = 124; break
                if (available['writeable_disk_bytes'] < 100*1024**2
                        or available['shared_unreclaimable_memory_bytes'] > int(6.8*1024**3)):
                    event = {'kind': 'shared_runtime_resource_budget', 'resources': available}; stop(process, deadline); code = 125; break
                try:
                    code = process.wait(timeout=min(2., remaining)); break
                except subprocess.TimeoutExpired:
                    continue
        return {'argv': command, 'exit_code': code, 'seconds': time.perf_counter()-start,
                'stop_event': event, 'log': log.name, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    try:
        for pose in ('STOW', 'PREDOCK', 'OPEN'):
            head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True,
                                           env={**os.environ, 'GIT_NO_REPLACE_OBJECTS': '1'}).strip()
            if head != expected:
                raise ValueError('source HEAD changed before '+pose)
            available = resources(output)
            if available['writeable_disk_bytes'] < args.minimum_disk_bytes or available['effective_memory_headroom_bytes'] < args.minimum_memory_bytes:
                raise ValueError('resource preflight failed before '+pose+': '+repr(available))
            job = {'pose': pose, 'resource_preflight': available, 'commands': [],
                   'passed': False, 'incomplete_command_sequence': True}
            record['jobs'].append(job)
            deadline = time.monotonic()+1200.
            with tempfile.TemporaryDirectory(prefix='razr-controls-'+pose.lower()+'-', dir='/tmp') as tmp:
                environment = {**os.environ, 'TMPDIR': tmp, 'PYTHONDONTWRITEBYTECODE': '1',
                               'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
                               'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
                proof = output/(pose.lower()+'-control-domain.json')
                environment_receipt = output/(pose.lower()+'-environment.json')
                check = run(prefix+['tools/check_environment.py', '--output', str(environment_receipt)],
                            output/(pose.lower()+'-environment.log'), environment, deadline)
                job['commands'].append(check)
                if check['exit_code']:
                    raise ValueError('locked environment check failed before '+pose)
                command = prefix+['integration/product_nominal_motion.py', '--pose', pose,
                                  '--expected-head', expected, '--output', str(proof)]
                job['commands'].append(run(command, output/(pose.lower()+'-native.log'), environment, deadline))
                if job['commands'][-1]['exit_code'] in (124, 125):
                    raise ValueError('native stage stopped by the common time/resource budget: '+pose)
                command = prefix+['tools/validate_product_nominal_report.py', '--report', str(proof),
                                  '--pose', pose, '--expected-head', expected]
                job['commands'].append(run(command, output/(pose.lower()+'-postguard.log'), environment, deadline))
                if job['commands'][-1]['exit_code'] in (124, 125):
                    raise ValueError('postguard stopped by the common time/resource budget: '+pose)
                job['passed'] = all(row['exit_code'] == 0 for row in job['commands'])
                job['incomplete_command_sequence'] = False
                if proof.exists():
                    job['native_report_sha256'] = hashlib.sha256(proof.read_bytes()).hexdigest()
            print(json.dumps({'pose': pose, 'passed': job['passed']}), flush=True)
            (output/'runner-report.json').write_text(json.dumps(record, indent=2)+'\n')
        record['all_three_jobs_passed'] = len(record['jobs']) == 3 and all(job['passed'] for job in record['jobs'])
    except Exception as exc:
        record['execution_failure'] = type(exc).__name__+': '+str(exc)
    (output/'runner-report.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({'all_three_jobs_passed': record['all_three_jobs_passed'], 'execution_failure': record.get('execution_failure')}), flush=True)
    return 0 if record['all_three_jobs_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
