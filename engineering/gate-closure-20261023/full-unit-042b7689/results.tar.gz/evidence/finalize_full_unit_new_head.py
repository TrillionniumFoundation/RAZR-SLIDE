"""Read and package a completed exact-HEAD full-unit run; never execute tests."""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile


ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
WORK = ROOT.parent / 'ci_audit'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--run-directory', type=Path, required=True)
    parser.add_argument('--delivery', type=Path, required=True)
    args = parser.parse_args()
    folder = args.run_directory.resolve()
    delivery = args.delivery.resolve()
    assert ROOT not in folder.parents and ROOT not in delivery.parents
    report = read(folder / 'results/report.json')
    controller = read(folder / 'controller.json')
    manifest_path = ROOT / 'tools/test_suites.json'
    manifest = read(manifest_path)
    suites = manifest['suites']
    expected_ids = [suite['id'] for suite in suites]
    rows = report['suite_results']
    current_head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'], text=True)
    assert current_head == args.expected_head == report['base_commit'] == report['expected_head'] == report['source_head_after']
    assert controller['expected_head'] == controller['head_before'] == controller['head_after'] == current_head
    assert controller['completed'] is True and controller['exit_code'] == 0
    assert controller['reported_passed'] is True and controller['verification_report_sha256'] == sha(folder / 'results/report.json')
    assert controller['manifest_sha256'] == report['suite_manifest_sha256'] == sha(manifest_path)
    assert controller['verification_entry_sha256'] == sha(ROOT / 'tools/verify.py')
    assert controller['controller_sha256'] == sha(WORK / 'run_full_unit_new_head.py')
    assert controller['controller_log_sha256'] == sha(folder / 'controller.log')
    assert not status
    assert len(suites) == 36 and len(expected_ids) == len(set(expected_ids))
    assert manifest['minimum_total_tests'] == sum(suite['minimum_tests'] for suite in suites) == 1558
    assert report['configured_minimum_tests'] == controller['configured_minimum_tests'] == 1558
    assert report['scope'] == 'all_current_unit_suites'
    assert report['selected_suite_ids'] == [row['id'] for row in rows] == expected_ids
    assert report['passed'] is True and report['execution_completed'] is True and report['test_checks_passed'] is True
    assert report['environment_verified'] is True and report['source_identity_verified'] is True
    assert report['source_bytes_unchanged'] is True and report['changed_during_tests'] == []
    assert report['source_hashes_before'] == report['source_hashes_after']
    assert report['syntax_errors'] == [] and report['diagnostic_unlocked'] is False
    assert report['present_tracked_bytes_match_head'] is True
    for flag in ('full_motion_reexecuted', 'native_KiCad_reexecuted', 'hardware_qualification', 'candidate_go', 'manufacturing_go'):
        assert report[flag] is False
    expected_command = [str(ROOT / '.venv/bin/python'), '-B', 'tools/verify.py', '--expected-head', current_head, '--output', str(folder / 'results')]
    assert controller['command'] == expected_command
    for suite, row in zip(suites, rows):
        child_path = folder / 'results' / (suite['id'] + '.json')
        child = read(child_path)
        command = [report['python_executable'], '-B', str(ROOT / 'tools/run_suite.py'), '--directory', str(ROOT / suite['directory']), '--minimum', str(suite['minimum_tests']), '--report', str(child_path)]
        for extra in suite.get('extra_paths', []):
            command += ['--extra-path', str(ROOT / extra)]
        assert row['command'] == command
        assert row['exit_code'] == 0 and row['passed'] is True
        assert row['minimum_tests'] == suite['minimum_tests'] and row['tests_run'] >= suite['minimum_tests']
        assert len(row['test_ids']) == row['tests_run'] and len(set(row['test_ids'])) == row['tests_run']
        assert all(row[key] == 0 for key in ('failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes'))
        assert all(row[key] == value for key, value in child.items())
    tests_run = sum(row['tests_run'] for row in rows)
    assert tests_run == report['tests_run'] == controller['tests_run'] and tests_run >= 1558
    recorded_files = controller['files']
    assert len(recorded_files) == len({row['path'] for row in recorded_files})
    assert {row['path'] for row in recorded_files} == {str(path.relative_to(folder)) for path in (folder / 'results').glob('*') if path.is_file()}
    for row in recorded_files:
        path = folder / row['path']
        assert row['bytes'] == path.stat().st_size and row['sha256'] == sha(path)
    sys.path.insert(0, str(ROOT))
    from tools.check_environment import inspect_environment
    environment_after = inspect_environment(ROOT)
    before_environment = report['environment']
    assert before_environment['passed'] is True and environment_after['passed'] is True
    assert before_environment['checked_package_count'] == environment_after['checked_package_count'] == 43
    assert before_environment['checked_packages'] == environment_after['checked_packages']
    assert before_environment['pyproject_sha256'] == environment_after['pyproject_sha256'] == report['pyproject_sha256']
    assert before_environment['uv_lock_sha256'] == environment_after['uv_lock_sha256'] == report['uv_lock_sha256']
    assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == current_head
    delivery.mkdir(parents=True, exist_ok=False)
    evidence = delivery / 'evidence'
    evidence.mkdir()
    for path in (folder / 'controller.json', folder / 'controller.log', WORK / 'run_full_unit_new_head.py', Path(__file__), WORK / 'full-unit-042b7689-start-resource.json', WORK / 'full-unit-042b7689-resource-observations.jsonl'):
        shutil.copyfile(path, evidence / path.name)
    (evidence / 'environment-after.json').write_text(json.dumps(environment_after, indent=2) + '\n')
    audit = {
        'schema': 'razr-full-unit-independent-receipt-v1',
        'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_head': current_head, 'scope': 'all_current_unit_suites',
        'passed': True, 'source_identity_verified': True, 'source_bytes_unchanged': True,
        'configured_suites': len(suites), 'completed_unique_suites': len(rows),
        'configured_minimum_tests': 1558, 'actual_tests_run': tests_run,
        'failures': 0, 'errors': 0, 'skipped': 0, 'expected_failures': 0, 'unexpected_successes': 0,
        'locked_package_count_before_and_after': 43, 'locked_environment_matches_before_after': True,
        'original_manifest_timeouts_preserved': True,
        'suite_command_directory_extra_paths_minimum_report_binding_verified': True,
        'child_report_and_controller_file_hashes_verified': True,
        'full_checkout_verified': report['full_checkout_verified'],
        'present_tracked_bytes_match_head': report['present_tracked_bytes_match_head'],
        'source_identity_scope': 'The execution report verifies exact HEAD bytes for the present selected source/input inventory; full historical checkout materialization is not asserted.',
        'report_sha256': sha(folder / 'results/report.json'),
        'controller_sha256': sha(folder / 'controller.json'),
        'elapsed_seconds': controller['elapsed_seconds'],
        'execution_hosted': False, 'full_motion_reexecuted': False,
        'native_KiCad_reexecuted': False, 'hardware_qualification': False,
        'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False,
        'results': [{'id': row['id'], 'tests_run': row['tests_run'], 'minimum_tests': row['minimum_tests'], 'seconds': row['seconds'], 'timeout_seconds': suite.get('timeout_seconds', 180), 'exit_code': row['exit_code']} for suite, row in zip(suites, rows)],
    }
    (evidence / 'SUMMARY.json').write_text(json.dumps(audit, indent=2) + '\n')
    archive = delivery / 'full-unit-042b7689.tar.gz'
    entries = []
    with tarfile.open(archive, 'w:gz', compresslevel=6) as bundle:
        for path in sorted((folder / 'results').iterdir()):
            assert path.is_file()
            name = 'results/' + path.name
            entries.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
            bundle.add(path, arcname=name, recursive=False)
        for path in sorted(evidence.iterdir()):
            name = 'evidence/' + path.name
            entries.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
            bundle.add(path, arcname=name, recursive=False)
    with tarfile.open(archive, 'r:gz') as bundle:
        actual = bundle.getmembers()
        assert len(actual) == len(entries) and {m.name for m in actual} == {r['path'] for r in entries}
        lookup = {r['path']: r for r in entries}
        for member in actual:
            assert member.isfile() and member.size == lookup[member.name]['bytes']
            stream = bundle.extractfile(member)
            assert stream is not None and hashlib.file_digest(stream, 'sha256').hexdigest() == lookup[member.name]['sha256']
    index = {'schema': 'razr-full-unit-archive-index-v1', 'source_head': current_head,
             'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
             'all_members_readback_sha256_verified': True, 'files': entries}
    (delivery / 'EVIDENCE_INDEX.json').write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({'passed': True, 'source_head': current_head, 'tests_run': tests_run,
                      'suites': len(rows), 'elapsed_seconds': controller['elapsed_seconds'],
                      'archive': str(archive), 'bytes': archive.stat().st_size,
                      'sha256': sha(archive), 'members_verified': len(entries)}))


if __name__ == '__main__':
    main()
