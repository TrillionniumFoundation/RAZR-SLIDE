"""Record one complete tools/verify.py run without changing its suite timeouts."""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import subprocess
import time


ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if len(args.expected_head) != 40 or any(c not in '0123456789abcdef' for c in args.expected_head):
        raise ValueError('complete lowercase source commit required')
    folder = args.output.resolve()
    if folder == ROOT or ROOT in folder.parents:
        raise ValueError('new output outside the repository required')
    folder.mkdir(parents=True, exist_ok=False)
    command = [str(ROOT / '.venv/bin/python'), '-B', 'tools/verify.py',
               '--expected-head', args.expected_head, '--output', str(folder / 'results')]
    manifest = json.loads((ROOT / 'tools/test_suites.json').read_text())
    head_before = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    receipt = {
        'schema': 'razr-full-unit-controller-v1',
        'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'expected_head': args.expected_head, 'head_before': head_before,
        'command': command, 'working_directory': str(ROOT),
        'controller_sha256': sha(__file__),
        'verification_entry_sha256': sha(ROOT / 'tools/verify.py'),
        'manifest_sha256': sha(ROOT / 'tools/test_suites.json'),
        'configured_suites': len(manifest['suites']),
        'configured_minimum_tests': manifest['minimum_total_tests'],
        'scope': 'one complete invocation with no suite selection and unchanged manifest timeouts',
        'environment_translation': 'already locked .venv/bin/python replaces uv run --locked python prefix only',
        'hosted_execution': False,
        'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False,
        'completed': False,
    }
    path = folder / 'controller.json'
    path.write_text(json.dumps(receipt, indent=2) + '\n')
    if head_before != args.expected_head:
        receipt.update(failure='expected source head differs', exit_code=2)
        path.write_text(json.dumps(receipt, indent=2) + '\n')
        return 2
    environment = os.environ.copy()
    environment.update(PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1',
                       OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
    started = time.monotonic()
    with (folder / 'controller.log').open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, env=environment,
                                stdout=log, stderr=subprocess.STDOUT)
    receipt.update(completed=True, exit_code=result.returncode,
                   elapsed_seconds=time.monotonic()-started,
                   completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                   head_after=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
                   controller_log_sha256=sha(folder / 'controller.log'))
    receipt['files'] = [{'path': str(p.relative_to(folder)), 'bytes': p.stat().st_size,
                         'sha256': sha(p)} for p in sorted((folder / 'results').glob('*')) if p.is_file()]
    report_path = folder / 'results/report.json'
    if report_path.is_file():
        report = json.loads(report_path.read_text())
        receipt.update(verification_report_sha256=sha(report_path),
                       reported_passed=report.get('passed'), tests_run=report.get('tests_run'),
                       reported_scope=report.get('scope'),
                       source_identity_verified=report.get('source_identity_verified'),
                       source_bytes_unchanged=report.get('source_bytes_unchanged'))
    path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('exit_code', 'elapsed_seconds', 'reported_passed',
          'tests_run', 'reported_scope', 'source_identity_verified', 'source_bytes_unchanged') if key in receipt}))
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
