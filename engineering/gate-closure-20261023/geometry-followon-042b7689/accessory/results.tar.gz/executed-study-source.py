"""Full-field OPEN accessory insertion/removal, at the declared nominal scope.

The seven original straight paths are checked against every installed current
EP5 participant. Released tabs are fixed; both PAWL slot flanks vary throughout
[-1,1]. A checked straight path has exactly the same geometric image in reverse.
Thread engagement, preload, tools/hands and loose-accessory storage are outside
this nominal material-interference study.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys
import time

DOMAIN = ((0., 1.), (-1., 1.), (-1., 1.))
ACCESSORIES = ('L_OPEN_HOLD_M1_NOMINAL', 'R_OPEN_HOLD_M1_NOMINAL',
               'B_OPEN_DISPLAY_SUPPORT_ACCESSORY', 'L_B_SUPPORT_0_M1_NOMINAL',
               'L_B_SUPPORT_1_M1_NOMINAL', 'R_B_SUPPORT_0_M1_NOMINAL',
               'R_B_SUPPORT_1_M1_NOMINAL')
VECTORS = ((0., 0., 10.), (0., 0., 10.), (80., 0., 0.),
           (0., 0., -8.), (0., 0., -8.), (0., 0., -8.), (0., 0., -8.))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stage_plan(names):
    """Declare exact stage inventories and derive the reverse installed sets."""
    names = list(names)
    if len(names) != 161 or len(set(names)) != 161 or not set(ACCESSORIES) <= set(names):
        raise ValueError('all 161 unique OPEN participants and seven accessories required')
    installed = set(names)-set(ACCESSORIES)
    stages = []
    for number, (name, vector) in enumerate(zip(ACCESSORIES, VECTORS), 1):
        stages.append({'insertion_stage': number, 'moving': name,
                       'seated_to_outside_vector_mm': list(vector),
                       'insertion_parameter_interval': [1., 0.], 'removal_parameter_interval': [0., 1.],
                       'installed_before_insertion': sorted(installed),
                       'removed_accessories': sorted(set(ACCESSORIES)-installed-{name})})
        installed.add(name)
    for number, stage in enumerate(reversed(stages), 1):
        installed.remove(stage['moving'])
        if installed != set(stage['installed_before_insertion']):
            raise ValueError('reverse path has a different complete obstacle inventory')
        stage.update(removal_stage=number, installed_during_removal=sorted(installed),
                     reverse_geometric_set_identity='t -> 1-t on the same [0,1] straight path',
                     reverse_obstacle_inventory_identical=True)
    return stages


def validate_stage(stage, rows, validate_frame):
    expected = set(stage['installed_before_insertion'])
    actual = [row.get('fixed') for row in rows]
    if len(actual) != len(expected) or len(set(actual)) != len(actual) or set(actual) != expected:
        raise ValueError('incomplete or repeated full installed obstacle field')
    if any(row.get('moving') != stage['moving'] for row in rows):
        raise ValueError('pair row does not identify this stage moving material')
    failures = []
    for row in rows:
        try:
            validate_frame(row)
        except ValueError as exc:
            failures.append({'fixed': row['fixed'], 'error': str(exc)})
    return {'checked_pairs': len(rows), 'counts': dict(Counter(row.get('disposition') for row in rows)),
            'all_installed_participants_checked_once': True, 'evaluation_failures': failures,
            'continuous_path_clear': not failures and all(row.get('disposition') == 'clear' for row in rows)}


def retain_collision_witness(witness, records, export):
    """Keep an actual full-factory positive even if its STEP export fails."""
    for key in ('trial_common_mm3', 'fresh_factory_common_mm3'):
        value = witness.get(key)
        if type(value) not in (int, float) or not math.isfinite(value) or value <= 1e-7:
            raise ValueError('a reproduced actual positive Common witness is required')
    retained = dict(witness)
    records.append(retained)
    try:
        retained['actual_positive_Common_STEP'] = export()
    except Exception as exc:
        error = type(exc).__name__+': '+str(exc)
        retained['STEP_export_failure'] = error
        return {'fixed': witness['fixed'], 'error': error,
                'failure_stage': 'actual_collision_STEP_export',
                'actual_common_mm3_preserved': witness['fresh_factory_common_mm3']}
    return None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--open-control-report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    root, output = args.root.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(root):
        raise ValueError('new evidence directory outside the repository required')
    sys.path[:0] = [str(root/'integration'), str(root/'tools')]
    import product_nominal_motion as nominal
    import validate_product_nominal_report as postguard
    import product_routing_ep5 as ep5
    import cadquery as cq
    p = nominal.p
    own_source = Path(__file__).resolve()
    own_before = sha(own_source)
    output.mkdir(parents=True)
    started = time.perf_counter()
    report = {'schema': 'razr-ep5-complete-accessory-motion-v1', 'source_commit': args.expected_head,
              'execution_completed': False, 'execution_checks_passed': False,
              'diagnostic_execution_checks_passed': False, 'stages': [],
              'complete_product_motion_proved': False, 'physical_qualification': False,
              'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False,
              'formal_directed_rounding_certificate': False, 'geometry_generator_imported': True,
              'same_CAD_kernel': True, 'tools_handling_thread_force_and_storage_qualified': False,
              'scope': {'pose': 'OPEN', 'slide_mm': 79.75, 'descent_mm': 8.2,
                        'tabs_mm': [3., 3.], 'left_right_slot_flanks': [[-1., 1.], [-1., 1.]],
                        'KEY_offsets_mm': [0., 0.], 'crosshead_offsets_mm': [0., 0.],
                        'telescope_joint_offsets_mm': [.1, .1, .1],
                        'accessory_path_parameter_mm': 'seated body plus t * original approach vector; t in [0,1]'},
              'executed_study_source': {'path': str(own_source), 'sha256': own_before},
              'confirmed_collision_witnesses': []}
    try:
        before = postguard.current_identity(root, args.expected_head)
        report['identity_before'] = before
        base_hash = sha(args.open_control_report)
        base = json.loads(args.open_control_report.read_text())
        report['installed_OPEN_domain_receipt_postcheck'] = postguard.validate_report(base, 'OPEN', args.expected_head, before)
        report['installed_OPEN_domain_receipt'] = {'path': str(args.open_control_report.resolve()), 'sha256': base_hash}
        parts, metadata = nominal.full_scene(79.75, 8.2, 3., 3., open_hold=True, open_support=True)
        ep5.validate_factory_input_coverage(metadata['scene'], before['executed_source_sha256'])
        if sorted(parts) != base['complete_participant_names']:
            raise ValueError('fresh complete OPEN scene differs from the checked control inventory')
        report['complete_participant_names'] = sorted(parts)
        report['native_scene_metadata'] = metadata
        coefficients = nominal.controls_coefficients(parts, p.native_inputs()[5])
        for name in ACCESSORIES:
            if any(any(vector) for vector in coefficients[name]):
                raise ValueError('an accessory has an unrepresented control-dependent placement')
        cache = {}
        for stage in stage_plan(parts):
            name, vector = stage['moving'], stage['seated_to_outside_vector_mm']
            moving = parts[name]
            rows = []
            for target in stage['installed_before_insertion']:
                relative = [vector, [-v for v in coefficients[target][2]], [-v for v in coefficients[target][3]]]
                row = nominal.continuous_pair(moving, parts[target], relative, cache=cache, domain=DOMAIN)
                rows.append({'moving': name, 'fixed': target, **row})
            stage['pairs'] = rows
            stage.update(validate_stage(stage, rows, postguard.validate_frame))
            report['stages'].append(stage)
            print(json.dumps({'stage': stage['insertion_stage'], 'moving': name,
                              'pairs': len(rows), 'counts': stage['counts'], 'seconds': time.perf_counter()-started}), flush=True)
            for row in rows:
                if row['disposition'] == 'clear' or len(report['confirmed_collision_witnesses']) >= 5:
                    continue
                target = row['fixed']
                for t, flank_l, flank_r in itertools.product((0., .125, .25, .5, .75, .875, 1.), (-1., 0., 1.), (-1., 0., 1.)):
                    moved = moving.translate(tuple(v*t for v in vector))
                    target_shift = nominal.translation(coefficients[target], (0., 0., flank_l, flank_r))
                    trial = p.strict_common(moved, parts[target].translate(target_shift))
                    if trial['common_mm3'] <= nominal.TOL:
                        continue
                    fresh, _ = nominal.full_scene(79.75, 8.2, 3., 3., flanks=(flank_l, flank_r),
                                                 open_hold=True, open_support=True)
                    actual_moving = fresh[name].translate(tuple(v*t for v in vector))
                    actual = p.strict_common(actual_moving, fresh[target])
                    if actual['common_mm3'] <= nominal.TOL:
                        raise ValueError('affine collision candidate did not reproduce in the actual full factory')
                    witness_path = output/('collision-%02d.step' % (len(report['confirmed_collision_witnesses'])+1))
                    def export():
                        cq.exporters.export(actual_moving.intersect(fresh[target]), str(witness_path))
                        return {'path': witness_path.name, 'sha256': sha(witness_path)}
                    witness = {'insertion_stage': stage['insertion_stage'],
                        'moving': name, 'fixed': target, 'path_parameter': t, 'slot_flanks': [flank_l, flank_r],
                        'trial_common_mm3': trial['common_mm3'], 'fresh_factory_common_mm3': actual['common_mm3'],
                        'all_installed_obstacles': stage['installed_before_insertion'],
                        'positive_enclosure_alone_was_not_called_collision': True}
                    failure = retain_collision_witness(witness, report['confirmed_collision_witnesses'], export)
                    if failure is not None:
                        stage['evaluation_failures'].append(failure)
                    break
        after = postguard.current_identity(root, args.expected_head)
        report['identity_after'] = after
        source_unchanged = (before == after and own_before == sha(own_source)
                            and base_hash == sha(args.open_control_report))
        report['source_bytes_unchanged'] = source_unchanged
        complete = len(report['stages']) == 7 and all(stage['all_installed_participants_checked_once'] for stage in report['stages'])
        failures = [{'stage': stage['insertion_stage'], **error}
                    for stage in report['stages'] for error in stage['evaluation_failures']]
        canonical = (own_source.is_relative_to(root)
                     and before['head_bound_source_sha256'].get(own_source.relative_to(root).as_posix()) == own_before)
        report.update(execution_completed=True, evaluation_failures=failures,
            unique_continuous_moving_obstacle_pairs=sum(stage['checked_pairs'] for stage in report['stages']),
            directed_insertion_and_removal_paths=14, reverse_paths_reuse_identical_proved_sets=True,
            all_declared_accessory_paths_clear=complete and all(stage['continuous_path_clear'] for stage in report['stages']),
            scratch_study_source=not canonical,
            diagnostic_execution_checks_passed=complete and source_unchanged and not failures,
            execution_checks_passed=canonical and complete and source_unchanged and not failures,
            sampled_clear_witnesses_cannot_discharge_an_unresolved_path=True)
    except Exception as exc:
        report['execution_failure'] = type(exc).__name__+': '+str(exc)
    report['seconds'] = time.perf_counter()-started
    (output/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: report.get(key) for key in ('execution_completed', 'execution_checks_passed',
        'diagnostic_execution_checks_passed', 'all_declared_accessory_paths_clear', 'execution_failure', 'seconds')}), flush=True)
    return 0 if report['diagnostic_execution_checks_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
