# KEY 端点单次探针：保全检查点与严格恢复

这是固定仓库提交 `042b768903cccbd7a0995317c8598401e0318e2a` 上的独立研究准备包。
该版本尚未执行 CAD。实际纯回归为 **50/50，0 failure/error/skip**：23 项 worker/
checkpoint/supervisor 回归和 27 项完整原始数据恢复验证回归。它们不增加冻结仓库
1558 项验收测试计数，也不构成几何或物理验收。

## 本次修复

- 每个端点 trial 是独立新进程，环境核查、原 canonical 基线核查、native、独立
  postguard 共用该 trial 的 1200 秒。选择列表必须唯一且按原六项顺序。
- CAD 导入前写下全部 154/161 参与件、24 个移动件以及所有 changed/fixed 配对。
  每 128 对和每个错误保存一次；正 Common 的完整数值和 pair 身份在 STEP 导出前
  原子保存，导出失败不能抹去正值。
- 完整 3396/3564 个 changed 配对与 8385/9316 个固定配对独立重建；重复、遗漏、
  错序、NaN、错误阈值/作用域/来源、丢失正值和缺少原 STEP 都不能恢复。
- 原四 profile 的 metadata 来自当前 HEAD 绑定的 gzip；STOW 原生 floor/pin 支持
  由原始顶点、面、轴、面积和区间重新计算，不只相信 producer 的通过布尔值。
- `status=complete` 只在全部实际数据、全部来源和独立 postguard 通过后保存。
  真实正 Common 可成为完整的“穿透试验”证据，不能成为可使用姿态或连续通过。
- 只在实际 Popen 成功后写 native 已启动和 PID；启动前超时不会被记作已执行。
  资源读取、保存回调、KeyboardInterrupt 等异常均停止并回收子进程。

原完整 KEY 资源守卫保持：起步 ordinary `f_bavail` 磁盘至少 256 MiB、有效内存
至少 2 GiB；运行 ordinary 磁盘至少 100 MiB、共享不可回收内存至多 6.8 GiB。
BLAS/OMP/MKL/NUMEXPR 线程均为 1。root 保留磁盘空间不计入预算。

## 原失败证据

前一版本被共享内存守卫以 125 停止。两条 stdout 报告 6792 对、四个保存 STEP，
但没有保全完整 `report.json`。这些 stdout 不能恢复为已验收 trial，也没有完成六项
20,880 个 changed 配对。原包保持不变：

`key-endpoint-042b7689-stopped-v1.tar.gz`

SHA256 `a4c9ec2f12c3e000ffbe281faaed7fa49ea0e125c0f815dafbcce860fc70c4aa`。

## 执行与恢复

待 root 分配 heavy 窗口且原 guard 全部满足后，在当前环境运行，例如只执行一个
能恢复旧穿透原始 pair 身份的 STOW 半带试验：

```bash
/workspace/scratch/95cd2986fdf2/RAZR-SLIDE/.venv/bin/python -B \
  /workspace/scratch/95cd2986fdf2/gates_audit/dev/key-endpoint-v4/run_key_endpoint_trials.py \
  --root /workspace/scratch/95cd2986fdf2/RAZR-SLIDE \
  --expected-head 042b768903cccbd7a0995317c8598401e0318e2a \
  --stow-report /workspace/scratch/95cd2986fdf2/run-controls-042b7689-retry1/stow-control-domain.json \
  --open-report /workspace/scratch/95cd2986fdf2/run-controls-042b7689-retry3/open-control-domain.json \
  --trials STOW_OUTSIDE_HALF_BAND \
  --output /workspace/scratch/95cd2986fdf2/run-key-endpoint-v4-new
```

其余原 trial 标签按顺序为 STOW_OUTSIDE_0p001mm、STOW_OUTSIDE_HALF_BAND、
STOW_OUTSIDE_FULL_BAND、OPEN_OUTSIDE_0p001mm、OPEN_OUTSIDE_HALF_BAND、
OPEN_OUTSIDE_FULL_BAND。`--trials` 选择其中有序子集。每项保留完整原始结果，整体
汇总只反映实际请求并完成的项，不把子集称为六项完成。

`--resume-from` 可以提供旧**完整 v4 单 trial** 的目录，目录内须仅有一个
`report.json` 或 `native/report.json`。恢复仅复用通过当前五文件来源、仓库 HEAD/
全部 43 锁包、原基线、全部配对和正值 STEP 字节核验的原 bundle；会记录原路径和
SHA，不伪造新 native 执行。partial、旧 v3、stdout-only 一律拒绝。

两次联合纯回归回执都保留：先前 48 项对应修复 native 启动口径之前的字节；
`combined-pure-test-receipt-v2.json` 对应当前 50 项与当前五文件 SHA。
独立原 18 项和扩展 27 项 reader 回执同样保留。完整字段合同见 `SCHEMA.md`。

## 科学边界

没有证明连续 backlash 域、全局 KEY 硬止挡、完整 G2、恢复力/摩擦/强度/公差或
任何制造资格。原 `ContactProfile.evaluate` 与历史证据没有被修改。新的四 STEP
独立 readback 若执行，会单独记录；它不能补造旧试验丢失的 pair 记录。
