# KEY endpoint single-trial checkpoint and resume contract

This is a scratch diagnostic on immutable repository HEAD
`042b768903cccbd7a0995317c8598401e0318e2a`. The old v3 sources and the stopped
v1 execution remain unchanged. Old stdout-only trials are not resumable.

## Files and ownership

- gates: `integration/probe_key_endpoint_extension.py` (single-trial worker),
  `run_key_endpoint_trials.py` (sequential selector/supervisor), and
  `tests/test_key_endpoint_extension.py` (original eight helper regressions plus checkpoint tests).
- ci: `tools/key_endpoint_resume.py` (stdlib independent completed-trial validator)
  and `tests/test_key_endpoint_resume.py` (focused synthetic resume regressions).
- All five files form the reviewed study source closure, keyed by the relative
  paths above and SHA256. The worker and validator compare that complete mapping
  before/after and to the caller-provided current mapping.

The supervisor accepts `--trials` with any unique labels in canonical order:
`STOW_OUTSIDE_0p001mm`, `STOW_OUTSIDE_HALF_BAND`, `STOW_OUTSIDE_FULL_BAND`,
`OPEN_OUTSIDE_0p001mm`, `OPEN_OUTSIDE_HALF_BAND`, `OPEN_OUTSIDE_FULL_BAND`.
Each worker gets exactly one `--trial`, the original canonical `--control-report`,
and a new output directory. Every selected trial has its own original 1200-second
shared environment/baseline/native/postguard budget and the original resource
guards (2GiB/256MiB start; 6.8GiB/100MiB runtime; all threads one).

## Single-trial report

`report.json` is atomically replaced at initialization (before CAD import), after
construction milestones, every 128 completed pairs, immediately after retaining
a positive numeric row **before STEP export**, after each export attempt, and at
the final source/postflight boundary. Both expected pair lists are present from
initialization. The checkpoint is always explicitly incomplete until every
required postcondition is checked.

Fields:

- `schema`: `razr-KEY-endpoint-single-trial-v2`.
- `source_commit`: full expected repository HEAD.
- `trial_label`: one of the six labels above.
- `trial_inputs`: `{label, KEY_offset_mm, crosshead_offset_mm, nominal_q_mm, pose, q_mm}`.
  Constants retain the original formulas: `a=(.425-.4)*hypot(1,12/79.75)`,
  `b=(.425-.4)*sqrt(2)`, `h=a+b`. Magnitudes are `.001`, `h/2`, `h`,
  with `dx=a*dq/h`. STOW has negative dq and nominal q=0; OPEN has positive dq
  and nominal q=12. Both sides use that same trial, not independent offsets.
- `scope`: `{pose, slide_mm, descent_mm, tabs_mm:[3,3], slot_flanks:[0,0],
  telescope_offsets_each_mm:[j,j,j], independent_left_right_offsets_explored:false}`.
  STOW `s=d=0,j=.1+8.2/3`; OPEN `s=79.75,d=8.2,j=.1`.
- `complete_participant_names`: exact sorted canonical baseline inventory,
  154 STOW / 161 OPEN; no substitutes.
- `moving_participants`: exact sorted 24 original KEY/crosshead/telescope roles.
- `expected_changed_pairs`: sorted complete pair list containing at least one moving body.
- `reused_unchanged_pairs`: exact complementary fixed pair list. These lists partition
  all 11781 / 12880 unique unordered pairs; changed counts 3396 / 3564.
- `actual_native_changed_pairs`: completed prefix of `expected_changed_pairs`, using
  original `p.strict_common` fields `{a,b,common_mm3,method,axis_gap_lower_mm,rejected}`,
  or `{a,b,evaluation_failed:true,error}` if an operation failed.
- `pending_changed_pairs`: exact remaining suffix; `processed_pair_count` equals the raw length.
- `positive_actual_Common`: every actual raw Common strictly greater than original
  `1e-7`, retained with all raw numeric fields, plus `actual_Common_STEP:{path,sha256}`
  for the first eight positives, or `STEP_export_failure` if its export failed.
  Additional positives remain numeric records; `positive_Common_STEP_export_limit_per_trial=8`.
  STEP paths are local relative filenames without links/traversal; reader checks bytes.
- `evaluation_failures`: original native failed rows and export errors. Export error
  records preserve the original positive numeric value. A completed resumable result
  requires an empty failure list and no nested error or budget records.
- `existing_profile_rejections`: four `{side,STOP,error}` records, all side/index pairs.
  These preserve the original factory contact-profile rejection of q outside [0,12].
- `pose_record`: original full `native_scene_metadata`, `moving_participants`,
  `complete_participant_names`, `participants`, and `in_domain_factory_crosscheck`:
  `{KEY_offset_mm,crosshead_offset_mm,all_participants_compared,
  bidirectional_material_difference_mm3}`. The map contains **all** participants,
  including explicit zeros for identical shapes. Every value is finite, nonnegative,
  and <=1e-7. STOW additionally preserves `native_plateau_contact_extension` raw rows;
  OPEN preserves `selected_lower_stop_positions_retained:true` and
  `new_lower_stop_force_or_retention_proof:false`.
  Each STOW floor candidate retains `vertices_eqr_mm`, `wire_count`,
  `edge_geometry_types`, `normal_xyz`, `center_eqr_mm`, actual area and q/e extents;
  each pin candidate retains `vertices_eqr_mm`, `radius_mm`,
  `axis_direction_xyz`, `cylinder_location_xyz`, actual q/r and e extents and
  the full cylinder volume outside the complete STOP. The independent reader
  derives rectangle, contact-range, margin and overlap consistency from these
  raw values and the unchanged HEAD-bound original profile gzip. Unsupported
  contact continuation remains a valid diagnostic result, never a support claim.
- `baseline_report`: `{pose,path,sha256}` referencing the original canonical JSON;
  `baseline_receipt_postcheck` is its independently checked result.
- `identity_before`, `identity_after`: repository `current_identity(root,head)` results;
  for a completed trial both equal the caller's current identity.
- `study_source_sha256_before`, `study_source_sha256_after`: full five-file mapping,
  both equal the caller's current mapping for a completed trial.
- `executed_study_source`: `{path,sha256}` for the actual worker source.
- `status`: `pending`, `constructing`, `evaluating`, `complete`, `interrupted`, or `failed`.
- `execution_completed`, `diagnostic_execution_checks_passed`, `source_bytes_unchanged`:
  all true only for a complete successfully evaluated finite diagnostic. Real positive
  Common is allowed in a complete diagnostic; it makes `finite_trial_material_clear=false`.
- `finite_trial_material_clear`: exactly no positive rows and no evaluation failures.
- `checkpoint_generation`: increasing nonnegative integer; diagnostic only.
- `execution_failure`: optional original exception text on failure/interruption.
- `seconds`: actual wall duration, finite nonnegative.

The following flags must remain false for every completed diagnostic:
`execution_checks_passed`, `canonical_execution_claimed`,
`continuous_backlash_domain_proved`, `global_KEY_hard_stop_proved`,
`complete_product_motion_proved`, `physical_qualification`, `candidate_go`,
`fixture_fabrication_go`, `manufacturing_go`, `formal_directed_rounding_certificate`,
`whole_current_factory_acceptance_claimed`, `all_trial_states_accepted_by_existing_factory`.
True flags: `scratch_study_source`, `geometry_generator_imported`, `same_CAD_kernel`,
`positive_Common_means_penetrating_trial_not_usable_state`,
`all_positive_pair_numeric_records_retained_even_when_STEP_export_limit_reached`.

## Validator API

`validate_completed_trial(record, *, expected_head, expected_label, current_identity,
expected_study_sources, baseline_report, baseline_path, report_directory)` returns
a small independent summary or raises ValueError. It must invoke the repository
canonical control postguard for `baseline_report`; validate its actual path/SHA;
rebuild both complete pair lists from the baseline inventory; validate every raw
numeric/rejection/positive/STEP record and exact trial/scope/identity; and reject
all incomplete or inconsistent states. A positive finite diagnostic can resume
only with every required actual STEP and every numeric pair record intact.

The CLI will receive report/baseline/root/study-root/expected-head/expected-label,
compute fresh current repository identity and five-file mapping, call the API,
and verify the same source identity after reading. It never imports CAD.

The supervisor's `--resume-from` directories are read-only inputs. It reuses only
already completed single-trial bundles accepted by this validator at the current
exact source/HEAD/lock/baseline identity. It records their actual paths and hashes;
it does not fabricate a new native execution or copy an incomplete trial into a
completed result. Without a valid full raw bundle a trial must run again.

Synthetic tests are not native CAD execution or additions to the frozen 1558 count.
