"""Bounded readback of four existing saved Common STEP files only.

No full scene, new Common, or geometric export is performed. Pair identities
and the interrupted finite trial remain unqualified. This scope has its own
90-second budget and 768 MiB reserve/RSS ceiling, never the full-scene guard.
"""
from __future__ import annotations
import argparse
import gc
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time

BASE = Path('/workspace/scratch/95cd2986fdf2')
ROOT = BASE/'RAZR-SLIDE'
HEAD = '042b768903cccbd7a0995317c8598401e0318e2a'
ORIGINAL = BASE/'run-key-endpoint-042b7689-v1/native'
ARCHIVE = BASE/'gates_audit/key-endpoint-042b7689-stopped-v1.tar.gz'
ARCHIVE_SHA = 'a4c9ec2f12c3e000ffbe281faaed7fa49ea0e125c0f815dafbcce860fc70c4aa'
HELPER = BASE/'gates_audit/dev/key-endpoint-v4/run_key_endpoint_trials.py'
WITNESSES = {
    'STOW_OUTSIDE_HALF_BAND-positive-01.step': '65e5e1df3f8161eee2d7da0c2358f6a0ee6df9263f174ec7bd618378c3fb7ec3',
    'STOW_OUTSIDE_HALF_BAND-positive-02.step': 'b8959f567c54bddacd2fa99f405ac8fd150c4f007bbbe9385ef1114dfda82c90',
    'STOW_OUTSIDE_HALF_BAND-positive-03.step': '41c5c7f745302d9663f9ea2e28fac98c2bd06cb4aaa38d7311002c359a1fe5ee',
    'STOW_OUTSIDE_HALF_BAND-positive-04.step': 'dcde4b9a528c6a4577845151c0b5c1c10902a7fd6b0a3d8ce6bbaed5a908e809',
}
RESERVE = 768*1024**2
MAX_SHARED = int(6.8*1024**3)
MIN_DISK = 100*1024**2


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    data = (json.dumps(value, indent=2, allow_nan=False)+'\n').encode()
    temporary = Path(str(path)+'.tmp')
    with temporary.open('wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def original_hashes():
    actual = {name: sha(ORIGINAL/name) for name in WITNESSES}
    if actual != WITNESSES or sha(ARCHIVE) != ARCHIVE_SHA:
        raise ValueError('saved original witness/archive bytes differ')
    return actual


def read_worker(output):
    started = time.perf_counter()
    report = {'schema': 'razr-saved-Common-STEP-readback-v1', 'source_commit': HEAD,
              'reader_source_sha256': sha(__file__), 'original_STEP_sha256': original_hashes(),
              'rows': [], 'readback_completed': False, 'complete_product_motion_proved': False,
              'physical_qualification': False, 'geometry_generator_imported': False,
              'full_scene_constructed': False, 'new_Common_computed': False,
              'old_trial_raw_pair_identity_recovered': False, 'old_trial_completion_recovered': False,
              'independent_CAD_kernel': False, 'original_Common_operation_recomputed': False}
    write(output/'readback.json', report)
    try:
        import cadquery as cq
        from OCP.Bnd import Bnd_Box
        from OCP.BRepBndLib import BRepBndLib
        from OCP.TopoDS import TopoDS_Iterator
        from OCP.TopAbs import TopAbs_COMPOUND, TopAbs_COMPSOLID, TopAbs_SOLID

        def leaf_types(shape):
            kind = shape.ShapeType()
            if kind in (TopAbs_COMPOUND, TopAbs_COMPSOLID):
                iterator = TopoDS_Iterator(shape)
                values = []
                while iterator.More():
                    values.extend(leaf_types(iterator.Value()))
                    iterator.Next()
                return values
            return [kind]

        for name, digest in WITNESSES.items():
            path = ORIGINAL/name
            roots = cq.importers.importStep(str(path)).vals()
            if not roots:
                raise ValueError('empty imported STEP: '+name)
            values = []
            for shape in roots:
                leaves = leaf_types(shape.wrapped)
                if not shape.isValid() or not leaves or any(kind != TopAbs_SOLID for kind in leaves):
                    raise ValueError('invalid or non-solid complete imported material: '+name)
                solids = shape.Solids()
                volumes = [solid.Volume() for solid in solids]
                total = shape.Volume()
                if (any(not math.isfinite(v) or v <= 0 for v in volumes)
                        or not math.isfinite(total) or total <= 0 or abs(total-sum(volumes)) > 1e-7):
                    raise ValueError('invalid or incomplete signed volume accounting: '+name)
                bounds = Bnd_Box()
                BRepBndLib.AddOptimal_s(shape.wrapped, bounds, False, False)
                box = list(bounds.Get())
                if (len(box) != 6 or not all(math.isfinite(v) for v in box)
                        or any(box[i+3] <= box[i] for i in range(3))):
                    raise ValueError('nonfinite full native bounds: '+name)
                values.append({'shape_type': shape.ShapeType(), 'valid': True,
                    'complete_solid_count': len(solids), 'solid_volumes_mm3': volumes,
                    'complete_signed_volume_mm3': total, 'bounds_xyz_min_then_max_mm': box,
                    'non_solid_top_level_leaf_count': 0})
            if sha(path) != digest:
                raise ValueError('witness changed during STEP import: '+name)
            row = {'file': name, 'sha256': digest, 'root_count': len(roots), 'roots': values,
                   'total_saved_Common_volume_mm3': sum(value['complete_signed_volume_mm3'] for value in values),
                   'saved_Common_volume_above_original_1e_minus_7':
                       sum(value['complete_signed_volume_mm3'] for value in values) > 1e-7,
                   'original_pair_identity_known': False}
            report['rows'].append(row)
            report['seconds'] = time.perf_counter()-started
            write(output/'readback.json', report)
            print(json.dumps(row), flush=True)
            del roots, solids, shape
            gc.collect()
        report['readback_completed'] = len(report['rows']) == 4 and original_hashes() == WITNESSES
    except BaseException as exc:
        report['execution_failure'] = type(exc).__name__+': '+str(exc)
        report['readback_completed'] = False
    report['seconds'] = time.perf_counter()-started
    write(output/'readback.json', report)
    return 0 if report['readback_completed'] else 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', action='store_true')
    args = parser.parse_args(argv)
    output = args.output.resolve()
    if args.worker:
        return read_worker(output)
    if output.exists() or output.is_relative_to(ROOT):
        raise ValueError('new external output required')
    output.mkdir(parents=True)
    shutil.copyfile(__file__, output/'executed-reader-source.py')
    shutil.copyfile(HELPER, output/'resource-helper-source.py')
    own_sha, helper_sha = sha(__file__), sha(HELPER)
    spec = importlib.util.spec_from_file_location('original_resource_helpers', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    report = {'schema': 'razr-small-saved-STEP-readback-supervisor-v1', 'expected_head': HEAD,
        'reader_source_sha256': own_sha, 'resource_helper_sha256': helper_sha,
        'scope': 'only import/read four preserved STEP witnesses; no new scene or Common',
        'common_budget_seconds': 90, 'reserve_and_worker_RSS_bytes': RESERVE,
        'maximum_shared_unreclaimable_memory_bytes': MAX_SHARED,
        'minimum_ordinary_disk_bytes': MIN_DISK, 'native_started': False,
        'readback_execution_checks_passed': False, 'original_full_KEY_start_guard_changed': False,
        'canonical_execution_claimed': False, 'complete_product_motion_proved': False,
        'physical_qualification': False, 'old_trial_completed': False}
    def save():
        write(output/'supervisor.json', report)
    save()
    process = None
    deadline = time.monotonic()+90.
    try:
        available = helper.resources(output)
        report['resource_preflight'] = available
        if (available['writeable_disk_bytes'] < MIN_DISK
                or available['effective_memory_headroom_bytes'] < RESERVE
                or available['shared_unreclaimable_memory_bytes']+RESERVE > MAX_SHARED):
            raise ValueError('original shared guard plus declared small readback reserve unavailable')
        sys.path.insert(0, str(ROOT/'tools'))
        import validate_product_nominal_report as guard
        report['identity_before'] = guard.current_identity(ROOT, HEAD)
        report['original_STEP_sha256'] = original_hashes()
        with tempfile.TemporaryDirectory(prefix='razr-witness-readback-', dir='/tmp') as temporary:
            environment = {**os.environ, 'TMPDIR': temporary, 'PYTHONDONTWRITEBYTECODE': '1',
                'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
            command = [str(ROOT/'.venv/bin/python'), '-B', str(Path(__file__).resolve()), '--worker', '--output', str(output)]
            report['argv'] = command
            report['environment_overrides'] = {key: environment[key] for key in (
                'TMPDIR', 'PYTHONDONTWRITEBYTECODE', 'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
                'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')}
            if time.monotonic() >= deadline:
                raise ValueError('shared 90-second readback budget exhausted before native start')
            with (output/'native.log').open('x') as stream:
                process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                report['native_started'] = True
                report['worker_pid'] = process.pid
                report['peak_observed_worker_RSS_bytes'] = 0
                save()
                try:
                    while True:
                        available = helper.resources(output)
                        status = Path('/proc')/str(process.pid)/'status'
                        try:
                            text = status.read_text()
                            line = next((line for line in text.splitlines() if line.startswith('VmRSS:')), None)
                            rss = int(line.split()[1])*1024 if line else 0
                        except FileNotFoundError:
                            rss = 0
                        report['peak_observed_worker_RSS_bytes'] = max(report['peak_observed_worker_RSS_bytes'], rss)
                        remaining = deadline-time.monotonic()
                        if (remaining <= 0 or available['writeable_disk_bytes'] < MIN_DISK
                                or available['shared_unreclaimable_memory_bytes'] > MAX_SHARED or rss > RESERVE):
                            report['stop_event'] = {'resources': available, 'worker_RSS_bytes': rss,
                                                    'deadline_exhausted': remaining <= 0}
                            helper.stop(process, deadline)
                            code = 124 if remaining <= 0 else 125
                            break
                        try:
                            code = process.wait(timeout=min(.5, remaining))
                            break
                        except subprocess.TimeoutExpired:
                            continue
                except BaseException:
                    helper.stop(process, deadline)
                    raise
            report['worker_exit_code'] = code
            report['native_log_sha256'] = sha(output/'native.log')
            if code:
                raise ValueError('saved STEP readback returned '+str(code))
        after = guard.current_identity(ROOT, HEAD)
        report['identity_after'] = after
        if (after != report['identity_before'] or original_hashes() != WITNESSES
                or sha(__file__) != own_sha or sha(HELPER) != helper_sha or time.monotonic() >= deadline):
            raise ValueError('readback source/input/runtime changed or total budget expired')
        raw = json.loads((output/'readback.json').read_text())
        if not raw.get('readback_completed') or len(raw.get('rows', [])) != 4:
            raise ValueError('not all four original witnesses were read completely')
        report['raw_report_sha256'] = sha(output/'readback.json')
        report['readback_execution_checks_passed'] = True
    except BaseException as exc:
        if process is not None and process.poll() is None:
            helper.stop(process, deadline)
        report['execution_failure'] = type(exc).__name__+': '+str(exc)
    save()
    print(json.dumps({key: report.get(key) for key in (
        'native_started', 'readback_execution_checks_passed', 'worker_exit_code', 'execution_failure')}), flush=True)
    return 0 if report['readback_execution_checks_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
