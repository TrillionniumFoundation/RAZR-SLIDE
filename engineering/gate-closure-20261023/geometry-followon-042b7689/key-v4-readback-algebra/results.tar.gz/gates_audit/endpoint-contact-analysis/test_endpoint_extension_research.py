"""Focused pure regressions for the finite STEP-backed research helper.

Synthetic geometry here tests contracts; only test_actual_step_backed_analysis
reads the original STEP text. No test imports a CAD kernel or runs Common.
"""
from decimal import Decimal
import gzip
import importlib.util
import json
from pathlib import Path
import sys
import unittest

import endpoint_extension_research as research


class EndpointResearchTests(unittest.TestCase):
    def setUp(self):
        original = json.loads(gzip.decompress((research.ROOT /
            'engineering/thin-mechanism-20261015/native-verification.json.gz').read_bytes()))
        self.profile = original['sides']['R']['contacts'][0]['profile']
        self.floor = [-.0011145618, .3]

    def test_coupled_domain_rejects_independent_box_corner(self):
        a, b, half = research.constants()
        with self.assertRaises(ValueError):
            research.require_coupled_trial(-half, a)
        research.require_coupled_trial(-half, -a)
        self.assertAlmostEqual(abs(-a+half), b)

    def test_entire_negative_domain_is_retained_across_face_partition(self):
        a, b, half = research.constants()
        entire = research.coupled_domain(-half, 0.)
        near = research.coupled_domain(-.02, 0.)
        beyond = research.coupled_domain(-half, -.02)
        self.assertEqual(near['q_offset_interval_mm'][0], beyond['q_offset_interval_mm'][1])
        self.assertEqual(entire['q_offset_interval_mm'], [beyond['q_offset_interval_mm'][0], near['q_offset_interval_mm'][1]])
        for domain in (entire, near, beyond):
            self.assertTrue(domain['vertices_dq_dx_mm'])
            self.assertFalse(domain['complete_material_clearance_proved'])
            for q, x in domain['vertices_dq_dx_mm']:
                self.assertLessEqual(abs(x), a+1e-14)
                self.assertLessEqual(abs(x-q), b+1e-14)
        with self.assertRaises(ValueError):
            research.coupled_domain(-half-.001, 0.)

    def test_negative_floor_extension_does_not_claim_whole_pin_clear(self):
        value = research.extended_contact(self.profile, self.floor, -.001, 0., endpoint='STOW')
        self.assertAlmostEqual(value['height_mm'], self.profile['floor_height']+self.profile['pin_radius'])
        self.assertEqual(value['height_derivative'], 0.)
        self.assertFalse(value['whole_pin_and_complete_KEY_nonintersection_proved'])
        self.assertLess(value['entire_pin_q_projection_mm'][0], self.floor[0])

    def test_no_clamp_and_nonfinite_inputs_rejected(self):
        half = research.constants()[2]
        for q in (0., -half-.001, float('nan'), float('inf')):
            with self.subTest(q=q), self.assertRaises(ValueError):
                research.extended_contact(self.profile, self.floor, q, 0., endpoint='STOW')
        for field, value in (('pin_radius', -.1), ('floor_height', float('nan')), ('q_max', 0.)):
            with self.subTest(field=field), self.assertRaises(ValueError):
                research.extended_contact({**self.profile, field: value}, self.floor, -.001, 0., endpoint='STOW')

    def test_finite_floor_trim_and_order_are_enforced(self):
        for floor in ((-.001, .0005), (.3, -.001), (float('nan'), .3)):
            with self.subTest(floor=floor), self.assertRaises(ValueError):
                research.extended_contact(self.profile, floor, -.001, 0., endpoint='STOW')

    def test_open_extension_retains_selected_branch_without_force_claim(self):
        qmax = self.profile['q_max']
        value = research.extended_contact(self.profile, (), qmax+.001, 0., endpoint='OPEN')
        self.assertEqual(value['height_mm'], self.profile['lower_stop_height'])
        self.assertFalse(value['native_floor_contact_support_claimed'])
        self.assertFalse(value['physical_lower_stop_or_restoring_force_proved'])
        for q in (qmax, qmax+research.constants()[2]+.001):
            with self.subTest(q=q), self.assertRaises(ValueError):
                research.extended_contact(self.profile, (), q, 0., endpoint='OPEN')

    def test_all_edge_partition_handles_concavity_missed_by_corners(self):
        square = [(0., 0.), (4., 0.), (4., 4.), (0., 4.)]
        notched = [(0., 0.), (4., 0.), (4., 4.), (3., 4.), (3., 1.), (1., 1.), (1., 4.), (0., 4.)]
        self.assertTrue(all(research.inside(notched, *point) for point in square))
        actual = research.exact_decimal_projected_overlap(square, notched)
        self.assertEqual(Decimal(actual['nominal_decimal_area_mm2']), Decimal('10'))
        self.assertFalse(actual['solid_interior_or_contact_force_qualified'])

    def test_invalid_or_crossing_native_face_boundary_rejected(self):
        bad = [
            [(0., 0.), (2., 0.), (2., 2.), (0., 1.)],
            [(0., 0.), (2., 0.), (2., 2.), (0., 0.)],
            [(0., 0.), (4., 0.), (4., 4.), (2., 4.), (2., -1.), (0., -1.)],
        ]
        for polygon in bad:
            with self.subTest(polygon=polygon), self.assertRaises(ValueError):
                research.orthogonal_polygon(polygon)

    def test_complete_pin_envelope_contains_radius_and_finite_axis_extent(self):
        half = research.constants()[2]
        box = research.complete_pin_enclosure(self.profile, (-.6, -.2), (-half, 0.))
        self.assertAlmostEqual(box['q_mm'][0], self.profile['pin_q']-.1)
        self.assertAlmostEqual(box['q_mm'][1], self.profile['pin_q']+half+.1)
        self.assertEqual(box['e_mm'], [-.6, -.2])
        self.assertFalse(box['complete_KEY_Common_evaluated'])
        for profile in ({**self.profile, 'pin_radius': 0.}, {**self.profile, 'pin_q': float('nan')}):
            with self.assertRaises(ValueError):
                research.complete_pin_enclosure(profile, (-.6, -.2), (-half, 0.))

    def test_actual_step_backed_analysis_has_six_finite_patches_and_no_motion_claim(self):
        actual = research.build()
        patches = [row for row in actual['opposed_finite_material_faces']
            if Decimal(row['projected_finite_face_overlap']['nominal_decimal_area_mm2']) > 0]
        self.assertEqual(len(patches), 6)
        for side in 'LR':
            self.assertEqual(sorted(Decimal(row['projected_finite_face_overlap']['nominal_decimal_area_mm2'])
                for row in patches if row['side'] == side), [Decimal('.08'), Decimal('.08'), Decimal('.12')])
        self.assertEqual({row['nominal_decimal_face_separation_mm'] for row in patches}, {'0.02'})
        self.assertTrue(all(row['full_negative_slot_tangent_inside_finite_floor'] for row in actual['actual_finite_floor_contact_ranges']))
        for flag in ('full_scene_or_new_Common_executed', 'complete_product_motion_proved',
                     'global_KEY_hard_stop_proved', 'continuous_backlash_domain_proved',
                     'physical_qualification', 'original_four_profile_evaluate_edited'):
            self.assertFalse(actual[flag], flag)
        self.assertNotIn('cadquery', sys.modules)
        self.assertNotIn('OCP', sys.modules)

    def test_original_production_profiles_still_reject_outside_domain(self):
        path = research.ROOT/'integration/cam_contact_profile.py'
        spec = importlib.util.spec_from_file_location('unmodified_original_cam_contact_profile', path)
        original = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = original
        spec.loader.exec_module(original)
        keys = ('pin_radius', 'floor_height', 'floor_corner_q', 'ramp_slope', 'pin_q', 'lower_stop_height', 'q_max')
        profile = original.ContactProfile(**{key: self.profile[key] for key in keys})
        for q in (-.001, self.profile['q_max']+.001):
            with self.assertRaises(ValueError):
                profile.evaluate(q)


if __name__ == '__main__':
    unittest.main(verbosity=2)
