"""Finite STEP-backed endpoint contact algebra, not a production profile edit.

The whole coupled slot domain is retained. Opposed native faces partition its
STOW negative interval; that partition is not a complete material clearance
certificate. A full pin envelope is recorded explicitly so a floor tangent
point cannot be mistaken for a full pin/KEY collision proof.
"""
from __future__ import annotations
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import re
import sys
import tarfile

ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
HERE = Path(__file__).resolve().parent
HEAD = '042b768903cccbd7a0995317c8598401e0318e2a'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite(value):
    if type(value) not in (float, int) or not math.isfinite(value):
        raise ValueError('finite real scalar required')
    return float(value)


def constants():
    a = (.425-.4)*math.hypot(1., 12./79.75)
    b = (.425-.4)*math.sqrt(2.)
    return a, b, a+b


def _ordered_xz_polygon(table, face, text_reader):
    refs = text_reader.refs
    bounds = refs(table[face['STEP_face_entity']])[:-1]
    if len(bounds) != 1:
        raise ValueError('one complete native face loop required')
    loop = table[refs(table[bounds[0]])[0]]
    segments = []
    for oriented in refs(loop):
        edge = table[refs(table[oriented])[0]]
        er = refs(edge)
        endpoints = [text_reader.vector(table[refs(table[v])[0]]) for v in er[:2]]
        curve = table[er[2]]
        if curve.startswith(('SURFACE_CURVE(', 'SEAM_CURVE(')):
            curve = table[refs(curve)[0]]
        if not curve.startswith('LINE('):
            raise ValueError('the finite face boundary is not entirely straight')
        if table[oriented].rstrip().endswith('.F.)'):
            endpoints.reverse()
        segments.append([(p[0], p[2]) for p in endpoints])
    for current, following in zip(segments, segments[1:]+segments[:1]):
        if current[1] != following[0]:
            raise ValueError('native oriented face edges do not form a complete closed cycle')
    polygon = [a for a, _ in segments]
    orthogonal_polygon(polygon)
    return polygon


def orthogonal_polygon(polygon):
    if (len(polygon) < 4 or any(len(point) != 2 for point in polygon)
            or len({tuple(point) for point in polygon}) != len(polygon)):
        raise ValueError('complete unique polygon corners required')
    edges = list(zip(polygon, polygon[1:]+polygon[:1]))
    for a, b in edges:
        if any(type(v) not in (float, int) or not math.isfinite(v) for v in (*a, *b)) or ((a[0] == b[0]) == (a[1] == b[1])):
            raise ValueError('finite nonzero axis-aligned polygon edges required')
    for i, (a, b) in enumerate(edges):
        for j, (c, d) in enumerate(edges):
            if j <= i+1 or (i == 0 and j == len(edges)-1):
                continue
            if (max(min(a[0], b[0]), min(c[0], d[0])) <= min(max(a[0], b[0]), max(c[0], d[0]))
                    and max(min(a[1], b[1]), min(c[1], d[1])) <= min(max(a[1], b[1]), max(c[1], d[1]))):
                raise ValueError('a simple native face boundary is required; nonadjacent edges intersect')


def inside(polygon, x, z):
    odd = False
    for a, b in zip(polygon, polygon[1:]+polygon[:1]):
        if min(a[0], b[0]) <= x <= max(a[0], b[0]) and min(a[1], b[1]) <= z <= max(a[1], b[1]):
            if (a[0] == b[0] == x) or (a[1] == b[1] == z):
                return True
        if (a[1] > z) != (b[1] > z):
            if x < a[0]+(z-a[1])*(b[0]-a[0])/(b[1]-a[1]):
                odd = not odd
    return odd


def exact_decimal_projected_overlap(first, second):
    """Partition orthogonal faces at every edge coordinate, not sparse samples.

    Within each open Cartesian cell both polygon indicators are constant.
    Midpoint classification therefore accounts for the complete planar area.
    Decimal arithmetic describes the parsed nominal STEP coordinates only.
    """
    orthogonal_polygon(first)
    orthogonal_polygon(second)
    first = [tuple(Decimal(str(value)) for value in point) for point in first]
    second = [tuple(Decimal(str(value)) for value in point) for point in second]
    xs = sorted({point[0] for point in first+second})
    zs = sorted({point[1] for point in first+second})
    area = Decimal(0)
    cells = []
    for xa, xb in zip(xs, xs[1:]):
        for za, zb in zip(zs, zs[1:]):
            if inside(first, (xa+xb)/2, (za+zb)/2) and inside(second, (xa+xb)/2, (za+zb)/2):
                value = (xb-xa)*(zb-za)
                area += value
                cells.append({'x_mm': [float(xa), float(xb)], 'z_mm': [float(za), float(zb)], 'nominal_decimal_area_mm2': str(value)})
    return {'nominal_decimal_area_mm2': str(area), 'complete_cell_partition': cells,
            'entire_orthogonal_face_projection_accounted': True,
            'solid_interior_or_contact_force_qualified': False}


def coupled_domain(low, high):
    """Exact linear inequalities; ordinary floating vertices are descriptive."""
    low, high = finite(low), finite(high)
    if low > high:
        raise ValueError('ordered q offset interval required')
    a, b, half = constants()
    if low < -half-1e-15 or high > half+1e-15:
        raise ValueError('interval exceeds the original coupled slots')
    # Parameters (dq,dx): neither scalar bound replaces |dx-dq| <= b.
    constraints = [(1., 0., high), (-1., 0., -low), (0., 1., a), (0., -1., a),
                   (-1., 1., b), (1., -1., b)]
    vertices = []
    for first, second in itertools.combinations(constraints, 2):
        u, v, c = first
        r, s, t = second
        det = u*s-v*r
        if det == 0:
            continue
        q, x = (c*s-v*t)/det, (u*t-c*r)/det
        if all(i*q+j*x <= k+1e-15 for i, j, k in constraints):
            if not any(abs(q-p[0]) <= 1e-14 and abs(x-p[1]) <= 1e-14 for p in vertices):
                vertices.append([q, x])
    return {'q_offset_interval_mm': [low, high], 'parameter_order': ['dq', 'dx'],
            'linear_inequalities': [{'dq': i, 'dx': j, 'upper_mm': k} for i, j, k in constraints],
            'vertices_dq_dx_mm': sorted(vertices), 'coupled_slot_domain_retained': True,
            'complete_material_clearance_proved': False, 'physical_qualification': False}


def require_coupled_trial(q, dx):
    q, dx = finite(q), finite(dx)
    a, b, _ = constants()
    if abs(dx) > a+1e-15 or abs(dx-q) > b+1e-15:
        raise ValueError('outside original coupled groove inequalities')


def profile_numbers(profile, names):
    result = {name: finite(profile[name]) for name in names}
    for name in ('pin_radius', 'q_max'):
        if name in result and result[name] <= 0:
            raise ValueError('positive finite native radius and declared travel required')
    return result


def extended_contact(profile, floor_q, q, dx, *, endpoint):
    """Research values on bounded outside intervals; no clamp or material pass."""
    q, dx = finite(q), finite(dx)
    profile = profile_numbers(profile, ('pin_q', 'pin_radius', 'floor_height', 'q_max', 'lower_stop_height'))
    _, _, half = constants()
    if endpoint == 'STOW':
        if not -half <= q < 0.:
            raise ValueError('this extension only covers the declared negative endpoint interval')
        require_coupled_trial(q, dx)
        if len(floor_q) != 2:
            raise ValueError('two finite floor endpoints required')
        floor_q = [finite(value) for value in floor_q]
        if floor_q[0] >= floor_q[1]:
            raise ValueError('ordered finite floor endpoints required')
        relative_q = profile['pin_q']-q
        if not floor_q[0] <= relative_q <= floor_q[1]:
            raise ValueError('finite native floor tangent has left its trimmed face')
        radius = profile['pin_radius']
        return {'q_mm': q, 'height_mm': profile['floor_height']+radius, 'height_derivative': 0.,
                'research_branch': 'finite_native_plateau_extension', 'native_floor_tangent_q_mm': relative_q,
                'entire_pin_q_projection_mm': [relative_q-radius, relative_q+radius],
                'whole_pin_and_complete_KEY_nonintersection_proved': False,
                'all_other_participants_clearance_proved': False, 'physical_qualification': False}
    if endpoint == 'OPEN':
        offset = q-profile['q_max']
        if not 0. < offset <= half:
            raise ValueError('this extension only covers the declared positive OPEN endpoint interval')
        require_coupled_trial(offset, dx)
        return {'q_mm': q, 'height_mm': profile['lower_stop_height'], 'height_derivative': 0.,
                'research_branch': 'retained_selected_lower_stop_extension',
                'native_floor_contact_support_claimed': False,
                'physical_lower_stop_or_restoring_force_proved': False,
                'whole_pin_and_complete_KEY_nonintersection_proved': False,
                'all_other_participants_clearance_proved': False, 'physical_qualification': False}
    raise ValueError('only STOW or OPEN research endpoints are defined')


def complete_pin_enclosure(profile, pin_e, q_interval):
    low, high = map(finite, q_interval)
    e0, e1 = map(finite, pin_e)
    profile = profile_numbers(profile, ('pin_q', 'pin_radius', 'floor_height'))
    if low > high or e0 >= e1 or not -constants()[2] <= low <= high <= 0.:
        raise ValueError('ordered complete negative plateau pin envelope required')
    r = profile['pin_radius']
    center = profile['floor_height']+r
    return {'e_mm': [e0, e1], 'q_mm': [profile['pin_q']-high-r, profile['pin_q']-low+r],
            'r_mm': [center-r, center+r], 'complete_candidate_cylinder_material_enclosed': True,
            'conservative_box_not_actual_collision': True, 'complete_KEY_Common_evaluated': False}


def original_pin_face(side, index, profile, reader):
    metadata = ROOT/'engineering/mounted-mechanism-20261015/geometry-manifest.json'
    manifest = json.loads(metadata.read_text())
    member = f'{side}_STOP_{index}.step'
    entry = next(item for item in manifest['files'] if item['path'] == member)
    archive = metadata.parent/manifest['archive']
    with tarfile.open(archive, 'r:gz') as stream:
        data = stream.extractfile(member).read()
    if hashlib.sha256(data).hexdigest() != entry['sha256'] or len(data) != entry['bytes']:
        raise ValueError('original STOP STEP member differs')
    table, refs = reader.entities(data), reader.refs
    candidates = []
    for number, value in table.items():
        if not value.startswith('ADVANCED_FACE('):
            continue
        face_refs = refs(value)
        surface = table[face_refs[-1]]
        if not surface.startswith('CYLINDRICAL_SURFACE('):
            continue
        radius = float(re.search(r',\s*([^,()]+)\s*\)$', surface).group(1))
        placement = refs(table[refs(surface)[0]])
        location, axis = reader.vector(table[placement[0]]), reader.vector(table[placement[1]])
        sign = -1 if side == 'L' else 1
        q, r = location[1]-14.8, sign*location[0]-23.85
        if (abs(radius-profile['pin_radius']) > 1e-9 or abs(abs(axis[2])-1) > 1e-10
                or abs(q-profile['pin_q']) > 1e-9
                or abs(r-profile['floor_height']-profile['pin_radius']) > 1e-9):
            continue
        vertices = {}
        for bound in face_refs[:-1]:
            loop = table[refs(table[bound])[0]]
            for oriented in refs(loop):
                edge = table[refs(table[oriented])[0]]
                for vertex in refs(edge)[:2]:
                    point = reader.vector(table[refs(table[vertex])[0]])
                    vertices[vertex] = [point[2]-4.2, point[1]-14.8, sign*point[0]-23.85]
        points = list(vertices.values())
        if len(points) < 2:
            raise ValueError('complete native cylindrical face endpoints missing')
        e = [min(point[0] for point in points), max(point[0] for point in points)]
        if e[0] >= e[1]:
            raise ValueError('native pin cylinder has no finite axis extent')
        candidates.append({'STEP_face_entity': number, 'axis_xyz': axis, 'location_xyz': location,
                          'pin_radius_mm': radius, 'e_extent_mm': e, 'vertices_eqr_mm': points})
    if len(candidates) != 1:
        raise ValueError('one original finite pin cylinder matching the profile required')
    return {'archive': str(archive.relative_to(ROOT)), 'member': member, 'member_sha256': entry['sha256'],
            **candidates[0], 'full_cylinder_inside_complete_STOP_not_recomputed': True,
            'native_BRep_validity_not_recomputed': True}


def build():
    spec = importlib.util.spec_from_file_location('step_text_reader', HERE/'inspect_step_planes.py')
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    evidence = json.loads((HERE/'explicit-plane-text-diagnostic.json').read_text())
    if evidence['reader_sha256'] != sha(HERE/'inspect_step_planes.py'):
        raise ValueError('original STEP text reader identity changed')
    for name, digest in evidence['source_files_sha256'].items():
        if sha(ROOT/name) != digest:
            raise ValueError('original STEP/profile source changed: '+name)
    actual = []
    for item in evidence['selected_planar_faces']:
        with tarfile.open(ROOT/item['source'], 'r:gz') as stream:
            data = stream.extractfile(item['member']).read()
        if hashlib.sha256(data).hexdigest() != item['member_sha256']:
            raise ValueError('actual selected STEP bytes changed')
        table = reader.entities(data)
        faces = reader.planes(data)
        face_map = {face['STEP_face_entity']: face for face in faces}
        for face in item['faces']:
            if face_map.get(face['STEP_face_entity']) != face:
                raise ValueError('recorded plane data differ from the actual STEP bytes')
        actual.append((item, table))
    profile_path = ROOT/'engineering/thin-mechanism-20261015/native-verification.json.gz'
    original = json.loads(gzip.decompress(profile_path.read_bytes()))
    profiles = {side: [entry['profile'] for entry in original['sides'][side]['contacts']] for side in 'LR'}
    records = []
    for side in 'LR':
        key_item, key_table = next((item, table) for item, table in actual
            if item['member'] == side+'_KEY.step' and item.get('selection_coordinate_mm') == 14.75)
        if len(key_item['faces']) != 1:
            raise ValueError('one complete opposing KEY face required')
        key_face = key_item['faces'][0]
        key_polygon = _ordered_xz_polygon(key_table, key_face, reader)
        for role in ('CAP_0', 'ROOT_INNER'):
            fixed, table = next((item, table) for item, table in actual if item['member'] == side+'_'+role+'.step')
            for face in fixed['faces']:
                if face['face_same_sense'] == key_face['face_same_sense']:
                    raise ValueError('serialized opposed native face orientation differs')
                projected = exact_decimal_projected_overlap(key_polygon, _ordered_xz_polygon(table, face, reader))
                gap = Decimal(str(key_face['plane_location_xyz'][1]))-Decimal(str(face['plane_location_xyz'][1]))
                if gap <= 0:
                    raise ValueError('no positive nominal opposing-face separation')
                records.append({'side': side, 'moving': side+'_KEY', 'fixed': side+'_'+role,
                    'KEY_STEP_face_entity': key_face['STEP_face_entity'], 'fixed_STEP_face_entity': face['STEP_face_entity'],
                    'nominal_decimal_face_separation_mm': str(gap), 'coincident_face_KEY_offset_mm': str(-gap),
                    'projected_finite_face_overlap': projected, 'original_stopped_Common_pair_identity_recovered': False,
                    'complete_solid_nonpenetration_or_first_stop_proved': False})
    area_contacts = [row for row in records if Decimal(row['projected_finite_face_overlap']['nominal_decimal_area_mm2']) > 0]
    if len(area_contacts) != 6 or {row['nominal_decimal_face_separation_mm'] for row in area_contacts} != {'0.02'}:
        raise ValueError('actual complete opposed finite face patches differ')
    a, b, half = constants()
    floor_ranges = []
    envelopes = []
    for side in 'LR':
        for index, profile in enumerate(profiles[side]):
            item, _ = next((item, table) for item, table in actual
                if item['member'] == side+'_KEY.step' and item.get('feature') == 'original_KEY_floor_'+str(index))
            if len(item['faces']) != 1 or len(item['faces'][0]['trim_loops']) != 1:
                raise ValueError('one finite native floor and boundary required')
            loop = item['faces'][0]['trim_loops'][0]
            if not loop['all_trim_curves_are_explicit_LINE'] or len(loop['vertex_coordinates']) != 4:
                raise ValueError('complete native rectangular floor required')
            values = loop['vertex_bounds_xyz']
            floor = [values[1][0]-14.8, values[1][1]-14.8]
            # Read every actual native cylinder endpoint from the pinned STOP
            # STEP. This is still no new BRep/whole-solid containment test.
            pin = original_pin_face(side, index, profile, reader)
            pin_e = pin['e_extent_mm']
            q_range = [profile['pin_q']-floor[1], profile['pin_q']-floor[0]]
            tangent = [profile['pin_q'], profile['pin_q']+half]
            floor_ranges.append({'side': side, 'STOP': index, 'native_floor_q_interval_mm': floor,
                'contact_tangent_q_offset_interval_mm': q_range, 'full_negative_slot_contact_range_mm': tangent,
                'full_negative_slot_tangent_inside_finite_floor': floor[0] <= tangent[0] <= tangent[1] <= floor[1],
                'complete_pin_KEY_collision_proved_clear': False})
            envelopes.append({'side': side, 'STOP': index,
                'actual_original_pin_cylindrical_face': pin,
                'full_negative_slot_complete_pin_enclosure': complete_pin_enclosure(profile, pin_e, [-half, 0.]),
                'near_opposed_face_complete_pin_enclosure': complete_pin_enclosure(profile, pin_e, [-.02, 0.])})
    return {'schema': 'razr-native-endpoint-extension-research-algebra-v1', 'repository_head': HEAD,
        'source_files_sha256': evidence['source_files_sha256'],
        'actual_STEP_member_bytes_and_face_data_recomputed': True,
        'slot_halfwidths_mm': {'cam_dx': a, 'yoke_dx_minus_dq': b, 'unprojected_q': half},
        'STOW_entire_original_negative_slot_domain': coupled_domain(-half, 0.),
        'STOW_partition_near_opposed_finite_faces_not_yet_clear': coupled_domain(-.02, 0.),
        'STOW_partition_beyond_opposed_faces_retained_for_rejection_analysis': coupled_domain(-half, -.02),
        'OPEN_entire_original_positive_slot_domain': coupled_domain(0., half),
        'opposed_finite_material_faces': records, 'actual_finite_floor_contact_ranges': floor_ranges,
        'complete_pin_material_enclosures': envelopes,
        'whole_original_coupled_slot_domain_preserved': True,
        'original_four_profile_evaluate_edited': False, 'software_q_clamping_used': False,
        'only_a_tangent_point_is_not_complete_pin_clearance': True,
        'full_scene_or_new_Common_executed': False, 'complete_product_motion_proved': False,
        'global_KEY_hard_stop_proved': False, 'continuous_backlash_domain_proved': False,
        'physical_qualification': False, 'formal_directed_rounding_certificate': False,
        'next_computational_obligations': [
            'Native continuous complete pin/KEY and STOP remainder checks over both retained STOW partitions',
            'Continuous whole 154/161 material fields over the original coupled dq/dx polygons and independent controls',
            'OPEN finite groove/cap and complete material checks; selected lower-stop extension is not force support']}


def main():
    result = build()
    result['research_helper_sha256'] = sha(__file__)
    path = HERE/'endpoint-extension-research-report.json'
    path.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'report':str(path),'actual_STEP_backed_algebra_completed':True,
        'positive_area_opposed_face_patches':sum(Decimal(row['projected_finite_face_overlap']['nominal_decimal_area_mm2']) > 0
            for row in result['opposed_finite_material_faces']),
        'complete_product_motion_proved':False,'CAD_executed':False}))


if __name__ == '__main__':
    main()
