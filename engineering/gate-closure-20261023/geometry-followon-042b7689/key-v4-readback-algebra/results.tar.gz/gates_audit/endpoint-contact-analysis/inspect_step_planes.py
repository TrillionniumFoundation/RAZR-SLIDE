"""Read STEP text face/edge topology only; never import CAD or infer volume.

This limited reader records explicit PLANEs and LINE trim endpoints. It does
not validate a BRep, orient solid interiors, or identify saved Common pairs.
"""
from __future__ import annotations
import gzip
import hashlib
import json
from pathlib import Path
import re
import tarfile

ROOT = Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
OUTPUT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def entities(data):
    return {int(number): value.strip() for number, value in
            re.findall(r'#(\d+)\s*=\s*(.*?);', data.decode(), flags=re.S)}


def refs(entity):
    return [int(value) for value in re.findall(r'#(\d+)', entity)]


def vector(entity):
    values = re.search(r'\(\s*[^,]*,\s*\(([^()]*)\)\s*\)', entity)
    if not values:
        raise ValueError('unrecognized STEP point/vector')
    result = [float(v) for v in values.group(1).split(',')]
    if len(result) != 3:
        raise ValueError('three coordinate components required')
    return result


def planes(data):
    table = entities(data)
    result = []
    for number, entity in table.items():
        if not entity.startswith('ADVANCED_FACE('):
            continue
        face_refs = refs(entity)
        if not table[face_refs[-1]].startswith('PLANE('):
            continue
        axis = table[refs(table[face_refs[-1]])[0]]
        placement = refs(axis)
        location = vector(table[placement[0]])
        normal = vector(table[placement[1]])
        loops = []
        for bound in face_refs[:-1]:
            loop = table[refs(table[bound])[0]]
            if not loop.startswith('EDGE_LOOP('):
                raise ValueError('non-edge face trim')
            vertices = {}
            curves = []
            for oriented in refs(loop):
                edge = table[refs(table[oriented])[0]]
                edge_refs = refs(edge)
                for vertex in edge_refs[:2]:
                    vertices[vertex] = vector(table[refs(table[vertex])[0]])
                curve = table[edge_refs[2]]
                if curve.startswith(('SURFACE_CURVE(', 'SEAM_CURVE(')):
                    curve = table[refs(curve)[0]]
                curves.append(curve.split('(', 1)[0])
            points = list(vertices.values())
            loops.append({'vertex_coordinates': points,
                          'vertex_bounds_xyz': [[min(v[i] for v in points), max(v[i] for v in points)] for i in range(3)],
                          'edge_curve_types': curves,
                          'all_trim_curves_are_explicit_LINE': all(value == 'LINE' for value in curves)})
        result.append({'STEP_face_entity': number, 'plane_location_xyz': location, 'plane_axis_xyz': normal,
                       'face_same_sense': entity.rstrip().endswith('.T.)'), 'trim_loops': loops})
    return result


def main():
    mounted_path = ROOT/'engineering/mounted-mechanism-20261015/geometry-manifest.json'
    mounted = json.loads(mounted_path.read_text())
    mounted_archive = mounted_path.parent/mounted['archive']
    assert sha(mounted_archive.read_bytes()) == mounted['archive_sha256']
    source_files = {str(mounted_path.relative_to(ROOT)): sha(mounted_path.read_bytes()),
                    str(mounted_archive.relative_to(ROOT)): mounted['archive_sha256']}
    entries = {item['path']: item for item in mounted['files']}
    selected = []
    with tarfile.open(mounted_archive, 'r:gz') as archive:
        for side in 'LR':
            for role, axis, coordinate in (('CAP_0', 1, 14.73), ('KEY', 1, 14.75)):
                member = side+'_'+role+'.step'
                data = archive.extractfile(member).read()
                assert sha(data) == entries[member]['sha256'] and len(data) == entries[member]['bytes']
                faces = planes(data)
                selected.append({'source': str(mounted_archive.relative_to(ROOT)), 'member': member,
                    'member_sha256': sha(data), 'selection_axis': axis, 'selection_coordinate_mm': coordinate,
                    'faces': [face for face in faces if abs(abs(face['plane_axis_xyz'][axis])-1) < 1e-10
                              and abs(face['plane_location_xyz'][axis]-coordinate) < 1e-9]})
                if role == 'KEY':
                    sign = -1 if side == 'L' else 1
                    for index, floor in enumerate((1.04, 6.04)):
                        candidates = [face for face in faces if abs(abs(face['plane_axis_xyz'][0])-1) < 1e-10
                                      and abs(sign*face['plane_location_xyz'][0]-23.85-floor) < 1e-9]
                        selected.append({'source': str(mounted_archive.relative_to(ROOT)), 'member': member,
                            'member_sha256': sha(data), 'feature': 'original_KEY_floor_'+str(index),
                            'faces': candidates})
    config_path = ROOT/'design/product_geometry.json'
    config = json.loads(config_path.read_text())
    native = config['native_baseline']
    archive_path = ROOT/native['archive']
    assert sha(archive_path.read_bytes()) == native['sha256']
    source_files[str(config_path.relative_to(ROOT))] = sha(config_path.read_bytes())
    source_files[native['archive']] = native['sha256']
    with tarfile.open(archive_path, 'r:gz') as archive:
        manifest_data = archive.extractfile('manifest.json').read()
        manifest = json.loads(manifest_data)
        for side in 'LR':
            role = side+'_ROOT_INNER'
            entry = manifest['exports'][role]
            data = archive.extractfile(entry['path']).read()
            assert sha(data) == entry['sha256']
            selected.append({'source': native['archive'], 'manifest_member_sha256': sha(manifest_data),
                'member': entry['path'], 'member_sha256': sha(data), 'selection_axis': 1, 'selection_coordinate_mm': 14.73,
                'faces': [face for face in planes(data) if abs(abs(face['plane_axis_xyz'][1])-1) < 1e-10
                          and abs(face['plane_location_xyz'][1]-14.73) < 1e-9]})
    profile_path = ROOT/'engineering/thin-mechanism-20261015/native-verification.json.gz'
    profile_data = json.loads(gzip.decompress(profile_path.read_bytes()))
    source_files[str(profile_path.relative_to(ROOT))] = sha(profile_path.read_bytes())
    result = {'schema': 'razr-STEP-explicit-plane-text-diagnostic-v1', 'reader_sha256': sha(Path(__file__).read_bytes()),
        'repository_head': '042b768903cccbd7a0995317c8598401e0318e2a', 'source_files_sha256': source_files,
        'source_archives_and_selected_members_matched_original_sha256': True,
        'profiles': {side: [entry['profile'] for entry in profile_data['sides'][side]['contacts']] for side in 'LR'},
        'selected_planar_faces': selected, 'CAD_executed': False, 'BRep_validity_or_volume_verified': False,
        'original_Common_pair_identity_recovered': False, 'continuous_backlash_domain_proved': False,
        'global_KEY_hard_stop_proved': False, 'physical_qualification': False}
    (OUTPUT/'explicit-plane-text-diagnostic.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'selected_feature_groups':len(selected),'explicit_plane_count':sum(len(x['faces']) for x in selected),
                      'CAD_executed':False,'output':str(OUTPUT/'explicit-plane-text-diagnostic.json')}))


if __name__ == '__main__':
    main()
