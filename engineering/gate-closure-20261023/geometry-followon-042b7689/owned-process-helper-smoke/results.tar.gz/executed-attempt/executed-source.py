"""One bounded stdlib child exercises the frozen production-candidate helper.

No CAD/FE, native guard changes, other procfs scans, or automatic retries.
The child alone has a 128 MiB address-space cap and a <32 MiB RSS target.
"""
from __future__ import annotations

import argparse
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import traceback


EXPECTED_HELPER = 'db92c8ceb3c39cd5843d96d042f0202915937abdc2a919d5854e71de4a4c0b25'
MIB = 1024**2


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_helper(path):
    path = path.resolve()
    require(path.is_file() and not path.is_symlink(), 'regular frozen helper required')
    require(sha(path) == EXPECTED_HELPER, 'actual helper differs from frozen SHA')
    spec = importlib.util.spec_from_file_location('owned_process_smoke_actual_helper', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == path, 'actual helper module path differs')
    return module


def fd_closed(fd):
    try:
        os.fstat(fd)
    except OSError as exc:
        if exc.errno == errno.EBADF:
            return True
        raise
    return False


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (128*MIB, 128*MIB))
    resource.setrlimit(resource.RLIMIT_CPU, (2, 2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def child(helper_path):
    started = time.monotonic()
    helper = load_helper(helper_path)
    inherited = [int(os.environ[helper.READY_FD]), int(os.environ[helper.RELEASE_FD])]
    helper.announce_worker_from_environment(Path(__file__))
    # A short bounded lifetime permits a second parent-side actual sample after
    # the helper's identity/memory-verified release. No allocation workload.
    time.sleep(.15)
    record = {
        'kind': 'actual_owned_process_helper_smoke_child_finished',
        'helper_sha256': sha(helper_path),
        'worker_source_sha256': sha(__file__),
        'isolated_python': bool(sys.flags.isolated),
        'no_site': bool(sys.flags.no_site),
        'address_space_limit': list(resource.getrlimit(resource.RLIMIT_AS)),
        'identity': helper.own_identity(),
        'inherited_channel_FDs': inherited,
        'inherited_channel_FDs_closed': all(fd_closed(fd) for fd in inherited),
        'self_ru_maxrss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        'elapsed_seconds': time.monotonic()-started,
    }
    print(json.dumps(record, sort_keys=True, allow_nan=False), flush=True)
    require(record['inherited_channel_FDs_closed'], 'worker inherited pipe descriptors remain open')
    require(record['self_ru_maxrss_bytes'] < 32*MIB, 'worker RSS target exceeded')
    return 0


def stop_and_reap(process, deadline, report):
    if process.poll() is None:
        report['terminate_requested'] = True
        try:
            process.terminate()
        except ProcessLookupError:
            report['terminate_exit_race'] = True
    try:
        return process.wait(timeout=max(.01, min(.4, deadline-time.monotonic())))
    except subprocess.TimeoutExpired:
        report['kill_requested'] = True
        try:
            process.kill()
        except ProcessLookupError:
            report['kill_exit_race'] = True
        return process.wait(timeout=max(.01, deadline-time.monotonic()))


def parent(helper_path, output):
    started = time.monotonic()
    deadline = started+9.
    require(not output.exists(), 'one fresh output directory; this command never retries')
    output.mkdir(parents=True)
    source = Path(__file__).resolve()
    helper_path = helper_path.resolve()
    report = {
        'schema': 'razr-frozen-owned-process-helper-single-stdlib-smoke-v1',
        'helper_path': str(helper_path), 'helper_sha256_before': sha(helper_path),
        'source_sha256_before': sha(source),
        'one_child_only': True, 'child_count': 0,
        'child_AS_limit_bytes': 128*MIB, 'child_RSS_target_bytes': 32*MIB,
        'wall_budget_seconds': 9, 'child_CPU_limit_seconds': 2,
        'CAD_or_FE_executed': False, 'native_guard_modified': False,
        'unrelated_proc_entries_opened_or_scanned': False,
        'privileges_or_access_controls_changed': False,
        'diagnostic_passed': False, 'child_started': False, 'child_reaped': False,
    }
    (output/'executed-source.py').write_bytes(source.read_bytes())
    (output/'executed-owned_process.py').write_bytes(helper_path.read_bytes())
    stdout_path, stderr_path = output/'child-stdout.log', output/'child-stderr.log'
    process = channel = None
    channel_fds = set()
    try:
        helper = load_helper(helper_path)
        channel = helper.OwnedChildChannel(source)
        channel_fds = set(channel.descriptors)
        report['parent_identity'] = channel.parent
        report['channel_FDs'] = sorted(channel_fds)
        command = [sys.executable, '-I', '-S', '-B', str(source), '--child',
                   '--helper', str(helper_path)]
        report['child_argv'] = command
        report['working_directory'] = str(output)
        env = channel.child_env({**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
            process = subprocess.Popen(command, cwd=output, env=env, stdout=stdout, stderr=stderr,
                                       pass_fds=channel.pass_fds, preexec_fn=limits, start_new_session=True)
            report.update(child_started=True, child_count=1, Popen_namespace_pid=process.pid)
            channel.after_spawn()

            def budget(memory=None):
                require(time.monotonic() < deadline-.5, 'smoke total wall budget exhausted')
                if memory is not None:
                    require(0 < memory['VmRSS'] <= memory['VmHWM'] < 32*MIB,
                            'actual helper sample exceeded the smoke RSS target')

            report['handshake'] = channel.accept(process, timeout_seconds=4, poll_callback=budget)
            report['post_release_memory'] = channel.sample(process)
            budget(report['post_release_memory'])
            report['child_exit_code'] = process.wait(timeout=max(.01, deadline-time.monotonic()))
            report['child_reaped'] = process.returncode is not None
        require(report['child_exit_code'] == 0, 'stdlib child did not exit successfully')
        lines = stdout_path.read_text().splitlines()
        require(len(lines) == 1, 'exactly one child completion record required')
        result = json.loads(lines[0])
        report['child_completion'] = result
        require(result['helper_sha256'] == EXPECTED_HELPER and result['worker_source_sha256'] == sha(source),
                'child executed different helper or smoke source')
        require(result['isolated_python'] is True and result['no_site'] is True,
                'isolated no-site child required')
        require(result['address_space_limit'] == [128*MIB, 128*MIB], 'child AS limit differs')
        require(result['inherited_channel_FDs_closed'] is True, 'worker did not close its inherited pipe FDs')
        require(0 < result['self_ru_maxrss_bytes'] < 32*MIB, 'final child self RSS target failed')
        packet = report['handshake']['packet']
        for key in ('os_getpid', 'os_getppid', 'proc_self_visible_pid', 'status', 'stat',
                    'pid_namespace', 'pid_for_children_namespace'):
            require(result['identity'][key] == packet[key], 'child completion identity changed: '+key)
        require(stderr_path.read_bytes() == b'', 'child stderr is not empty')
        report['all_success_checks_before_final_cleanup'] = True
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
    finally:
        if process is not None:
            try:
                report['child_exit_code'] = stop_and_reap(process, deadline, report)
                report['child_reaped'] = process.returncode is not None
            except BaseException as exc:
                report['cleanup_failure'] = type(exc).__name__+': '+str(exc)
        if channel is not None:
            try:
                channel.close()
                report['channel_internal_FD_set_empty'] = not channel.descriptors
                report['all_parent_channel_FDs_closed'] = all(fd_closed(fd) for fd in channel_fds)
            except BaseException as exc:
                report['FD_cleanup_failure'] = type(exc).__name__+': '+str(exc)
        report['elapsed_seconds'] = time.monotonic()-started
        report['helper_sha256_after'] = sha(helper_path)
        report['source_sha256_after'] = sha(source)
        report['source_bytes_unchanged'] = (report['helper_sha256_after'] == report['helper_sha256_before'] == EXPECTED_HELPER
                                          and report['source_sha256_after'] == report['source_sha256_before'])
        report['streams'] = {path.name: {'exists': path.exists(), 'bytes': path.stat().st_size if path.exists() else None,
                                       'sha256': sha(path) if path.exists() else None}
                             for path in (stdout_path, stderr_path)}
        report['diagnostic_passed'] = bool(
            report.get('all_success_checks_before_final_cleanup') and report['source_bytes_unchanged']
            and report['child_reaped'] and report.get('all_parent_channel_FDs_closed')
            and report.get('channel_internal_FD_set_empty') and report['child_count'] == 1
            and report['elapsed_seconds'] < 9 and not any(
                key in report for key in ('failure', 'cleanup_failure', 'FD_cleanup_failure')))
        (output/'result.json').write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps({key: report.get(key) for key in ('diagnostic_passed', 'child_count', 'child_exit_code',
          'child_reaped', 'elapsed_seconds', 'post_release_memory', 'failure')}), flush=True)
    return 0 if report['diagnostic_passed'] else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--helper', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--child', action='store_true')
    args = parser.parse_args()
    if args.child:
        return child(args.helper)
    require(args.output is not None, 'parent output directory required')
    return parent(args.helper, args.output)


if __name__ == '__main__':
    raise SystemExit(main())
