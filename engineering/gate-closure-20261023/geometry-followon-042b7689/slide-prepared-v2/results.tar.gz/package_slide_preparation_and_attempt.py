"""Read frozen SLIDE evidence and package it; never execute the native worker."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile


BASE = Path('/workspace/scratch/95cd2986fdf2')
ROOT = BASE/'RAZR-SLIDE'
HEAD = '042b768903cccbd7a0995317c8598401e0318e2a'
PREP = BASE/'g2_slide/prepared-v2'
ATTEMPT = Path('/tmp/razr-slide-042b7689-attempt1')
REVIEW = BASE/'input_recovery/g2_slide/reviews/native-runner-independent-source-review.json'
OUT = BASE/'ci_audit/slide-prepared-v2-and-attempt1-delivery'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    require(not OUT.exists(), 'a new release bundle directory is required')
    sources = read(PREP/'executed-source-manifest.json')['sources']
    require(len(sources) == 12 and len({row['path'] for row in sources}) == 12,
            'exact 11 native-closure sources and one preparation harness required')
    original_hashes = {}
    layout = []
    for row in sources:
        path = Path(row['path'])
        require(path.is_relative_to(BASE), 'unexpected source path')
        require(sha(path) == row['sha256'] == sha(PREP/row['copy']),
                'current source or executed byte copy differs from preparation')
        original_hashes[str(path)] = row['sha256']
        layout.append({'original_absolute_path': str(path),
                       'workspace_relative_path': str(path.relative_to(BASE)),
                       'archive_member': 'prepared-v2/'+row['copy'],
                       'sha256': row['sha256']})
    native_sources = {key: value for key, value in original_hashes.items()
                      if key != str(BASE/'ci_audit/run_slide_preparation.py')}
    require(len(native_sources) == 11, 'native source closure count mismatch')
    index = read(PREP/'EVIDENCE_INDEX.json')
    for row in index['files']:
        path = PREP/row['path']
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                'preparation evidence index mismatch')
    actual_prep_files = {str(p.relative_to(PREP)) for p in PREP.rglob('*') if p.is_file()}
    require(actual_prep_files == {row['path'] for row in index['files']} | {'EVIDENCE_INDEX.json'},
            'unindexed or missing preparation evidence')
    prep = read(PREP/'arithmetic-preparation-report.json')
    require(prep['functional_commit'] == HEAD and prep['tests_run'] == 27
            and len(set(prep['test_ids'])) == 27, 'preparation test count or HEAD mismatch')
    require(all(prep[key] == 0 for key in ('failures', 'errors', 'skipped',
            'expected_failures', 'unexpected_successes')), 'preparation test failure')
    require(prep['arithmetic_preparation_checks_passed'] is True
            and prep['source_and_runtime_unchanged'] is True
            and prep['CAD_imported'] is False and prep['native_execution_started'] is False,
            'preparation scope mismatch')
    require(prep['scratch_source_sha256_before'] == prep['scratch_source_sha256_after']
            == native_sources, 'preparation source closure mismatch')
    before = prep['repository_and_environment_before']
    require(before == prep['repository_and_environment_after'], 'preparation identity changed')
    require(before['repository_head'] == HEAD and before['executed_source_overlay'] is False
            and before['environment']['passed'] is True
            and before['environment']['checked_package_count'] == 43,
            'original preparation source/lock qualification missing')
    external = read(REVIEW)
    require(external['source_sha256_before'] == external['source_sha256_after'] == native_sources
            and external['sources_unchanged'] is True
            and external['new_blocking_defect_found'] is False
            and external['CAD_imported'] is False
            and external['native_execution_performed'] is False,
            'independent source review closure mismatch')
    controller = read(ATTEMPT/'controller.json')
    require(controller['expected_head'] == HEAD
            and controller['scratch_source_sha256_before'] == native_sources,
            'actual attempt source closure mismatch')
    require(controller['worker_started'] is False and controller['resource_start_refused'] is True
            and controller['completed'] is False and 'worker_pid' not in controller,
            'attempt did not stop before worker startup')
    require({str(p.relative_to(ATTEMPT)) for p in ATTEMPT.rglob('*') if p.is_file()}
            == {'controller.json'}, 'unexpected worker output exists')
    require(len(controller['resource_observations']) == 1, 'unexpected resource execution history')
    observation = controller['resource_observations'][0]
    additional = controller['startup_estimated_additional_memory_reserve_MiB']*2**20
    shared_limit = controller['shared_unreclaimable_limit_GiB']*2**30
    require(controller['hard_wall_limit_seconds'] == 1800
            and controller['worker_peak_RSS_limit_MiB'] == 1536
            and controller['startup_estimated_additional_memory_reserve_MiB'] == 1536
            and controller['shared_unreclaimable_limit_GiB'] == 6.8
            and controller['startup_ordinary_disk_reserve_MiB'] == 200
            and controller['ordinary_disk_reserve_MiB'] == 100, 'original budgets changed')
    require(observation['f_bavail_bytes'] >= 200*2**20
            and observation['estimated_unreclaimable_bytes']+additional > shared_limit,
            'recorded resource condition does not explain startup refusal')
    false_flags = ('hosted_execution', 'canonical_execution_checks_passed',
                   'complete_G2_qualification', 'whole_declared_slide_domain_clear',
                   'physical_qualification', 'candidate_go', 'fixture_fabrication_go',
                   'manufacturing_go', 'formal_directed_rounding_certificate')
    require(all(controller[key] is False for key in false_flags), 'qualification scope inflated')
    head_now = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    status_now = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'], text=True)
    require(head_now == HEAD and not status_now.strip(), 'repository no longer frozen at expected HEAD')
    OUT.mkdir()
    payload = OUT/'payload'
    payload.mkdir()
    shutil.copytree(PREP, payload/'prepared-v2')
    (payload/'attempt1').mkdir()
    shutil.copy2(ATTEMPT/'controller.json', payload/'attempt1/controller.json')
    (payload/'reviews').mkdir()
    shutil.copy2(REVIEW, payload/'reviews/native-runner-independent-source-review.json')
    review = {
        'schema': 'razr-slide-start-refusal-independent-review-v1',
        'reviewed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'repository_head': HEAD,
        'original_controller': str(ATTEMPT/'controller.json'),
        'original_controller_sha256': sha(ATTEMPT/'controller.json'),
        'original_controller_source_sha256': native_sources[str(BASE/'g2_slide/supervise_slide_native.py')],
        'observed_single_attempt_status': 'not_started_resource_preflight_refused',
        'controller_branch_return_code': 3,
        'worker_started': False, 'worker_PID_recorded': False,
        'native_report_or_log_exists': False,
        'native_execution_performed': False,
        'recorded_resource_observation': observation,
        'startup_additional_memory_bytes': additional,
        'startup_combined_memory_bytes': observation['estimated_unreclaimable_bytes']+additional,
        'original_shared_memory_limit_bytes': shared_limit,
        'startup_disk_condition_passed': True,
        'startup_memory_condition_passed': False,
        'all_11_attempt_sources_equal_frozen_prepared_sources_and_current_bytes': True,
        'all_12_preparation_sources_equal_executed_copies': True,
        'preparation_tests_executed': 27,
        'preparation_tests_passed': 27,
        'preparation_test_data_are_synthetic_or_arithmetic': True,
        'original_preparation_43_lock_and_source_identity_checks_passed': True,
        'native_worker_environment_or_geometry_checks_executed_by_attempt': False,
        'current_head_and_clean_worktree_independently_observed': True,
        'independent_review_imported_CAD_or_reran_tests': False,
        'native_result_or_continuous_domain_clearance_inferred': False,
        **{key: False for key in false_flags},
        'limitation': 'The controller stopped before starting its worker. Preparation tests and source review do not prove native SLIDE clearance.'}
    write(payload/'reviews/attempt1-start-refusal-independent-review.json', review)
    write(payload/'SOURCE_LAYOUT.json', {'schema': 'razr-slide-executed-source-layout-v1',
                                        'repository_dependency_commit': HEAD,
                                        'native_source_count': 11,
                                        'additional_preparation_harness_count': 1,
                                        'sources': layout})
    summary = {
        'schema': 'razr-slide-preparation-and-start-refusal-delivery-v1',
        'repository_head': HEAD,
        'scope': read(PREP/'SUMMARY.json')['scope'],
        'prepared_v2': {'actual_tests_run': 27, 'passed': 27, 'failures': 0, 'errors': 0,
                        'skips': 0, 'elapsed_seconds': prep['elapsed_seconds'],
                        'peak_RSS_KiB': prep['peak_RSS_KiB'],
                        'native_source_count': 11, 'harness_source_count': 1,
                        'native_execution_started': False,
                        'counted_in_repository_1558_unit_tests': False},
        'unique_actual_controller_attempt': {'status': 'not_started_resource_preflight_refused',
                                             'worker_started': False,
                                             'native_completed_pair_count': 0,
                                             'cause': 'recorded shared memory plus original 1536 MiB startup reserve exceeded original 6.8 GiB limit'},
        'native_execution_performed': False,
        'whole_declared_slide_external_pair_domain_clear': False,
        **{key: False for key in false_flags},
        'raw_evidence': ['prepared-v2/arithmetic-preparation-report.json',
                         'prepared-v2/arithmetic-tests.log',
                         'prepared-v2/executed-source-manifest.json',
                         'attempt1/controller.json'],
        'independent_reviews': ['reviews/native-runner-independent-source-review.json',
                                'reviews/attempt1-start-refusal-independent-review.json'],
        'source_bytes_layout': 'SOURCE_LAYOUT.json',
        'excluded_payloads': 'No K/H/C matrices or production matrix payloads are included.'}
    write(payload/'SUMMARY.json', summary)
    shutil.copy2(Path(__file__), payload/'package_slide_preparation_and_attempt.py')
    files = [{'path': str(p.relative_to(payload)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(payload.rglob('*')) if p.is_file()]
    write(payload/'EVIDENCE_INDEX.json', {'schema': 'razr-slide-delivery-member-index-v1', 'files': files})
    archived_files = [{'path': str(p.relative_to(payload)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                      for p in sorted(payload.rglob('*')) if p.is_file()]
    archive = OUT/'slide-prepared-v2-and-attempt1-042b7689.tar.gz'
    with tarfile.open(archive, 'w:gz') as stream:
        for row in archived_files:
            stream.add(payload/row['path'], arcname=row['path'], recursive=False)
    expected = {row['path']: row for row in archived_files}
    with tarfile.open(archive, 'r:gz') as stream:
        members = stream.getmembers()
        require(len(members) == len(expected) and len({m.name for m in members}) == len(members),
                'archive member count mismatch')
        for member in members:
            require(member.isfile() and member.name in expected, 'unexpected tar member')
            data = stream.extractfile(member).read()
            require(len(data) == expected[member.name]['bytes']
                    and hashlib.sha256(data).hexdigest() == expected[member.name]['sha256'],
                    'archive member readback mismatch')
    require(all(sha(path) == digest for path, digest in original_hashes.items()),
            'source changed during packaging')
    delivery = {'schema': 'razr-slide-release-delivery-index-v1', 'repository_head': HEAD,
                'archive': str(archive), 'archive_bytes': archive.stat().st_size,
                'archive_sha256': sha(archive), 'archive_member_count': len(archived_files),
                'all_members_readback_sha256_verified': True,
                'suggested_repository_path': 'engineering/gate-closure-20261023/slide-preparation/slide-prepared-v2-and-attempt1-042b7689.tar.gz',
                'summary': str(payload/'SUMMARY.json'), 'summary_sha256': sha(payload/'SUMMARY.json'),
                'members': archived_files, 'native_execution_performed': False,
                'canonical_execution_checks_passed': False, 'complete_G2_qualification': False}
    write(OUT/'DELIVERY_INDEX.json', delivery)
    print(json.dumps({key: delivery[key] for key in ('archive', 'archive_bytes', 'archive_sha256',
                     'archive_member_count', 'all_members_readback_sha256_verified')}, indent=2))


if __name__ == '__main__':
    main()
