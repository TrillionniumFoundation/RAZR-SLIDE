"""Freeze and run only pure SLIDE contracts; native/CAD execution is forbidden."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import resource
import sys
import time
import unittest

BASE = Path('/workspace/scratch/95cd2986fdf2/g2_slide')
sys.path.insert(0, str(BASE))
import verify_slide_native as worker


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=BASE/'prepared-v2')
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(exist_ok=False)
    before = worker.source_identity()
    current = worker.evidence.postguard.current_identity(worker.ROOT, worker.DEFAULT_HEAD)
    source_copy = output/'executed-source-bytes'
    source_copy.mkdir()
    manifest = []
    all_sources = {**before, str(Path(__file__).resolve()): worker.sha(__file__)}
    for index, (path, digest) in enumerate(sorted(all_sources.items())):
        target = source_copy/(str(index).zfill(2)+'-'+Path(path).name)
        target.write_bytes(Path(path).read_bytes())
        worker.evidence.require(worker.sha(target) == digest, 'copied source bytes changed')
        manifest.append({'path': path, 'sha256': digest, 'copy': str(target.relative_to(output))})
    worker.atomic_json(output/'executed-source-manifest.json', {'sources': manifest})
    worker.atomic_json(output/'runner-preparation.json', worker.preparation(worker.DEFAULT_HEAD))
    suite = unittest.defaultTestLoader.discover(str(BASE), pattern='test_slide*.py')
    def ids(tests):
        result = []
        for item in tests:
            result.extend(ids(item) if isinstance(item, unittest.TestSuite) else [item.id()])
        return result
    test_ids = ids(suite)
    started = time.monotonic()
    with (output/'arithmetic-tests.log').open('w') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    elapsed = time.monotonic()-started
    after = worker.source_identity()
    current_after = worker.evidence.postguard.current_identity(worker.ROOT, worker.DEFAULT_HEAD)
    CAD = any(name == 'cadquery' or name == 'OCP' or name.startswith('OCP.') for name in sys.modules)
    receipt = {'schema': 'razr-slide-source-bound-arithmetic-preparation-v1',
               'functional_commit': worker.DEFAULT_HEAD,
               'tests_run': result.testsRun, 'test_ids': test_ids,
               'failures': len(result.failures), 'errors': len(result.errors),
               'skipped': len(result.skipped), 'expected_failures': len(result.expectedFailures),
               'unexpected_successes': len(result.unexpectedSuccesses),
               'elapsed_seconds': elapsed, 'peak_RSS_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               'scratch_source_sha256_before': before, 'scratch_source_sha256_after': after,
               'repository_and_environment_before': current, 'repository_and_environment_after': current_after,
               'source_and_runtime_unchanged': before == after and current == current_after
                    and all(worker.sha(path) == digest for path, digest in all_sources.items()),
               'CAD_imported': CAD, 'native_execution_started': False,
               'test_data_for_raw_clear_records_are_synthetic': True,
               'new_tests_added_to_current_1558_repository_suite_count': False,
               'complete_external_pair_native_clearance_proved': False,
               **{key: False for key in worker.evidence.FALSE_FLAGS}}
    receipt['arithmetic_preparation_checks_passed'] = bool(result.wasSuccessful() and result.testsRun == len(test_ids)
        and len(test_ids) == len(set(test_ids)) and not result.skipped and not result.expectedFailures
        and not result.unexpectedSuccesses and receipt['source_and_runtime_unchanged'] and not CAD)
    worker.atomic_json(output/'arithmetic-preparation-report.json', receipt)
    print(json.dumps({key: receipt[key] for key in ('tests_run', 'elapsed_seconds', 'peak_RSS_KiB',
          'arithmetic_preparation_checks_passed', 'CAD_imported', 'native_execution_started')}))
    return 0 if receipt['arithmetic_preparation_checks_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
