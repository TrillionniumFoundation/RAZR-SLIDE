"""Seal the reviewed small SEATING r3 code/evidence bundle, without native work."""
from __future__ import annotations

import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path('/workspace/scratch/95cd2986fdf2')
SOURCE = BASE/'input_recovery/g2_seating_v3'
OUTPUT = BASE/'input_recovery/seating-r3-owned-process-delivery-042b7689'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def main():
    assert not OUTPUT.exists()
    manifest_path = SOURCE/'prepared-v3/executed-source-manifest.json'
    assert sha(manifest_path) == '1c0c613e8f44b7488c5f7a02fa6cb4d570d5ae3721bfd24e5568b0d1a17a5d44'
    source_manifest = json.loads(manifest_path.read_text())
    for name, record in source_manifest.items():
        assert sha(SOURCE/name) == record['sha256'] == sha(Path(record['preserved_source_path']))
    report_path = SOURCE/'prepared-v3/arithmetic-tests-report.json'
    report = json.loads(report_path.read_text())
    assert sha(report_path) == '8046f55160fb87af78d838737caa5890ad2f6246909554397bc344810a393f1b'
    assert report['passed'] is True and report['test_count'] == 50 and report['CAD_imported'] is False
    review = BASE/'ci_audit/seating-r3-owned-process-integration-independent-review.json'
    assert sha(review) == 'cc9fc8f698292fc6d0f00500e2f48d4fa6734daea2f27674401d0d573d282847'
    smoke = BASE/'gates_audit/owned-process-helper-smoke'
    assert sha(smoke/'executed-attempt/result.json') == 'a5b492e2e19149da985218294bee8b04082ebde41ac3ac0f91c2808269e3f577'
    original_bundle = BASE/'input_recovery/seating-checkpoint-delivery-042b7689-r2/seating-v1-v2-prepared-and-preflight-042b7689.tar.gz'
    assert sha(original_bundle) == '40ba168efd5da52489a441d0c4aea5b7bc9adc18506a66f9a31b1623d098ddae'

    inputs = {f'seating-r3/{name}': SOURCE/name for name in source_manifest}
    for name in ('README.md', 'r2-preservation.json'):
        inputs['seating-r3/'+name] = SOURCE/name
    prepared_names = ['arithmetic-tests-report.json', 'arithmetic-tests.log',
                      'executed-source-manifest.json', 'preparation-report.json']
    prepared_names += ['executed-source-bytes/'+name for name in source_manifest]
    for name in prepared_names:
        inputs['seating-r3/prepared-v3/'+name] = SOURCE/'prepared-v3'/name
    inputs['independent-review/seating-r3-integration.json'] = review
    smoke_names = ('independent-source-review.json', 'ARCHIVE_READBACK.json', 'ARCHIVE_INDEX.json',
        'smoke_owned_process.py', 'README.md', 'executed-attempt/executed-source.py',
        'executed-attempt/child-stdout.log', 'executed-attempt/result.json',
        'executed-attempt/child-stderr.log', 'executed-attempt/executed-owned_process.py')
    for name in smoke_names:
        inputs['shared-helper-smoke/'+name] = smoke/name
    inputs['historical-dependency/seating-v1-v2-prepared-and-preflight-042b7689.tar.gz'] = original_bundle
    inputs['historical-r2-refusal/controller-native-1.json'] = Path('/tmp/razr-seating-v2-042b7689-native-1/controller.json')
    inputs['delivery/build_seating_r3_delivery.py'] = Path(__file__).resolve()
    for path in inputs.values():
        assert path.is_file() and not path.is_symlink() and path.stat().st_size < 1024**2

    payload = {name: path.read_bytes() for name, path in inputs.items()}
    rows = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                   'source': str(inputs[name])} for name, data in payload.items()}
    layout = {'repository_execution_root': str(BASE/'RAZR-SLIDE'),
        'functional_head': '042b768903cccbd7a0995317c8598401e0318e2a',
        'seating_r3_archive_prefix': 'seating-r3/', 'seating_r3_execution_root': str(SOURCE),
        'r3_original_execution_paths': {name: str(SOURCE/name) for name in source_manifest},
        'historical_dependency_archive': 'historical-dependency/seating-v1-v2-prepared-and-preflight-042b7689.tar.gz',
        'historical_dependency_archive_sha256': sha(original_bundle),
        'historical_dependency_prefixes': {'v1/': str(SOURCE.parent/'g2_seating'),
                                           'v2/': str(SOURCE.parent/'g2_seating_v2')},
        'restoration_rule': 'Verify the nested original member manifest and existing destination hashes; materialize only missing exact bytes, never overwrite differing frozen sources.',
        'native_execution_was_not_started': True}
    summary = {'schema': 'razr-seating-r3-reviewed-preparation-delivery-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'functional_head': layout['functional_head'], 'source_count': len(source_manifest),
        'source_manifest_sha256': sha(manifest_path), 'small_test_report_sha256': sha(report_path),
        'small_test_count': 50, 'small_test_components': {'original': 25, 'shared_owned_process': 17, 'seating_lifecycle': 8},
        'pure_tests_passed': True, 'CAD_imported': False, 'locked_package_count': 43,
        'independent_review_sha256': sha(review), 'shared_helper_actual_smoke_sha256': sha(smoke/'executed-attempt/result.json'),
        'r3_preflight_executed': False, 'r3_native_executed': False, 'numerical_solver_executed': False,
        'active_worker_owned_by_this_delivery': False, 'native_limits_relaxed': False,
        'complete_native_diagnostic_executed': False, 'complete_G2_qualification': False,
        'canonical_execution_checks_passed': False, 'candidate_go': False,
        'contains_large_numeric_or_geometry_payload': False,
        'historical_r2_refusal_not_retagged_as_r3': True,
        'next_action': 'Only an independently scheduled guarded r3 preflight/native attempt with the exact prepared manifest can produce new native evidence.'}
    payload['SUMMARY.json'] = encoded(summary)
    payload['source-layout.json'] = encoded(layout)
    payload['README.md'] = (
        '# SEATING r3 reviewed code and evidence\n\n'
        'Read `seating-r3/README.md` for exact scope, source identities and continuation commands. '
        'The 50 pure tests and shared stdlib-only helper smoke passed; no r3 capacity preflight, CAD or FE was executed.\n\n'
        '`source-layout.json` records the explicit execution layout. The nested historical bundle retains '
        'the original v1/v2 preparation and first r2 refusal; the later r2 refusal is separately preserved. '
        'Those historical artifacts are not r3 executions.\n\n'
        'Every archive member is hash-checked after sealing. Prefix evidence and monitoring readiness '
        'cannot grant continuous SEATING, full G2, or physical/manufacturing qualification.\n').encode()
    for name in ('SUMMARY.json', 'source-layout.json', 'README.md'):
        rows[name] = {'sha256': hashlib.sha256(payload[name]).hexdigest(), 'bytes': len(payload[name]),
                      'source': 'generated small delivery metadata'}
    payload['member-manifest.json'] = encoded(rows)
    OUTPUT.mkdir()
    archive = OUTPUT/'seating-r3-reviewed-owned-process-preparation-042b7689.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as bundle:
            for name, data in sorted(payload.items()):
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
                bundle.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as bundle:
        actual = bundle.getmembers()
        assert len(actual) == len(payload) and len({row.name for row in actual}) == len(actual)
        for item in actual:
            assert item.isfile() and bundle.extractfile(item).read() == payload[item.name]
    assert all(sha(path) == rows[name]['sha256'] for name, path in inputs.items())
    (OUTPUT/'member-manifest.json').write_bytes(payload['member-manifest.json'])
    record = {'archive': str(archive), 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
        'member_count': len(payload), 'member_manifest_sha256': hashlib.sha256(payload['member-manifest.json']).hexdigest(),
        'all_members_read_back_and_SHA256_verified': True, 'all_source_bytes_unchanged_during_sealing': True,
        'summary': summary}
    index = OUTPUT/'archive-readback-index.json'; index.write_bytes(encoded(record))
    print(json.dumps({'archive': str(archive), 'bytes': record['archive_bytes'], 'members': record['member_count'],
                      'sha256': record['archive_sha256'], 'index': str(index), 'index_sha256': sha(index)}))


if __name__ == '__main__':
    main()
