"""Single isolated stdlib child: verify its own procfs identity and RSS mapping.

This is a separate 9-second, 128-MiB-AS diagnostic with a <32-MiB RSS target.
No native computation/guard changes, procfs scanning, or privilege changes.
Both child streams and every exit/cleanup outcome are preserved.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import secrets
import select
import subprocess
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def status(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        key, _, value = line.partition(':')
        if key in ('Pid', 'PPid', 'NSpid'):
            numbers = [int(item) for item in value.split()]
            result[key] = numbers if key == 'NSpid' else numbers[0]
        elif key in ('VmRSS', 'VmHWM'):
            parts = value.split()
            if len(parts) != 2 or parts[1] != 'kB':
                raise ValueError('unexpected memory unit')
            result[key+'_bytes'] = int(parts[0])*1024
    return result


def stat(path):
    value = Path(path).read_text()
    left, right = value.index('('), value.rindex(')')
    parts = value[right+1:].split()
    return {'pid': int(value[:left].strip()), 'comm': value[left+1:right],
            'state': parts[0], 'ppid': int(parts[1]), 'starttime_ticks': int(parts[19])}


def identity(prefix='/proc/self'):
    return {'status': status(prefix+'/status'), 'stat': stat(prefix+'/stat'),
            'pid_namespace': os.readlink(prefix+'/ns/pid'),
            'pid_for_children_namespace': os.readlink(prefix+'/ns/pid_for_children')}


def own_identity():
    return {'os_getpid': os.getpid(), 'os_getppid': os.getppid(),
            'proc_self_visible_pid': os.readlink('/proc/self'), **identity()}


def read_line(fd, deadline):
    value = b''
    while b'\n' not in value:
        remaining = deadline-time.monotonic()
        if remaining <= 0:
            raise TimeoutError('dedicated handshake pipe timed out')
        ready, _, _ = select.select([fd], [], [], remaining)
        if not ready:
            raise TimeoutError('dedicated handshake pipe timed out')
        data = os.read(fd, 4096)
        if not data:
            raise ValueError('dedicated pipe closed before a full identity line')
        value += data
        if len(value) > 8192:
            raise ValueError('unexpected large diagnostic handshake')
    if value.count(b'\n') != 1 or not value.endswith(b'\n'):
        raise ValueError('one exact handshake line required')
    return value[:-1].decode()


def child(nonce, outgoing, incoming):
    started = time.monotonic()
    packet = {'kind': 'owned_child_identity', 'nonce': nonce,
              'source_sha256': sha(__file__), 'isolated_python': bool(sys.flags.isolated),
              'no_site': bool(sys.flags.no_site), **own_identity()}
    line = (json.dumps(packet, separators=(',', ':'))+'\n').encode()
    if len(line) >= 4096 or os.write(outgoing, line) != len(line):
        raise ValueError('identity pipe did not retain one atomic packet')
    os.close(outgoing)
    print(json.dumps(packet), flush=True)
    received = read_line(incoming, started+5.)
    os.close(incoming)
    if received != nonce:
        raise ValueError('wrong release nonce')
    result = {'kind': 'owned_child_finished', 'nonce': nonce,
              'self_ru_maxrss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
              'elapsed_seconds': time.monotonic()-started}
    print(json.dumps(result), flush=True)
    return 0


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (128*1024**2, 128*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (2, 2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def stop(process, deadline, record):
    if process.poll() is None:
        record['terminate_requested'] = True
        try:
            process.terminate()
        except ProcessLookupError:
            record['terminate_already_exited'] = True
    try:
        return process.wait(timeout=max(.01, min(.5, deadline-time.monotonic())))
    except subprocess.TimeoutExpired:
        record['kill_requested'] = True
        try:
            process.kill()
        except ProcessLookupError:
            record['kill_already_exited'] = True
        return process.wait(timeout=max(.01, deadline-time.monotonic()))


def parent(output):
    started = time.monotonic()
    deadline = started+9.
    if output.exists():
        raise ValueError('fresh diagnostic output directory required')
    output.mkdir(parents=True)
    source = Path(__file__).resolve()
    (output/'executed-source.py').write_bytes(source.read_bytes())
    report = {'schema': 'razr-own-child-procfs-namespace-probe-v2',
              'source_sha256': sha(source), 'parent_identity': own_identity(),
              'one_child_only': True, 'CAD_or_FE_executed': False,
              'unrelated_proc_entries_opened_or_scanned': False,
              'privileges_or_access_controls_changed': False,
              'child_address_space_limit_bytes': 128*1024**2,
              'child_RSS_target_bytes': 32*1024**2,
              'child_CPU_seconds_limit': 2, 'wall_budget_seconds': 9,
              'native_guard_modified': False, 'mapping_verified': False,
              'child_started': False, 'child_reaped': False}
    nonce = secrets.token_hex(16)
    handshake_r, handshake_w = os.pipe()
    release_r, release_w = os.pipe()
    descriptors = {handshake_r, handshake_w, release_r, release_w}
    process = None
    stdout_path, stderr_path = output/'child-stdout.log', output/'child-stderr.log'
    def close(fd):
        if fd in descriptors:
            os.close(fd)
            descriptors.remove(fd)
    try:
        command = [sys.executable, '-I', '-S', '-B', str(source), '--child', nonce,
                   '--handshake-write-fd', str(handshake_w), '--release-read-fd', str(release_r)]
        report['argv'] = command
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout,
                stderr=stderr, pass_fds=(handshake_w, release_r), preexec_fn=limits,
                start_new_session=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
            report.update(child_started=True, Popen_pid=process.pid)
            close(handshake_w); close(release_r)
            observed = json.loads(read_line(handshake_r, min(deadline, time.monotonic()+4.)))
            close(handshake_r)
            report['child_self_report'] = observed
            if (observed.get('nonce') != nonce or observed.get('kind') != 'owned_child_identity'
                    or observed.get('source_sha256') != report['source_sha256']
                    or observed.get('isolated_python') is not True or observed.get('no_site') is not True):
                raise ValueError('dedicated child identity source/nonce/isolation mismatch')
            visible = observed.get('proc_self_visible_pid')
            if not isinstance(visible, str) or not visible.isdecimal() or int(visible) <= 0:
                raise ValueError('positive numeric own procfs identity required')
            if process.poll() is not None:
                raise ValueError('child exited before RSS inspection')
            prefix = '/proc/'+visible
            actual = identity(prefix)
            own = report['parent_identity']
            checks = {
                'self_getpid_is_Popen_pid': observed['os_getpid'] == process.pid,
                'self_getppid_is_parent_getpid': observed['os_getppid'] == own['os_getpid'],
                'procfs_status_and_stat_pid_are_visible_pid': observed['status']['Pid'] == actual['status']['Pid'] == actual['stat']['pid'] == observed['stat']['pid'] == int(visible),
                'procfs_parent_is_this_parent': actual['status']['PPid'] == actual['stat']['ppid'] == int(own['proc_self_visible_pid']),
                'NSpid_matches_self_report': actual['status']['NSpid'] == observed['status']['NSpid'],
                'NSpid_last_is_Popen_pid': actual['status']['NSpid'][-1] == process.pid,
                'NSpid_first_is_procfs_visible_pid': actual['status']['NSpid'][0] == int(visible),
                'namespace_matches_child_and_parent': actual['pid_namespace'] == observed['pid_namespace'] == own['pid_namespace'],
                'pid_for_children_namespace_matches': actual['pid_for_children_namespace'] == observed['pid_for_children_namespace'] == own['pid_for_children_namespace'],
                'starttime_matches_child_self_report': actual['stat']['starttime_ticks'] == observed['stat']['starttime_ticks'],
                'positive_RSS_and_HWM': 0 < actual['status'].get('VmRSS_bytes', 0) <= actual['status'].get('VmHWM_bytes', 0),
            }
            second = identity(prefix)
            checks['stable_stat_namespace_and_NSpid_after_RSS'] = (
                second['stat']['pid'] == actual['stat']['pid']
                and second['stat']['starttime_ticks'] == actual['stat']['starttime_ticks']
                and second['pid_namespace'] == actual['pid_namespace']
                and second['status']['NSpid'] == actual['status']['NSpid'])
            checks['child_remains_alive'] = process.poll() is None
            report.update(parent_read_child_proc_path=prefix, parent_read_child_identity=actual,
                second_parent_read_child_identity=second, identity_checks=checks,
                Popen_pid_differs_from_procfs_visible_pid=process.pid != int(visible),
                naive_Popen_proc_path_opened=False)
            if not all(checks.values()):
                raise ValueError('owned child procfs identity did not verify')
            report['mapping_verified'] = True
            release = (nonce+'\n').encode()
            if os.write(release_w, release) != len(release):
                raise ValueError('release pipe write incomplete')
            close(release_w)
            report['child_exit_code'] = process.wait(timeout=max(.01, deadline-time.monotonic()))
            report['child_reaped'] = process.poll() is not None
    except BaseException as exc:
        report['failure'] = type(exc).__name__+': '+str(exc)
        report['mapping_verified'] = False
    finally:
        if process is not None:
            report['child_exit_code'] = stop(process, deadline, report)
            report['child_reaped'] = process.poll() is not None
        for fd in tuple(descriptors):
            close(fd)
        report['all_owned_pipe_descriptors_closed'] = not descriptors
    for label, path in (('stdout', stdout_path), ('stderr', stderr_path)):
        report['child_'+label+'_path'] = str(path)
        report['child_'+label+'_sha256'] = sha(path) if path.exists() else None
        report['child_'+label+'_bytes'] = path.stat().st_size if path.exists() else None
    if report.get('child_exit_code') == 0 and report['mapping_verified']:
        try:
            lines = [json.loads(line) for line in stdout_path.read_text().splitlines()]
            if len(lines) != 2 or lines[0] != report['child_self_report']:
                raise ValueError('stdout does not retain the exact handshake plus completion')
            finish = lines[1]
            if (finish.get('kind') != 'owned_child_finished' or finish.get('nonce') != nonce
                    or not 0 < finish.get('self_ru_maxrss_bytes', 0) < 32*1024**2):
                raise ValueError('child target RSS or completion not demonstrated')
            report['child_finish_record'] = finish
            report['child_self_peak_below_32MiB'] = True
        except BaseException as exc:
            report['failure'] = type(exc).__name__+': '+str(exc)
            report['mapping_verified'] = False
    report['elapsed_seconds'] = time.monotonic()-started
    report['source_unchanged'] = sha(source) == sha(output/'executed-source.py') == report['source_sha256']
    report['diagnostic_passed'] = bool(report['mapping_verified'] and report.get('child_exit_code') == 0
        and report['child_reaped'] and report.get('child_self_peak_below_32MiB')
        and report['source_unchanged'] and report['elapsed_seconds'] <= 9.)
    (output/'result.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: report.get(key) for key in ('diagnostic_passed', 'Popen_pid',
        'Popen_pid_differs_from_procfs_visible_pid', 'parent_read_child_proc_path',
        'child_exit_code', 'elapsed_seconds', 'failure')}))
    return 0 if report['diagnostic_passed'] else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--child')
    parser.add_argument('--handshake-write-fd', type=int)
    parser.add_argument('--release-read-fd', type=int)
    args = parser.parse_args()
    if args.child:
        raise SystemExit(child(args.child, args.handshake_write_fd, args.release_read_fd))
    if args.output is None:
        parser.error('--output is required for the parent')
    raise SystemExit(parent(args.output.resolve()))
