"""One bounded stdlib child probes only its own visible procfs identity.

No CAD/FE imports, unrelated /proc scan, privilege changes, or sampler fallback.
The ordinary Popen PID remains the only child lifecycle handle.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import secrets
import select
import subprocess
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def proc_status(path):
    values = {}
    for line in Path(path).read_text().splitlines():
        key, _, value = line.partition(':')
        if key in ('Pid', 'PPid', 'NSpid'):
            numbers = [int(item) for item in value.split()]
            values[key] = numbers if key == 'NSpid' else numbers[0]
        elif key in ('VmRSS', 'VmHWM'):
            fields = value.split()
            if len(fields) != 2 or fields[1] != 'kB':
                raise ValueError('unexpected procfs memory unit')
            values[key+'_bytes'] = int(fields[0])*1024
    return values


def proc_stat(path):
    value = Path(path).read_text()
    left, right = value.index('('), value.rindex(')')
    fields = value[right+1:].split()
    return {'pid': int(value[:left].strip()), 'comm': value[left+1:right],
            'state': fields[0], 'ppid': int(fields[1]), 'starttime_ticks': int(fields[19])}


def identity(prefix='/proc/self'):
    return {'status': proc_status(prefix+'/status'), 'stat': proc_stat(prefix+'/stat'),
            'pid_namespace': os.readlink(prefix+'/ns/pid'),
            'pid_for_children_namespace': os.readlink(prefix+'/ns/pid_for_children')}


def self_identity():
    return {'os_getpid': os.getpid(), 'os_getppid': os.getppid(),
            'proc_self_visible_pid': os.readlink('/proc/self'), **identity()}


def run_child(challenge):
    start = time.monotonic()
    report = {'kind': 'child_handshake', 'challenge': challenge,
              'source_sha256': sha(__file__), **self_identity()}
    print(json.dumps(report), flush=True)
    ready, _, _ = select.select([sys.stdin], [], [], 5.)
    if not ready or sys.stdin.readline().strip() != challenge:
        return 2
    print(json.dumps({'kind': 'child_finished', 'challenge': challenge,
                     'elapsed_seconds': time.monotonic()-start,
                     'self_ru_maxrss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}), flush=True)
    return 0


def child_limits():
    resource.setrlimit(resource.RLIMIT_AS, (32*1024**2, 32*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (2, 2))


def stop_child(child, deadline):
    if child.poll() is None:
        try:
            child.terminate()
        except ProcessLookupError:
            pass
    try:
        return child.wait(timeout=max(.01, min(.5, deadline-time.monotonic())))
    except subprocess.TimeoutExpired:
        try:
            child.kill()
        except ProcessLookupError:
            pass
        return child.wait(timeout=max(.01, deadline-time.monotonic()))


def run_parent(output):
    started = time.monotonic()
    deadline = started+9.
    if output.exists():
        raise ValueError('new diagnostic output required')
    output.parent.mkdir(parents=True, exist_ok=True)
    report = {'schema': 'razr-own-child-procfs-namespace-probe-v1',
              'source_sha256': sha(__file__), 'parent_identity': self_identity(),
              'one_child_only': True, 'CAD_or_FE_executed': False,
              'unrelated_proc_entries_opened_or_scanned': False,
              'privileges_or_access_controls_changed': False,
              'child_address_space_limit_bytes': 32*1024**2,
              'child_CPU_seconds_limit': 2, 'parent_wall_budget_seconds': 9,
              'native_guard_modified': False, 'mapping_verified': False}
    challenge = secrets.token_hex(16)
    command = [sys.executable, '-B', str(Path(__file__).resolve()), '--child', challenge]
    child = None
    try:
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, text=True, preexec_fn=child_limits,
                                 env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        report['Popen_pid'] = child.pid
        ready, _, _ = select.select([child.stdout], [], [], max(0., min(3., deadline-time.monotonic())))
        if not ready:
            raise ValueError('bounded child identity handshake timed out')
        observed = json.loads(child.stdout.readline())
        report['child_self_report'] = observed
        if (observed.get('challenge') != challenge or observed.get('kind') != 'child_handshake'
                or observed.get('source_sha256') != report['source_sha256']):
            raise ValueError('child challenge/source identity differs')
        visible = observed.get('proc_self_visible_pid')
        if not isinstance(visible, str) or not visible.isdecimal() or int(visible) <= 0:
            raise ValueError('child did not report a numeric own procfs identity')
        report['Popen_pid_differs_from_procfs_visible_pid'] = child.pid != int(visible)
        report['naive_Popen_proc_path_opened'] = False
        if child.poll() is not None:
            raise ValueError('child already exited before observation')
        # This path came only from our exact child's /proc/self handshake.
        prefix = '/proc/'+visible
        actual = identity(prefix)
        parent = report['parent_identity']
        checks = {
            'reported_getpid_equals_Popen_pid': observed['os_getpid'] == child.pid,
            'reported_getppid_equals_parent_getpid': observed['os_getppid'] == parent['os_getpid'],
            'self_report_and_parent_read_stat_pid_match_visible': observed['stat']['pid'] == actual['stat']['pid'] == int(visible),
            'self_report_and_parent_read_status_pid_match_visible': observed['status']['Pid'] == actual['status']['Pid'] == int(visible),
            'parent_visible_ppid_matches_own_child': actual['status']['PPid'] == actual['stat']['ppid'] == int(parent['proc_self_visible_pid']),
            'NSpid_chain_matches_child_self_report': actual['status']['NSpid'] == observed['status']['NSpid'],
            'NSpid_last_equals_Popen_pid': actual['status']['NSpid'][-1] == child.pid,
            'NSpid_first_equals_visible_pid': actual['status']['NSpid'][0] == int(visible),
            'pid_namespace_matches_own_parent_and_child': actual['pid_namespace'] == observed['pid_namespace'] == parent['pid_namespace'],
            'pid_for_children_namespace_matches': actual['pid_for_children_namespace'] == observed['pid_for_children_namespace'] == parent['pid_for_children_namespace'],
            'starttime_matches_child_self_report': actual['stat']['starttime_ticks'] == observed['stat']['starttime_ticks'],
            'positive_RSS_and_HWM_observed': 0 < actual['status'].get('VmRSS_bytes', 0) <= actual['status'].get('VmHWM_bytes', 0),
        }
        second = identity(prefix)
        checks['starttime_and_namespace_stable_after_RSS_read'] = (
            second['stat']['pid'] == actual['stat']['pid']
            and second['stat']['starttime_ticks'] == actual['stat']['starttime_ticks']
            and second['pid_namespace'] == actual['pid_namespace']
            and second['status']['NSpid'] == actual['status']['NSpid'])
        checks['child_still_alive_after_RSS_read'] = child.poll() is None
        report.update(parent_read_child_proc_path=prefix, parent_read_child_identity=actual,
                      second_parent_read_child_identity=second, identity_checks=checks)
        if not all(checks.values()):
            raise ValueError('self-reported procfs mapping is not fully verified')
        report['mapping_verified'] = True
        child.stdin.write(challenge+'\n'); child.stdin.flush()
        stdout, stderr = child.communicate(timeout=max(.01, deadline-time.monotonic()))
        report.update(child_exit_code=child.returncode, child_finish_lines=stdout,
                      child_stderr=stderr, child_reaped=child.poll() is not None)
        finish = json.loads(stdout.strip())
        report['child_finish_record'] = finish
        if (child.returncode != 0 or finish.get('kind') != 'child_finished'
                or finish.get('challenge') != challenge
                or finish['self_ru_maxrss_bytes'] >= 32*1024**2):
            raise ValueError('bounded child did not complete within its declared scope')
        report['child_self_reported_peak_below_32MiB'] = True
    except BaseException as exc:
        report['failure'] = type(exc).__name__+': '+str(exc)
        report['mapping_verified'] = False
        if child is not None:
            report['child_exit_code'] = stop_child(child, deadline)
            report['child_reaped'] = child.poll() is not None
    report['elapsed_seconds'] = time.monotonic()-started
    report['source_unchanged'] = sha(__file__) == report['source_sha256']
    report['diagnostic_passed'] = bool(report['mapping_verified'] and report.get('child_exit_code') == 0
        and report.get('child_reaped') and report['source_unchanged'] and report['elapsed_seconds'] <= 9.)
    output.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: report.get(key) for key in (
        'diagnostic_passed', 'Popen_pid', 'Popen_pid_differs_from_procfs_visible_pid',
        'parent_read_child_proc_path', 'elapsed_seconds', 'failure')}))
    return 0 if report['diagnostic_passed'] else 2


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--child':
        raise SystemExit(run_child(sys.argv[2]))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(run_parent(args.output.resolve()))
