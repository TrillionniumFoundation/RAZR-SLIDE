"""Run one reviewed scratch study with fixed budgets and immutable receipts.

This launcher records a local diagnostic, never a canonical repository job or
a hosted Actions run. Geometry outcomes remain in the original study report.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--study', choices=('accessory', 'key'), required=True)
    parser.add_argument('--open-report', type=Path, required=True)
    parser.add_argument('--stow-report', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(root):
        raise ValueError('new output outside the frozen repository required')
    expected = args.expected_head
    if len(expected) != 40 or any(c not in '0123456789abcdef' for c in expected):
        raise ValueError('full expected HEAD required')
    if args.study == 'key' and args.stow_report is None:
        raise ValueError('both checked endpoint receipts required for KEY')
    uv = shutil.which('uv')
    if uv is None:
        raise ValueError('installed uv launcher required')
    source = Path(__file__).resolve()
    folder = source.parent
    helper_path = folder/'run_canonical_controls.py'
    spec = importlib.util.spec_from_file_location('reviewed_resource_reader', helper_path)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    sys.path.insert(0, str(root/'tools'))
    import validate_product_nominal_report as guard
    name = 'product_accessory_motion.py' if args.study == 'accessory' else 'probe_key_endpoint_extension.py'
    study_source = folder/'integration'/name
    paths = (source, helper_path, study_source, folder/'PATCH_MANIFEST.json')
    source_before = {str(path): sha(path) for path in paths}
    manifest = json.loads((folder/'PATCH_MANIFEST.json').read_text())
    if manifest['files']['integration/'+name] != sha(study_source):
        raise ValueError('study bytes differ from the reviewed patch manifest')
    output.mkdir(parents=True)
    for path, filename in ((source, 'runner-source.py'), (helper_path, 'resource-helper-source.py'),
                           (study_source, 'executed-study-source.py')):
        shutil.copyfile(path, output/filename)
    record = {'schema': 'razr-local-followon-diagnostic-runner-v1', 'expected_head': expected,
              'study': args.study, 'source_before': source_before, 'commands': [],
              'local_diagnostic_execution_completed': False, 'canonical_execution_claimed': False,
              'hosted_Actions_execution_claimed': False, 'common_study_budget_seconds': 1200,
              'preflight_limits': {'writeable_disk_bytes': 256*1024**2,
                                   'effective_memory_headroom_bytes': 2*1024**3},
              'runtime_limits': {'minimum_writeable_disk_bytes': 100*1024**2,
                                 'maximum_shared_unreclaimable_memory_bytes': int(6.8*1024**3)}}
    def save():
        (output/'runner-report.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    def stop(process, deadline):
        if process.poll() is not None:
            return
        grace = max(0., min(1., deadline-time.monotonic()))
        try:
            os.killpg(process.pid, signal.SIGTERM if grace else signal.SIGKILL)
        except ProcessLookupError:
            process.wait(timeout=1.)
            return
        try:
            process.wait(timeout=grace if grace else 1.)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=1.)
    def run(command, log_name, environment, deadline):
        start = time.perf_counter()
        event = None
        if time.monotonic() >= deadline:
            raise ValueError('shared 1200-second budget exhausted before command')
        log = output/log_name
        with log.open('x') as stream:
            process = subprocess.Popen(command, cwd=root, env=environment,
                stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                while True:
                    available = helper.resources(output)
                    remaining = deadline-time.monotonic()
                    if remaining <= 0:
                        event = {'kind': 'shared_study_timeout', 'resources': available}
                        stop(process, deadline); code = 124; break
                    if (available['writeable_disk_bytes'] < 100*1024**2
                            or available['shared_unreclaimable_memory_bytes'] > int(6.8*1024**3)):
                        event = {'kind': 'shared_runtime_resource_budget', 'resources': available}
                        stop(process, deadline); code = 125; break
                    try:
                        code = process.wait(timeout=min(2., remaining)); break
                    except subprocess.TimeoutExpired:
                        continue
            except BaseException:
                stop(process, deadline)
                raise
        result = {'argv': command, 'exit_code': code, 'seconds': time.perf_counter()-start,
                  'stop_event': event, 'log': log_name, 'log_sha256': sha(log)}
        record['commands'].append(result); save()
        return result
    try:
        available = helper.resources(output); record['resource_preflight'] = available
        if (available['writeable_disk_bytes'] < 256*1024**2
                or available['effective_memory_headroom_bytes'] < 2*1024**3):
            raise ValueError('original resource preflight not satisfied')
        deadline = time.monotonic()+1200.
        before = guard.current_identity(root, expected); record['identity_before'] = before
        baseline_paths = {'OPEN': args.open_report}
        if args.study == 'key': baseline_paths['STOW'] = args.stow_report
        record['baseline_receipts'] = {}
        for pose, path in baseline_paths.items():
            digest = sha(path)
            raw = json.loads(path.read_text())
            checked = guard.validate_report(raw, pose, expected, before)
            record['baseline_receipts'][pose] = {'path': str(path.resolve()), 'sha256': digest,
                                                'independent_postguard': checked}
        with tempfile.TemporaryDirectory(prefix='razr-'+args.study+'-', dir='/tmp') as tmp:
            tmp = Path(tmp)
            environment = {**os.environ, 'TMPDIR': str(tmp), 'UV_CACHE_DIR': str(tmp/'uv-cache'),
                'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
                'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
            record['environment_overrides'] = {key: environment[key] for key in (
                'TMPDIR', 'UV_CACHE_DIR', 'PYTHONDONTWRITEBYTECODE', 'OPENBLAS_NUM_THREADS',
                'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')}
            prefix = [uv, 'run', '--locked', 'python', '-B']
            check = run(prefix+['tools/check_environment.py', '--output', str(output/'environment.json')],
                        'environment.log', environment, deadline)
            if check['exit_code']:
                raise ValueError('locked runtime check failed')
            command = prefix+[str(study_source), '--root', str(root), '--expected-head', expected,
                              '--output', str(output/'native')]
            if args.study == 'accessory':
                command += ['--open-control-report', str(args.open_report.resolve())]
            else:
                copied = tmp/'control-evidence'; copied.mkdir()
                record['temporary_baseline_copies'] = {}
                for pose, path in baseline_paths.items():
                    target = copied/(pose.lower()+'-control-domain.json')
                    shutil.copyfile(path, target)
                    if sha(target) != record['baseline_receipts'][pose]['sha256']:
                        raise ValueError('temporary baseline copy differs from original bytes')
                    record['temporary_baseline_copies'][pose] = {'path': str(target), 'sha256': sha(target)}
                command += ['--control-evidence-directory', str(copied)]
            result = run(command, 'native.log', environment, deadline)
            if result['exit_code']:
                raise ValueError('native diagnostic command returned '+str(result['exit_code']))
            if time.monotonic() >= deadline:
                raise ValueError('shared budget exhausted before postflight')
            after = guard.current_identity(root, expected); record['identity_after'] = after
            unchanged = (before == after and source_before == {str(path): sha(path) for path in paths}
                and all(sha(path) == record['baseline_receipts'][pose]['sha256'] for pose, path in baseline_paths.items()))
            record['source_and_original_baseline_bytes_unchanged'] = unchanged
            if not unchanged:
                raise ValueError('source or original baseline changed during execution')
            raw_path = output/'native/report.json'
            raw = json.loads(raw_path.read_text())
            record['native_report_sha256'] = sha(raw_path)
            if (raw.get('source_commit') != expected or raw.get('source_bytes_unchanged') is not True
                    or raw.get('executed_study_source') != {'path': str(study_source), 'sha256': sha(study_source)}
                    or raw.get('identity_before') != before or raw.get('identity_after') != after
                    or raw.get('execution_completed') is not True
                    or raw.get('diagnostic_execution_checks_passed') is not True
                    or raw.get('execution_checks_passed') is not False):
                raise ValueError('raw diagnostic completion and exact identity are inconsistent')
            if time.monotonic() >= deadline:
                raise ValueError('shared budget exhausted during postflight')
            record['local_diagnostic_execution_completed'] = True
            record['independent_geometry_result_review_required'] = True
            record['canonical_execution_claimed'] = False
    except BaseException as exc:
        record['execution_failure'] = type(exc).__name__+': '+str(exc)
    save()
    print(json.dumps({key: record.get(key) for key in (
        'study', 'local_diagnostic_execution_completed', 'canonical_execution_claimed', 'execution_failure')}), flush=True)
    return 0 if record['local_diagnostic_execution_completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
