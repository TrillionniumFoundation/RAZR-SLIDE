"""Finite slot-admissible KEY endpoint-outside diagnostics on complete material.

The current factory deliberately rejects q outside [0,12]. This study does not
clamp q or pretend that the factory accepted it. It translates actual complete
KEY/crosshead/telescope material according to the existing rigid motion law,
retaining each STOP at the existing endpoint plateau/lower-stop height. Native
floor extents are inspected before claiming a STOW plateau continuation.
Positive Common proves a penetrating trial placement, not a usable state or a
global hard-stop theorem. Finite clear trials do not discharge a continuous
backlash domain or restoring-force/physical qualification.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clearance_constants():
    radial = .425-.4
    cam = radial*math.hypot(1., 12./79.75)
    yoke = radial*math.sqrt(2.)
    return cam, yoke, cam+yoke


def endpoint_trials(pose):
    if pose not in ('STOW', 'OPEN'):
        raise ValueError('one declared endpoint required')
    cam, _, half = clearance_constants()
    direction = -1. if pose == 'STOW' else 1.
    return [{'label': pose+'_OUTSIDE_'+label, 'KEY_offset_mm': direction*half*factor,
             'crosshead_offset_mm': direction*cam*factor, 'nominal_q_mm': 0. if pose == 'STOW' else 12.}
            for label, factor in (('0p001mm', .001/half), ('HALF_BAND', .5), ('FULL_BAND', 1.))]


def moving_inventory(names):
    names = set(names)
    result = {side+'_'+role for side in 'LR' for role in (
        'KEY', 'CROSSHEAD', 'CROSSHEAD_TUBE_BOTTOM_CAP', 'KEY_FOLLOWER_LOWER_FLANGE',
        'TELESCOPE_1', 'TELESCOPE_1_BOTTOM_CAP', 'TELESCOPE_2', 'TELESCOPE_2_BOTTOM_CAP',
        'TELESCOPE_3', 'TELESCOPE_3_CORE_BOTTOM_SHOULDER', 'TELESCOPE_3_CAM_LOWER_FLANGE',
        'TELESCOPE_3_CAM_UPPER_FLANGE')}
    if not result <= names:
        raise ValueError('complete moving KEY/crosshead/telescope material is missing')
    return result


def pair_partition(names):
    """Every changed pair is recomputed; only unchanged pairs may be reused."""
    names = list(names)
    if len(names) != len(set(names)):
        raise ValueError('duplicate material participant')
    moving = moving_inventory(names)
    pairs = list(itertools.combinations(sorted(names), 2))
    changed = [(a, b) for a, b in pairs if a in moving or b in moving]
    fixed = [(a, b) for a, b in pairs if a not in moving and b not in moving]
    if len(changed)+len(fixed) != len(names)*(len(names)-1)//2 or set(changed) & set(fixed):
        raise ValueError('changed and unchanged pair partition is incomplete')
    return changed, fixed


def rigid_trial(parts, dq, dx):
    cam, yoke, _ = clearance_constants()
    if not all(type(v) in (int, float) and math.isfinite(v) for v in (dq, dx)):
        raise ValueError('finite offsets required')
    if abs(dx) > cam+1e-12 or abs(dx-dq) > yoke+1e-12:
        raise ValueError('trial is outside the two coupled native groove constraints')
    moving = moving_inventory(parts)
    result = dict(parts)
    for name in sorted(moving):
        sign = -1. if name.startswith('L_') else 1.
        vector = (0., dq, 0.) if name.endswith('_KEY') else (sign*dx, 0., 0.)
        result[name] = parts[name].translate(vector)
    return result


def contact_coordinates(side, point, nominal_q=0.):
    """Inverse of the audited native placement plus the 6 mm mounted shift."""
    x, y, z = point.toTuple() if hasattr(point, 'toTuple') else point
    sign = -1. if side == 'L' else 1.
    return z-4.2, y-14.8-nominal_q, sign*x-23.85


def retain_positive(row, positives, export=None):
    """Preserve a real numeric rejection even if witness export later fails."""
    common = row.get('common_mm3')
    if (type(common) not in (int, float) or not math.isfinite(common)
            or common <= 1e-7 or row.get('rejected') is not True):
        raise ValueError('an actual positive Common row is required')
    positive = dict(row)
    positives.append(positive)
    if export is None:
        return None
    try:
        positive['actual_Common_STEP'] = export()
    except Exception as exc:
        error = type(exc).__name__+': '+str(exc)
        positive['STEP_export_failure'] = error
        return {'a': row['a'], 'b': row['b'], 'evaluation_failed': True,
                'failure_stage': 'positive_Common_STEP_export', 'error': error,
                'actual_common_mm3_preserved': common}
    return None


def native_plateau_extent(parts, profiles, p):
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    import cadquery as cq
    _, _, outside = clearance_constants()
    records = []
    for side in 'LR':
        sign = -1. if side == 'L' else 1.
        for index, profile in enumerate(profiles[side]):
            key, stop = parts[side+'_KEY'], parts[f'{side}_STOP_{index}']
            floors = []
            for face_index, face in enumerate(key.Faces()):
                if face.geomType() != 'PLANE':
                    continue
                normal = face.normalAt(); center = contact_coordinates(side, face.Center())
                if (abs(sign*normal.x-1.) > 1e-9 or abs(center[2]-profile.floor_height) > 1e-7
                        or not -.61 < center[0] < -.19):
                    continue
                vertices = [contact_coordinates(side, vertex.Center()) for vertex in face.Vertices()]
                e = [min(v[0] for v in vertices), max(v[0] for v in vertices)]
                q = [min(v[1] for v in vertices), max(v[1] for v in vertices)]
                corners = {(round(v[0], 9), round(v[1], 9)) for v in vertices}
                rectangular = (len(face.Wires()) == 1 and len(vertices) == 4 and len(face.Edges()) == 4
                    and all(edge.geomType() == 'LINE' for edge in face.Edges())
                    and corners == set(itertools.product(map(lambda x: round(x, 9), e), map(lambda x: round(x, 9), q)))
                    and abs(face.Area()-(e[1]-e[0])*(q[1]-q[0])) <= 1e-7)
                floors.append({'face': face_index, 'e_extent_mm': e, 'q_extent_mm': q,
                               'area_mm2': face.Area(), 'complete_trimmed_face_is_rectangle': rectangular})
            pins = []
            for face_index, face in enumerate(stop.Faces()):
                if face.geomType() != 'CYLINDER':
                    continue
                cylinder = BRepAdaptor_Surface(face.wrapped).Cylinder(); axis = cylinder.Axis().Direction()
                if abs(abs(axis.Z())-1.) > 1e-9 or abs(cylinder.Radius()-profile.pin_radius) > 1e-7:
                    continue
                location = cylinder.Location(); point = (location.X(), location.Y(), location.Z())
                e0, q0, r0 = contact_coordinates(side, point)
                extents = [contact_coordinates(side, vertex.Center())[0] for vertex in face.Vertices()]
                e = [min(extents), max(extents)]
                pin = cq.Solid.makeCylinder(cylinder.Radius(), e[1]-e[0],
                    cq.Vector(sign*(23.85+r0), 14.8+q0, 4.2+e[0]), cq.Vector(0, 0, 1))
                pins.append({'face': face_index, 'pin_q_mm': q0, 'pin_r_mm': r0, 'e_extent_mm': e,
                             'full_pin_outside_STOP_mm3': p.volume(pin.cut(stop))})
            record = {'side': side, 'STOP': index, 'floor_candidates': floors, 'pin_candidates': pins,
                      'negative_KEY_interval_mm': [-outside, 0.], 'native_plateau_extension_supported': False}
            if len(floors) == len(pins) == 1:
                floor, pin = floors[0], pins[0]
                q_range = [pin['pin_q_mm'], pin['pin_q_mm']+outside]
                overlap = min(floor['e_extent_mm'][1], pin['e_extent_mm'][1])-max(floor['e_extent_mm'][0], pin['e_extent_mm'][0])
                margins = [q_range[0]-floor['q_extent_mm'][0], floor['q_extent_mm'][1]-q_range[1]]
                supported = (floor['complete_trimmed_face_is_rectangle'] and min(margins) >= 0. and overlap > 0.
                    and pin['full_pin_outside_STOP_mm3'] <= 1e-7
                    and abs(pin['pin_r_mm']-profile.floor_height-profile.pin_radius) <= 1e-7
                    and abs(pin['pin_q_mm']-profile.pin_q) <= 1e-7)
                record.update(native_plateau_extension_supported=supported, contact_q_interval_mm=q_range,
                              finite_floor_q_edge_margins_mm=margins, contact_e_overlap_mm=overlap)
            records.append(record)
    return {'schema': 'razr-native-finite-plateau-extension-v1', 'rows': records,
            'all_four_current_native_floors_support_the_declared_negative_q_contact': len(records) == 4 and all(
                row['native_plateau_extension_supported'] for row in records),
            'restoring_force_and_physical_contact_qualified': False, 'formal_directed_rounding_certificate': False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--control-evidence-directory', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    root, output = args.root.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(root):
        raise ValueError('new evidence output outside source required')
    sys.path[:0] = [str(root/'integration'), str(root/'tools')]
    import product_nominal_motion as nominal
    import validate_product_nominal_report as postguard
    import product_routing_ep5 as ep5
    import cadquery as cq
    p = nominal.p
    output.mkdir(parents=True)
    started = time.perf_counter(); own = Path(__file__).resolve(); own_before = sha(own)
    report = {'schema': 'razr-complete-KEY-endpoint-outside-finite-diagnostic-v1',
        'source_commit': args.expected_head, 'execution_completed': False, 'execution_checks_passed': False,
        'diagnostic_execution_checks_passed': False, 'scratch_study_source': not own.is_relative_to(root),
        'executed_study_source': {'path': str(own), 'sha256': own_before},
        'continuous_backlash_domain_proved': False, 'global_KEY_hard_stop_proved': False,
        'complete_product_motion_proved': False, 'physical_qualification': False,
        'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False,
        'geometry_generator_imported': True, 'same_CAD_kernel': True,
        'formal_directed_rounding_certificate': False, 'poses': [], 'trials': [],
        'positive_Common_STEP_export_limit_per_trial': 8,
        'all_positive_pair_numeric_records_retained_even_when_STEP_export_limit_reached': True,
        'all_trial_states_accepted_by_existing_factory': False,
        'positive_Common_means_penetrating_trial_not_usable_state': True}
    evidence_hashes = {}
    try:
        before = postguard.current_identity(root, args.expected_head); report['identity_before'] = before
        for pose in ('STOW', 'OPEN'):
            baseline_path = args.control_evidence_directory/(pose.lower()+'-control-domain.json')
            evidence_hashes[str(baseline_path.resolve())] = sha(baseline_path)
            baseline = json.loads(baseline_path.read_text())
            receipt = postguard.validate_report(baseline, pose, args.expected_head, before)
            s, d = (0., 0.) if pose == 'STOW' else (79.75, 8.2)
            accessory = pose == 'OPEN'
            parts, metadata = nominal.full_scene(s, d, 3., 3., open_hold=accessory, open_support=accessory)
            ep5.validate_factory_input_coverage(metadata['scene'], before['executed_source_sha256'])
            if sorted(parts) != baseline['complete_participant_names']:
                raise ValueError('fresh complete endpoint inventory differs from the checked control receipt')
            profiles = p.native_inputs()[4]
            moving = moving_inventory(parts)
            # Verify the rigid placement law against an actual accepted factory
            # state on the same flat branch, before extrapolating outside q.
            cam, _, half = clearance_constants()
            inward = min(profile.breakpoints[0] for side in 'LR' for profile in profiles[side])/4 if pose == 'STOW' else -.001
            dx = inward*cam/half
            actual, _ = nominal.full_scene(s, d, 3., 3., key_offsets=(inward, inward), crosshead_offsets=(dx, dx),
                                            open_hold=accessory, open_support=accessory)
            expected = rigid_trial(parts, inward, dx)
            differences = {name: max(p.volume(actual[name].cut(expected[name])), p.volume(expected[name].cut(actual[name])))
                           for name in sorted(parts) if not actual[name].isSame(expected[name])}
            if set(actual) != set(parts) or any(value > 1e-7 for value in differences.values()):
                raise ValueError('rigid branch placement omitted or changed actual factory material')
            pose_record = {'pose': pose, 'participants': len(parts), 'complete_participant_names': sorted(parts),
                'checked_baseline_control_receipt': receipt, 'baseline_report_sha256': evidence_hashes[str(baseline_path.resolve())],
                'native_scene_metadata': metadata, 'in_domain_factory_crosscheck': {
                    'KEY_offset_mm': inward, 'crosshead_offset_mm': dx,
                    'all_participants_compared': len(parts), 'bidirectional_material_difference_mm3': differences},
                'moving_participants': sorted(moving), 'tabs_mm': [3., 3.], 'slot_flanks': [0., 0.],
                'telescope_allocation': metadata['scene']['telescope_offsets_by_side_mm']}
            if pose == 'STOW':
                pose_record['native_plateau_contact_extension'] = native_plateau_extent(parts, profiles, p)
            else:
                pose_record['selected_lower_stop_positions_retained'] = True
                pose_record['new_lower_stop_force_or_retention_proof'] = False
            report['poses'].append(pose_record)
            selected_pairs, fixed_pairs = pair_partition(parts)
            for trial in endpoint_trials(pose):
                current = rigid_trial(parts, trial['KEY_offset_mm'], trial['crosshead_offset_mm'])
                q = trial['nominal_q_mm']+trial['KEY_offset_mm']; rejected = []
                for side in 'LR':
                    for index, profile in enumerate(profiles[side]):
                        try: profile.evaluate(q)
                        except ValueError as exc: rejected.append({'side': side, 'STOP': index, 'error': str(exc)})
                if len(rejected) != 4:
                    raise ValueError('trial is not the declared missing software endpoint branch')
                rows = []; positives = []; failures = []
                for a, b in selected_pairs:
                    try:
                        result = p.strict_common(current[a], current[b])
                    except Exception as exc:
                        row = {'a': a, 'b': b, 'evaluation_failed': True, 'error': type(exc).__name__+': '+str(exc)}
                        failures.append(row)
                    else:
                        row = {'a': a, 'b': b, **result, 'rejected': result['common_mm3'] > 1e-7}
                        if row['rejected']:
                            export = None
                            if len(positives) < 8:
                                path = output/(trial['label']+'-positive-%02d.step' % (len(positives)+1))
                                def export():
                                    cq.exporters.export(current[a].intersect(current[b]), str(path))
                                    return {'path': path.name, 'sha256': sha(path)}
                            failure = retain_positive(row, positives, export)
                            if failure is not None:
                                failures.append(failure)
                    rows.append(row)
                if {(row['a'], row['b']) for row in rows} != set(selected_pairs) or len(rows) != len(selected_pairs):
                    raise ValueError('actual moving-pair inventory is incomplete')
                trial.update(pose=pose, q_mm=q, existing_profile_rejections=rejected,
                    actual_native_changed_pairs=rows, changed_pair_count=len(rows),
                    unchanged_pair_count_from_bound_baseline=len(fixed_pairs),
                    unchanged_participant_names=sorted(set(parts)-moving),
                    complete_unordered_pair_count=len(rows)+len(fixed_pairs),
                    baseline_receipt_sha256=pose_record['baseline_report_sha256'],
                    positive_actual_Common=positives, evaluation_failures=failures,
                    finite_trial_material_clear=not positives and not failures,
                    whole_current_factory_acceptance_claimed=False)
                report['trials'].append(trial)
                print(json.dumps({'trial': trial['label'], 'native_pairs': len(rows), 'positive_pairs': len(positives),
                                  'errors': len(failures), 'seconds': time.perf_counter()-started}), flush=True)
        after = postguard.current_identity(root, args.expected_head); report['identity_after'] = after
        unchanged = before == after and own_before == sha(own) and all(sha(path) == digest for path, digest in evidence_hashes.items())
        failures = [error for trial in report['trials'] for error in trial['evaluation_failures']]
        complete = len(report['poses']) == 2 and len(report['trials']) == 6
        report.update(execution_completed=True, source_bytes_unchanged=unchanged,
                      diagnostic_execution_checks_passed=complete and unchanged and not failures,
                      evaluation_failure_count=len(failures),
                      retained_actual_positive_pair_count=sum(len(trial['positive_actual_Common']) for trial in report['trials']))
    except Exception as exc:
        report['execution_failure'] = type(exc).__name__+': '+str(exc)
    report['seconds'] = time.perf_counter()-started
    (output/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: report.get(key) for key in ('execution_completed', 'diagnostic_execution_checks_passed',
        'retained_actual_positive_pair_count', 'execution_failure', 'seconds')}), flush=True)
    return 0 if report['diagnostic_execution_checks_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
