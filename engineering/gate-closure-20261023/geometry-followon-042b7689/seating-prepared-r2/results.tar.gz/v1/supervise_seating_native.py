"""External resource guard for the unchanged prepared-v1 SEATING worker.

The six prepared sources remain unchanged. The worker gets 1,740 seconds for
between-operator checks, leaving 60 seconds under the hard 1,800-second ceiling
to serialize an interrupted report. A hard in-kernel stop may leave only the
controller and stdout evidence; it never counts as a completed diagnostic.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

import verify_seating_native as worker

PREPARED_SOURCE_MANIFEST_SHA256 = '2f677af6163a421da21f3c8b719071c2e5b60a46a36e7f6a21cf991bae4c93b3'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def snapshot(path):
    values = {key: int(value) for key, value in
              (line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())}
    disk = os.statvfs(path)
    return {
        'f_bavail_bytes': disk.f_bavail * disk.f_frsize,
        'estimated_unreclaimable_bytes': values['anon'] + values.get('shmem', 0)
            + max(values.get('kernel', 0) - values.get('slab_reclaimable', 0), 0)
            + values.get('unevictable', 0),
    }


def process_memory(pid):
    result = {}
    try:
        for line in Path('/proc/%d/status' % pid).read_text().splitlines():
            key, _, value = line.partition(':')
            if key in ('VmRSS', 'VmHWM'):
                result[key] = int(value.split()[0]) * 1024
    except FileNotFoundError:
        pass
    return result


def save(path, value):
    temporary = path.with_suffix('.writing')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)


def terminate(child):
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, required=True)
    parser.add_argument('--expected-head', default=worker.DEFAULT_HEAD)
    parser.add_argument('--maximum-subdivision-depth', type=int, choices=range(4), default=3)
    parser.add_argument('--preflight-only', action='store_true')
    args = parser.parse_args(argv)
    output = args.output_directory.resolve()
    if output.exists() or not output.is_relative_to(Path('/tmp').resolve()):
        raise ValueError('a new private /tmp native output directory is required')
    head = subprocess.check_output(['git', '-C', str(worker.ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    if head != args.expected_head or len(head) != 40:
        raise ValueError('explicit frozen full repository HEAD required')
    if subprocess.check_output(['git', '-C', str(worker.ROOT), 'status', '--porcelain'], text=True).strip():
        raise ValueError('clean frozen repository required')
    output.mkdir(parents=True, exist_ok=False)
    sources = worker.adapter_identity()
    prepared_manifest = worker.HERE / 'prepared-v1/executed-source-manifest.json'
    if sha(prepared_manifest) != PREPARED_SOURCE_MANIFEST_SHA256:
        raise ValueError('prepared-v1 source manifest changed')
    expected_sources = {name: row['sha256'] for name, row in json.loads(prepared_manifest.read_text()).items()}
    if sources != expected_sources:
        raise ValueError('current worker sources differ from the independently reviewed prepared-v1 bytes')
    supervisor_sha = sha(__file__)
    initial = snapshot(output)
    state = {
        'schema': 'razr-seating-prepared-v1-bounded-controller-v1',
        'expected_head': args.expected_head,
        'utc_started': dt.datetime.now(dt.timezone.utc).isoformat(),
        'worker_source_sha256_before': sources,
        'prepared_source_manifest_sha256': PREPARED_SOURCE_MANIFEST_SHA256,
        'supervisor_source': str(Path(__file__).resolve()), 'supervisor_sha256': supervisor_sha,
        'initial_resources': initial, 'worker_started': False, 'completed': False,
        'hard_wall_limit_seconds': 1800, 'worker_between_operator_limit_seconds': 1740,
        'worker_peak_RSS_limit_MiB': 1536, 'shared_unreclaimable_limit_GiB': 6.8,
        'startup_available_disk_MiB': 400, 'runtime_available_disk_reserve_MiB': 300,
        'startup_incremental_memory_reserve_MiB': 1536,
        'canonical_execution_checks_passed': False, 'whole_declared_seating_domain_clear': False,
        'complete_G2_qualification': False, 'candidate_go': False,
        'fixture_fabrication_go': False, 'manufacturing_go': False,
        'observations': [],
    }
    target = output / 'controller.json'
    save(target, state)
    if initial['f_bavail_bytes'] < 400 * 2**20 or initial['estimated_unreclaimable_bytes'] + 1536 * 2**20 > 6.8 * 2**30:
        state.update(status='not_started_insufficient_resource_margin')
        save(target, state)
        return 3
    command = [str(worker.ROOT / '.venv/bin/python'), '-B', str(worker.HERE / 'verify_seating_native.py'),
               '--native', '--output', str(output / 'report.json'), '--expected-head', args.expected_head,
               '--seconds', '1740', '--minimum-available-disk-mib', '300', '--maximum-rss-mib', '1536',
               '--maximum-pair-calls', '20000', '--maximum-subdivision-depth', str(args.maximum_subdivision_depth)]
    state['command'] = command
    if args.preflight_only:
        state.update(status='preflight_only_worker_not_started')
        save(target, state)
        return 0
    copies = output / 'executed-source-bytes'; copies.mkdir()
    manifest = []
    for name, digest in sources.items():
        source, destination = worker.HERE / name, copies / name
        destination.write_bytes(source.read_bytes())
        if sha(destination) != digest or sha(source) != digest:
            raise ValueError('prepared worker source changed during archival copy')
        manifest.append({'source': str(source), 'copy': str(destination), 'sha256': digest})
    own_copy = copies / Path(__file__).name
    own_copy.write_bytes(Path(__file__).read_bytes())
    if sha(own_copy) != supervisor_sha:
        raise ValueError('controller source changed during archival copy')
    save(output / 'executed-source-manifest.json', {'sources': manifest,
         'controller': {'source': str(Path(__file__).resolve()), 'copy': str(own_copy), 'sha256': supervisor_sha}})
    environment = {**os.environ, 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
                   'MKL_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
    started = last = time.monotonic(); reason = None
    with (output / 'native.log').open('wb') as log:
        child = subprocess.Popen(command, cwd=worker.ROOT, env=environment,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        state.update(worker_started=True, pid=child.pid); save(target, state)
        try:
            while child.poll() is None:
                observed = {**snapshot(output), 'worker_memory': process_memory(child.pid),
                            'elapsed_seconds': time.monotonic() - started}
                if observed['elapsed_seconds'] > 1800:
                    reason = 'hard_wall_guard'
                elif observed['f_bavail_bytes'] < 300 * 2**20:
                    reason = 'ordinary_available_disk_guard'
                elif observed['estimated_unreclaimable_bytes'] > 6.8 * 2**30:
                    reason = 'shared_unreclaimable_memory_guard'
                elif max(observed['worker_memory'].values(), default=0) > 1536 * 2**20:
                    reason = 'worker_peak_RSS_guard'
                if reason or time.monotonic() - last >= 15:
                    state['observations'].append(observed); save(target, state); last = time.monotonic()
                    print(json.dumps(observed), flush=True)
                if reason:
                    terminate(child)
                    break
                time.sleep(.5)
        except BaseException:
            terminate(child)
            raise
        code = child.wait()
    after = worker.adapter_identity()
    state.update(worker_exit_code=code, elapsed_seconds=time.monotonic() - started,
                 resource_stop_reason=reason, worker_source_sha256_after=after,
                 worker_sources_unchanged=after == sources, supervisor_source_unchanged=sha(__file__) == supervisor_sha,
                 final_resources=snapshot(output), utc_finished=dt.datetime.now(dt.timezone.utc).isoformat())
    state['head_after'] = subprocess.check_output(['git', '-C', str(worker.ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    state['worktree_clean_after'] = not subprocess.check_output(['git', '-C', str(worker.ROOT), 'status', '--porcelain'], text=True).strip()
    path = output / 'report.json'
    if path.is_file():
        state['report_sha256'] = sha(path)
        try:
            report = json.loads(path.read_text())
            state['reported_complete_native_diagnostic_executed'] = report.get('complete_native_diagnostic_executed')
            state['reported_external_pair_domain_clear'] = report.get('whole_declared_seating_external_pair_domain_clear')
        except Exception as exc:
            state['report_parse_failure'] = type(exc).__name__ + ': ' + str(exc)
    else:
        state['hard_stop_may_leave_stdout_and_controller_only'] = True
    state['completed'] = bool(code == 0 and reason is None and after == sources
        and state['supervisor_source_unchanged'] and state['worktree_clean_after']
        and state['head_after'] == args.expected_head
        and state.get('reported_complete_native_diagnostic_executed') is True)
    save(target, state)
    print(json.dumps({k: state.get(k) for k in ('completed', 'worker_exit_code',
          'resource_stop_reason', 'reported_external_pair_domain_clear', 'elapsed_seconds')}), flush=True)
    return 0 if state['completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
