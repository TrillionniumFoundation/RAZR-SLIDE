# Complete-material SEATING diagnostic preparation

## Executed result and remaining work

The source-bound arithmetic preparation at repository commit
`042b768903cccbd7a0995317c8598401e0318e2a` passed **15/15** regressions in
7.212 seconds, with 44,000 KiB peak RSS and no CAD import. It checked 7,364
actual finite FPC core cells and 48 complete taper polygons. The independent
review also accepted the shared-descent polytope and whole finite-polygon
coverage arguments. A separate 4/4 independent report-guard regression closed
the earlier synthetic negative-gap/aggregate evidence loophole.

No SEATING CAD execution is claimed by this preparation. The six executed
sources are preserved byte for byte in `prepared-v1/executed-source-bytes/`.
Their manifest SHA256 is
`2f677af6163a421da21f3c8b719071c2e5b60a46a36e7f6a21cf991bae4c93b3`.
The later external supervisor is a separate source identity and does not edit
or relabel the prepared worker or its test receipts.

## Declared continuous domain

- Slide is fixed at 79.75 mm; the shared descent is `d in [0,8.2]` mm.
- Both tabs are released at 3 mm. The two slot flanks vary independently in
  `[-1,1]`. KEY/crosshead offsets are fixed at zero.
- On each side, all three telescope joints satisfy `0.1 <= j_i <= 2.9` and
  `j1+j2+j3 = 8.5-d`. Both sides use the **same** descent variable.
- All 154 installed travel materials are retained. The seven separately
  installed OPEN accessories are outside this travel configuration.
- The report inventory contains all 11,781 unordered pairs: 11,476 rigid
  pairs, 304 flexible/rigid pairs, and the complete FPC/OLED pair.

The actual reference factory call is `full_scene(79.75,0,3,3)` with explicit
equal telescope allocation and zero offsets/flanks. The canonical PREDOCK
control report has the same complete name inventory, but its raw geometry
starts at tab zero and moves to released tabs through its control domain.
Its raw geometry is therefore not substituted for this reference scene.

## Continuous material coverage

`seating_domain.py` constructs the coupled joint polytope with exact rational
arithmetic. Its 28 generators use the critical descents 0, 2.6, 5.4 and 8.2.
The two bodies' relative law is formed before projection. B parts and the
complete telescope-3 group move by `-d`; telescope 1 follows `j1`, telescope 2
follows `j1+j2`; pawls and pins retain independent flank motion. A B-attached
reference adds `d` to Z and does not change Y during SEATING.

`seating_enclosures.py` covers the actual EP5 finite YZ polygon extrusion,
including both complete finite planar taper wings. The original 49 mandatory
stations split each of S/U1/U2 into 48 cells. Endpoint extrema, the complete
normal-thickness bound and the station-merge guard cover each actual cell's
corners. Oriented adjacent-cell boundaries cancel to the original polygon
boundary. The nonzero winding of a valid polygon interior then proves that
the union of cell convex hulls covers the entire finite polygon, not only its
boundary or a sampled center curve. The complete X extrusion is retained.
The 150 elementary boxes are grouped into nine native material cages.

The S-rise extremum at descent 7.65 is included. OLED front, full finite
annulus and return leg are enclosed separately; nested internally tangent
disks bound the changing annulus in A/B frames. Full FPC/OLED separation uses
the actual material regions. Positive local cell Jacobians are not promoted
to a proof of global native topology or all-pose self-validity.

Every flexible/rigid pair uses complete material cages in an A or B frame,
with conservative interval subdivision when necessary. All region Common
volume upper bounds are summed against **one** `1e-7 mm^3` budget for the
original pair. A positive conservative overlap remains unresolved.

## Native evidence and bounded execution

The worker rechecks full source/input/lock identity before and after CAD,
checks the actual factory against the source-owned rigid laws, retains every
material and pair, and independently validates raw numeric evidence rather
than trusting `clear` labels. Complete cage labels, region sums, both child
intervals, reverse-frame failures and resource-stop details are checked.

After root allocates the heavy-computation slot, the concrete entry point is:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/workspace/scratch/95cd2986fdf2/RAZR-SLIDE/.venv/bin/python -B \
/workspace/scratch/95cd2986fdf2/input_recovery/g2_seating/supervise_seating_native.py \
--expected-head 042b768903cccbd7a0995317c8598401e0318e2a \
--output-directory /tmp/razr-seating-042b7689-attempt1
```

Appending `--preflight-only` checks the present resource margin without
starting CAD. Every invocation needs a new output directory. The controller
requires 400 MiB ordinary available disk, retains 300 MiB during execution,
reserves 1,536 MiB incremental memory, caps the worker's observed RSS at that
amount, and stops its own process group if shared unreclaimable memory exceeds
6.8 GiB. The worker has 1,740 seconds for between-operation checks and the
controller enforces an independent 1,800-second wall limit. The pair-call
budget is 20,000 and interval subdivision depth is three.

The original worker writes its complete raw JSON when it returns. A hard stop
inside a long native operation can therefore preserve only the controller and
stdout evidence; such an attempt is explicitly incomplete. A successful
external-pair proof still does not set whole-SEATING self-validity, complete
G2, physical qualification or manufacturing release to true.

## Evidence paths

- `prepared-v1/arithmetic-tests-report.json`
- `prepared-v1/preparation-report.json`
- `prepared-v1/arithmetic-tests.log`
- `/workspace/scratch/95cd2986fdf2/gates_audit/dev/followon/seating-enclosure-independent-review.json`
- `/workspace/scratch/95cd2986fdf2/ci_audit/seating-guard-counterexample.json`
- `/workspace/scratch/95cd2986fdf2/ci_audit/seating-guard-fix-independent-review.json`

The counterexample is retained as historical evidence; it is not rewritten as
a pass. The frozen 100-file numerical delivery and repository sources remain
unchanged by this preparation.
