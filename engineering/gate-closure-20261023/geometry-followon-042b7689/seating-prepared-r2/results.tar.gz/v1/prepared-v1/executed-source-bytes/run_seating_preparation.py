"""Execute only source-bound arithmetic regressions and preparation metadata."""
from __future__ import annotations

import argparse
import io
import json
from pathlib import Path
import resource
import sys
import time
import unittest

import verify_seating_native as adapter
import test_seating_arithmetic as tests


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, required=True)
    parser.add_argument('--expected-head', default=adapter.DEFAULT_HEAD)
    args = parser.parse_args(argv)
    output = args.output_directory.resolve()
    if output.exists() or output.is_relative_to(adapter.ROOT.resolve()):
        raise ValueError('new scratch output directory outside the repository required')
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    before = adapter.arithmetic_repository_identity(args.expected_head)
    own_before = adapter.adapter_identity()
    environment = adapter.postguard.check_environment.inspect_environment(adapter.ROOT)
    if environment.get('passed') is not True:
        raise ValueError('arithmetic regressions require the existing locked environment')
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
    (output / 'arithmetic-tests.log').write_text(stream.getvalue())
    after = adapter.arithmetic_repository_identity(args.expected_head)
    own_after = adapter.adapter_identity()
    cad_imported = any(name == 'cadquery' or name == 'OCP' or name.startswith('OCP.') for name in sys.modules)
    unchanged = before == after and own_before == own_after
    record = {'schema': 'razr-seating-source-bound-arithmetic-regressions-v1',
              'expected_head': args.expected_head, 'test_count': result.testsRun,
              'failures': [(str(test), detail) for test, detail in result.failures],
              'errors': [(str(test), detail) for test, detail in result.errors],
              'skipped': [(str(test), reason) for test, reason in result.skipped],
              'passed': result.wasSuccessful() and unchanged and not cad_imported and not result.skipped,
              'adapter_source_sha256_before': own_before, 'adapter_source_sha256_after': own_after,
              'repository_identity_before': before, 'repository_identity_after': after,
              'source_identity_unchanged': unchanged, 'locked_environment': environment,
              'CAD_imported': cad_imported, 'native_checks_executed': False,
              'actual_finite_cell_crosschecks': 4 * sum(len(s['s']) - 1 for s, _ in tests.FiniteMaterialEnclosureTests.pose_sections.values()),
              'actual_taper_polygon_crosschecks': 6 * 2 * 2 * 2,
              'cell_crosschecks_are_regressions_not_substitutes_for_continuous_coverage_proof': True,
              'seconds': time.monotonic() - started, 'peak_RSS_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'complete_G2_qualification': False, 'candidate_go': False,
              'fixture_fabrication_go': False, 'manufacturing_go': False}
    (output / 'arithmetic-tests-report.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
    if record['passed']:
        prepared = adapter.preparation_report(args.expected_head)
        (output / 'preparation-report.json').write_text(json.dumps(prepared, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: record[key] for key in ('test_count', 'passed', 'seconds', 'peak_RSS_KiB',
                     'actual_finite_cell_crosschecks', 'actual_taper_polygon_crosschecks', 'CAD_imported')}))
    return 0 if record['passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
