"""Package only the preserved SEATING code and small evidence, then read it back."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/95cd2986fdf2')
V1 = ROOT / 'input_recovery/g2_seating'
V2 = ROOT / 'input_recovery/g2_seating_v2'
HEAD = '042b768903cccbd7a0995317c8598401e0318e2a'
V1_MANIFEST = '2f677af6163a421da21f3c8b719071c2e5b60a46a36e7f6a21cf991bae4c93b3'
V2_ORIGINAL_MANIFEST = '8203817f83268b44b651e0afe3e1ba34c2d9f68a2be500f48c3e67f5260eeb59'
V2_MANIFEST = '1024dc5aa4e8cc2011b4201ea73f84abe78f6695ed27e5b70e517d6e56af867c'


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def verify_preserved_sources(directory, prepared, expected):
    path = directory / prepared / 'executed-source-manifest.json'
    require(sha(path) == expected, 'prepared manifest bytes changed')
    manifest = json.loads(path.read_text())
    for name, row in manifest.items():
        require(sha(directory / name) == row['sha256'], 'current source differs: ' + name)
        require(sha(directory / prepared / 'executed-source-bytes' / name) == row['sha256'],
                'preserved execution source differs: ' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, required=True)
    parser.add_argument('--v2-review', type=Path, action='append', required=True)
    parser.add_argument('--preflight', type=Path, required=True)
    args = parser.parse_args()
    output = args.output_directory.resolve()
    require(not output.exists() and output.is_relative_to(ROOT / 'input_recovery'),
            'a new scratch delivery directory is required')
    verify_preserved_sources(V1, 'prepared-v1', V1_MANIFEST)
    verify_preserved_sources(V2, 'prepared-v2-r2', V2_MANIFEST)
    old = V2 / 'prepared-v2/executed-source-manifest.json'
    require(sha(old) == V2_ORIGINAL_MANIFEST, 'earlier prepared-v2 manifest changed')
    for name, row in json.loads(old.read_text()).items():
        require(sha(V2 / 'prepared-v2/executed-source-bytes' / name) == row['sha256'],
                'earlier v2 source bytes were not preserved')
    preflight = json.loads(args.preflight.read_text())
    require(preflight['expected_head'] == HEAD
            and preflight['prepared_source_manifest_sha256'] == V2_MANIFEST
            and preflight['worker_started'] is False and preflight['completed'] is False,
            'only the actual reviewed-v2 non-starting preflight belongs in this delivery')
    require(preflight.get('status') in ('preflight_only_worker_not_started',
            'not_started_insufficient_resource_margin', 'not_started_locked_environment_mismatch'),
            'unexpected preflight disposition')

    files = {}

    def add(path, name):
        require(not Path(path).is_symlink(), 'symbolic links are not delivery members')
        path = Path(path).resolve()
        require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 2**21,
                'only small regular evidence files may be packaged')
        require(path.suffix in ('.py', '.json', '.md', '.log'), 'matrix or binary payload is excluded')
        require(name not in files and not name.startswith('/') and '..' not in Path(name).parts,
                'duplicate or unsafe archive member')
        files[name] = path

    for directory, prefix in ((V1, 'v1'), (V2, 'v2')):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                add(path, prefix + '/' + path.relative_to(directory).as_posix())
    for path in (
        ROOT / 'gates_audit/dev/followon/seating-enclosure-independent-review.json',
        ROOT / 'ci_audit/seating-guard-counterexample.json',
        ROOT / 'ci_audit/seating-guard-fix-independent-review.json',
        ROOT / 'ci_audit/seating-guard-fix-independent-tests.log',
        ROOT / 'ci_audit/seating-supervisor-independent-review.json',
    ):
        add(path, 'independent-reviews/v1/' + path.name)
    for path in args.v2_review:
        add(path, 'independent-reviews/v2/' + path.name)
    add(args.preflight, 'preflight/controller.json')
    add(Path(__file__), 'delivery/build_delivery.py')
    add(Path(__file__).with_name('README.md'), 'README.md')
    add(Path(__file__).with_name('SUMMARY.json'), 'SUMMARY.json')
    rows = [{'member': name, 'original_path': str(path), 'bytes': path.stat().st_size,
             'sha256': sha(path)} for name, path in sorted(files.items())]
    member_manifest = {
        'schema': 'razr-seating-v1-v2-small-code-and-evidence-delivery-v1',
        'repository_head': HEAD, 'v1_prepared_manifest_sha256': V1_MANIFEST,
        'earlier_v2_prepared_manifest_sha256': V2_ORIGINAL_MANIFEST,
        'v2_prepared_manifest_sha256': V2_MANIFEST,
        'native_execution_performed_by_this_delivery': False,
        'preflight_status': preflight['status'], 'worker_started': False,
        'no_numeric_matrices_or_native_geometry_payloads': True,
        'complete_G2_qualification': False,
        'members': rows,
    }
    raw_manifest = (json.dumps(member_manifest, indent=2) + '\n').encode()
    output.mkdir(parents=True)
    archive = output / 'seating-v1-v2-prepared-and-preflight-042b7689.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
        for row in rows:
            path = files[row['member']]
            require(sha(path) == row['sha256'], 'input changed before archive write')
            tar.add(path, arcname=row['member'], recursive=False)
        info = tarfile.TarInfo('member-manifest.json')
        info.size = len(raw_manifest)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(raw_manifest))
    expected = {row['member']: row for row in rows}
    expected['member-manifest.json'] = {'bytes': len(raw_manifest), 'sha256': sha_bytes(raw_manifest)}
    verified = []
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        require(len(members) == len(expected) and {m.name for m in members} == set(expected),
                'archive member inventory differs')
        for item in members:
            require(item.isfile(), 'unexpected nonregular archive member')
            with tar.extractfile(item) as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            require(item.size == expected[item.name]['bytes'] and digest == expected[item.name]['sha256'],
                    'archive member readback differs')
            verified.append({'member': item.name, 'bytes': item.size, 'sha256': digest})
    require(all(sha(files[row['member']]) == row['sha256'] for row in rows),
            'an original delivery file changed during packaging')
    index = {
        'schema': 'razr-seating-small-delivery-archive-readback-v1',
        'archive': str(archive), 'archive_bytes': archive.stat().st_size,
        'archive_sha256': sha(archive), 'all_members_readback_verified': True,
        'all_original_files_unchanged_during_packaging': True,
        'member_count': len(verified), 'members': verified,
        'embedded_member_manifest_sha256': sha_bytes(raw_manifest),
        'no_native_or_matrix_execution': True,
    }
    (output / 'member-manifest.json').write_bytes(raw_manifest)
    index_path = output / 'archive-readback-index.json'
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({'archive': str(archive), 'archive_sha256': index['archive_sha256'],
        'archive_bytes': index['archive_bytes'], 'member_count': len(verified),
        'index': str(index_path), 'index_sha256': sha(index_path)}))


if __name__ == '__main__':
    main()
