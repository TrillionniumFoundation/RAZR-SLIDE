# SEATING v2: preserved geometry with durable pair evidence

## Scope and actual execution

This is a separately identified scratch adapter for repository HEAD
`042b768903cccbd7a0995317c8598401e0318e2a`. The original `g2_seating/`
sources and `prepared-v1/` evidence remain unchanged. The current v2-r2
preparation passed 25/25 pure tests in 6.990 seconds with 45,316 KiB peak RSS
and no CAD import: the original 15 geometry/evidence tests, seven checkpoint
tests and three metadata/payload negative-control groups. The exact current
execution sources are preserved in `prepared-v2-r2/executed-source-bytes/`.
The earlier 22/22 v2 preparation is retained separately in `prepared-v2/`;
its independent review identified the metadata/payload guard gaps corrected
by r2, so those earlier successful pure tests are not relabeled as r2 tests.

The source manifest SHA256 is
`1024dc5aa4e8cc2011b4201ea73f84abe78f6695ed27e5b70e517d6e56af867c`.
The preparation verifies the old six source hashes and old manifest,
requires byte-identical domain/enclosure/inventory/arithmetic-test sources,
and compares the geometry/evidence helper ASTs and actual geometry calls.
No SEATING native execution is established by these preparation results.

The declared domain remains slide 79.75 mm, shared descent in [0,8.2] mm,
released tabs at 3 mm, independent flanks in [-1,1], and independent left
and right telescope allocations constrained by each side's three joints in
[0.1,2.9] mm and sum `8.5 - the same d`. KEY and crosshead offsets are zero.
All 154 installed travel materials and all 11,781 unordered pairs remain
in scope. The exact shared-descent projection and complete finite FPC/OLED
cages are documented in the preserved original README and preparation.

## Evidence persistence

`pairs.jsonl` is created exclusively for one run. Its header binds the
complete participant inventory, exact domain, original repository/runtime
identity, all ten scratch sources, execution limits, and a new run nonce.
Every record repeats the nonce/context digest and includes its sequence,
previous-record digest, and its own digest. Construction evidence precedes
the exact ordered pair prefix. Each completed pair stores its unchanged raw
evidence once; no growing full report is rewritten inside the pair loop.

Every record is flushed. Header, construction, interruption, postflight and
final commit are fsynced; pairs are additionally fsynced in batches of 16.
A hard stop can leave an incomplete final line. The prefix reader preserves
intact records and reports the tail separately, and always reports the
diagnostic as incomplete. The checkpoint is evidence preservation, not a
native restart adapter or a completed-domain certificate.

Normal completion additionally writes a full JSON report, a journal commit
binding its exact bytes, and an atomic final index binding both files. The
independent saved reader requires all three and rechecks the original raw
geometric evidence, complete source/input/43-package identity, construction,
inventory and exact pair accounting. A final commit alone grants nothing.
Budget/error details and nested unresolved evidence cannot be aggregated
into a passing completion result. Missing/truncated/reordered records,
wrong source/domain/run identity, modified raw pairs and absent final indexes
are covered by the small negative controls.

The reader also binds every actual base control to the source-owned reference,
including the explicit equal telescope allocation, complete payload key set
and hashes, absence of an external payload overlay, and the original false
physical/product scope flags. Booleans cannot masquerade as finite zero-valued
controls, and nonfinite controls or incomplete payload declarations fail.

The controller retains a partial-journal readback after an interrupted
worker. A telemetry/write exception or interrupt in the controller first
terminates and reaps its own child process group. The controller never
terminates another task's processes.

## Unchanged resource contract and concrete commands

The original limits remain: 400 MiB ordinary available disk before starting,
300 MiB runtime disk reserve, 1,536 MiB startup incremental memory reserve and
worker peak RSS limit, 6.8 GiB shared unreclaimable-memory ceiling, 1,740 seconds
for worker checks and an independent 1,800-second process-group timeout.
The pair-call limit is 20,000 and maximum interval subdivision depth is three.

Use the locked interpreter with single-threaded numerical libraries. Every
invocation requires a new private output directory. A preflight never starts
the worker:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/workspace/scratch/95cd2986fdf2/RAZR-SLIDE/.venv/bin/python -B \
/workspace/scratch/95cd2986fdf2/input_recovery/g2_seating_v2/supervise_seating_native.py \
--expected-head 042b768903cccbd7a0995317c8598401e0318e2a \
--prepared-manifest /workspace/scratch/95cd2986fdf2/input_recovery/g2_seating_v2/prepared-v2-r2/executed-source-manifest.json \
--prepared-sha256 1024dc5aa4e8cc2011b4201ea73f84abe78f6695ed27e5b70e517d6e56af867c \
--output-directory /tmp/razr-seating-v2-042b7689-NEW-preflight \
--preflight-only
```

After explicit allocation of the shared heavy-computation slot, a native
attempt uses the same command with a different new output directory and
without `--preflight-only`. The original resource gates still decide whether
a worker may start. The source manifest must continue to match all actual
executed bytes. Reproduction elsewhere must preserve or explicitly adapt the
recorded execution-path contract under a new source identity.

Pure saved readback, requiring the same clean repository, locked environment
and scratch source identity, is available through:

```bash
/workspace/scratch/95cd2986fdf2/RAZR-SLIDE/.venv/bin/python -B \
/workspace/scratch/95cd2986fdf2/input_recovery/g2_seating_v2/check_seating_checkpoint.py \
--expected-head 042b768903cccbd7a0995317c8598401e0318e2a \
--journal /tmp/ACTUAL-RUN/pairs.jsonl --output /tmp/NEW-prefix-readback.json
```

For a published full result, replace `--journal ...` with
`--report /tmp/ACTUAL-RUN/report.json` and use a new output path. A prefix
reader intentionally returns an incomplete status even when a final commit
is present; only the complete reader may qualify the external-pair result.

## Qualification boundary

A complete external-pair diagnostic would still leave full-family native
self-validity, complete G2, physical qualification and manufacturing release
unproven. The report flags preserve those distinctions. The numerical FE
deliveries, unqualified panel H candidate and rejected probe-only preflight
are separate evidence and are not modified by this work.
