"""Reproduce the old metadata counterexamples and verify the frozen r2 fix."""
from __future__ import annotations

import ast
import copy
import datetime as dt
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

BASE = Path('/workspace/scratch/95cd2986fdf2')
STUDY = BASE/'input_recovery/g2_seating_v2'
sys.path.insert(0, str(STUDY))
import check_seating_checkpoint as reader


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    before = reader.worker.adapter_identity()
    old_manifest = STUDY/'prepared-v2/executed-source-manifest.json'
    new_manifest = STUDY/'prepared-v2-r2/executed-source-manifest.json'
    old = json.loads(old_manifest.read_text())
    new = json.loads(new_manifest.read_text())
    assert len(old) == len(new) == len(before) == 10
    for name, row in new.items():
        assert sha(STUDY/name) == sha(row['preserved_source_path']) == row['sha256'] == before[name]
    for row in old.values():
        assert sha(row['preserved_source_path']) == row['sha256']
    original_path = Path(old['check_seating_checkpoint.py']['preserved_source_path'])
    tree = ast.parse(original_path.read_bytes(), filename=str(original_path))
    original = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                               and node.name == 'construction_valid'], type_ignores=[])
    old_namespace = dict(vars(reader))
    exec(compile(original, str(original_path), 'exec'), old_namespace)
    original_construction = old_namespace['construction_valid']
    names = reader.worker.expected_inventory()
    laws = reader.domain.rigid_laws(names, {'L': .025, 'R': .025}, names)
    probes = []
    for descent in (F('2.6'), F('4.1'), F('8.2')):
        vertices = reader.domain.joints_at(descent)
        probes.append({'descent_mm': float(descent),
            'joints_by_side_mm': {'L': list(map(float, vertices[0])), 'R': list(map(float, vertices[-1]))},
            'flanks': [-.4, .65], 'rigid_materials_checked': len(laws),
            'maximum_bidirectional_material_difference_mm3': 0.,
            'complete_factory_reconstructed_including_both_flexible_bodies': True,
            'samples_do_not_establish_continuous_law': True})
    scene = {'factory': 'integration/product_split_assembly.py:split_scene',
             'parent_factory': 'integration/product_assembly.py:product_scene',
             'slide_mm': 79.75, 'descent_mm': 0., 'left_tab_mm': 3., 'right_tab_mm': 3.,
             'OPEN_hold_screws_installed': False, 'OPEN_display_support_insert_installed': False,
             'installed_mechanical_parts': 108, 'expected_scene_participants': 108,
             'slot_flanks': [0., 0.], 'KEY_offsets_mm': [0., 0.], 'crosshead_offsets_mm': [0., 0.],
             'B_translation_mm': [0., 79.75, 8.2],
             'telescope_offsets_by_side_mm': {side: [float(reader.domain.REFERENCE_JOINT)]*3 for side in 'LR'},
             'telescope_allocation': 'explicit admissible joint allocation',
             **dict.fromkeys(reader.SCENE_FALSE_FLAGS, False)}
    report = {'construction_completed': True, 'native_checks_executed': True,
              'construction_probes': probes, 'native_scene_metadata': {'combined_participants': 154,
              'mechanical_participants': 108, 'candidate_participants': 41, 'scene': scene}}
    reader.construction_valid(report, laws)
    cases = []
    mutations = [
        ('wrong_actual_base_controls', {'slot_flanks': [1., -1.], 'KEY_offsets_mm': [.03, .03],
          'crosshead_offsets_mm': [.02, .02], 'telescope_offsets_by_side_mm': {'L': [.1]*3, 'R': [.1]*3}}),
        ('Boolean_descent_masquerading_as_zero', {'descent_mm': False}),
        ('false_physical_release_claims', {'physical_holding_and_force_qualified': True,
                                         'candidate_go': True, 'manufacturing_go': True})]
    for label, changes in mutations:
        candidate = copy.deepcopy(report)
        candidate['native_scene_metadata']['scene'].update(changes)
        original_construction(candidate, laws)
        try:
            reader.construction_valid(candidate, laws)
        except ValueError as error:
            rejected = str(error)
        else:
            raise AssertionError('r2 accepted original counterexample: '+label)
        cases.append({'case': label, 'synthetic_changed_metadata': changes,
                      'old_exact_AST_accepted': True, 'new_reader_rejected': True,
                      'new_reader_error': rejected})
    payloads = {'engineering/synthetic-a.json': 'a'*64, 'engineering/synthetic-b.json': 'b'*64,
                'engineering/synthetic.tar.gz': 'c'*64}
    identity = {'head_bound_source_sha256': payloads,
                'executed_source_sha256': {str(reader.worker.ROOT/name): digest for name, digest in payloads.items()}}
    payload_scene = {'source_inputs': {'engineering/synthetic-a.json': 'a'*64,
                                      'engineering/synthetic-b.json': 'b'*64},
                     'archive': 'engineering/synthetic.tar.gz', 'archive_sha256': 'c'*64}
    reader.factory_payload_valid(payload_scene, identity)
    payload_scene['source_inputs'].pop('engineering/synthetic-b.json')
    reader.worker.enclosure.ep5.validate_factory_input_coverage(payload_scene, identity['executed_source_sha256'])
    try:
        reader.factory_payload_valid(payload_scene, identity)
    except ValueError as error:
        rejected = str(error)
    else:
        raise AssertionError('r2 accepted omitted original payload')
    cases.append({'case': 'omitted_source_payload', 'old_subset_coverage_accepted': True,
                  'new_reader_rejected': True, 'new_reader_error': rejected})
    original_supervisor = Path(old['supervise_seating_native.py']['preserved_source_path'])
    current_supervisor = STUDY/'supervise_seating_native.py'
    class NormalizeManifestPath(ast.NodeTransformer):
        def visit_Constant(self, node):
            if node.value in ('prepared-v2/executed-source-manifest.json',
                              'prepared-v2-r2/executed-source-manifest.json'):
                return ast.copy_location(ast.Constant(value='EXPLICIT_REVIEWED_PREPARED_MANIFEST'), node)
            return node
    def normalized_AST(path):
        return ast.dump(NormalizeManifestPath().visit(ast.parse(path.read_bytes())), include_attributes=False)
    assert normalized_AST(original_supervisor) == normalized_AST(current_supervisor)
    lifecycle_path = BASE/'ci_audit/seating-v2-supervisor-lifecycle-independent-review.json'
    lifecycle = json.loads(lifecycle_path.read_text())
    assert lifecycle['sha256_before'] == lifecycle['sha256_after'] == sha(original_supervisor)
    assert lifecycle['specific_regression_cases_passed'] == 4
    preparation = STUDY/'prepared-v2-r2/arithmetic-tests-report.json'
    tests = json.loads(preparation.read_text())
    assert tests['test_count'] == 25 and not tests['failures'] and not tests['errors'] and not tests['skipped']
    assert tests['passed'] is True and tests['CAD_imported'] is False and tests['source_identity_unchanged'] is True
    assert tests['adapter_source_sha256_before'] == tests['adapter_source_sha256_after'] == before
    assert tests['v1_preservation_and_geometry_before'] == tests['v1_preservation_and_geometry_after']
    after = reader.worker.adapter_identity()
    assert before == after and not any(name.startswith(('cadquery', 'OCP')) for name in sys.modules)
    receipt = {
        'schema': 'razr-seating-v2-r2-independent-journal-reader-review-v1',
        'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'repository_head': reader.worker.DEFAULT_HEAD,
        'source_sha256_before': before, 'source_sha256_after': after, 'source_unchanged': True,
        'old_prepared_manifest': str(old_manifest), 'old_prepared_manifest_sha256': sha(old_manifest),
        'new_prepared_manifest': str(new_manifest), 'new_prepared_manifest_sha256': sha(new_manifest),
        'old_reader_sha256': sha(original_path), 'new_reader_sha256': sha(STUDY/'check_seating_checkpoint.py'),
        'specific_original_counterexamples_reproduced_and_closed': cases,
        'valid_source_owned_synthetic_reference_metadata_accepted': True,
        'pure_arithmetic_not_native_geometry': True, 'CAD_imported_or_executed': False,
        'reviewed_journal_contracts': [
            'A random run ID, source/domain/runtime context hash, sequence and previous-record hash bind each record.',
            'The complete ordered 154-material inventory fixes 11781 pair indices; only the next unique prefix entry can be appended.',
            'Each pair is flushed and each 16th pair fsynced; construction/interruption/postflight/final commit are forced durable.',
            'Truncated tails preserve intact prefix data and never qualify a complete diagnostic.',
            'Final report bytes, final journal commit, exact journal prefix and atomic index must all match; original row errors cannot be replaced.',
            'A full raw reader separately reconstructs the domain, pair/cage geometry contracts, all current source and 43 locked package identities.',
            'The r2 base controls, original 17/6 explicit equal joints, full payload set and eleven actual physical-scope false flags are checked against source semantics.'
        ],
        'lifecycle_regression_receipt': str(lifecycle_path),
        'lifecycle_regression_receipt_sha256': sha(lifecycle_path),
        'lifecycle_cases_passed_on_original_supervisor_AST': 4,
        'current_supervisor_AST_identical_except_prepared_manifest_default': True,
        'current_preparation_tests': {'report': str(preparation), 'sha256': sha(preparation),
                                     'actual_passed': 25, 'seconds': tests['seconds'],
                                     'peak_RSS_KiB': tests['peak_RSS_KiB'], 'duplicate_suite_rerun_by_reviewer': False},
        'current_source_copies_and_old_source_copies_sha256_verified': True,
        'source_ready_for_single_original_bound_preflight_only': True,
        'native_worker_started_by_review': False, 'resource_availability_proved': False,
        'canonical_execution_checks_passed': False, 'whole_declared_seating_domain_clear': False,
        'complete_G2_qualification': False, 'physical_qualification': False}
    path = BASE/'ci_audit/seating-v2-r2-independent-review.json'
    path.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'review': str(path), 'sha256': sha(path), 'counterexamples_closed': len(cases),
                      'single_preflight_ready': True}, indent=2))


if __name__ == '__main__':
    main()
