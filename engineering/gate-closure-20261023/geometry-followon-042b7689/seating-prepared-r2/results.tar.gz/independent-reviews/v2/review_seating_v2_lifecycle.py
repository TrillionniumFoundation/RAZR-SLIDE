"""Execute only original supervisor AST with synthetic child/resource objects."""
from __future__ import annotations

import argparse
import ast
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
from types import SimpleNamespace
from unittest.mock import patch

BASE = Path('/workspace/scratch/95cd2986fdf2')
SOURCE = BASE/'input_recovery/g2_seating_v2/supervise_seating_native.py'
HEAD = '042b768903cccbd7a0995317c8598401e0318e2a'


class FakeChild:
    pid = 987654321

    def __init__(self):
        self.returncode = None
        self.wait_count = 0

    def poll(self):
        return self.returncode

    def wait(self, timeout=None):
        self.wait_count += 1
        self.returncode = -15
        return self.returncode


def main():
    raw = SOURCE.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    tree = ast.parse(raw, filename=str(SOURCE))
    selected = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)], type_ignores=[])
    code = compile(selected, str(SOURCE), 'exec')
    results = []
    with tempfile.TemporaryDirectory(prefix='razr-seating-supervisor-pure-', dir='/tmp') as folder:
        folder = Path(folder)
        fixture = folder/'synthetic-sources'; fixture.mkdir()
        (fixture/'synthetic-worker.py').write_text('# Synthetic lifecycle fixture; never executed.\n')
        fixture_digest = hashlib.sha256((fixture/'synthetic-worker.py').read_bytes()).hexdigest()
        manifest = folder/'synthetic-manifest.json'
        manifest.write_text(json.dumps({'synthetic-worker.py': {'sha256': fixture_digest}}))
        manifest_sha = hashlib.sha256(manifest.read_bytes()).hexdigest()
        for label in ('resource_OSError', 'resource_KeyboardInterrupt', 'first_post_Popen_save_OSError'):
            child = FakeChild()
            worker = SimpleNamespace(ROOT=BASE/'RAZR-SLIDE', HERE=fixture, DEFAULT_HEAD=HEAD,
                adapter_identity=lambda: {'synthetic-worker.py': fixture_digest},
                postguard=SimpleNamespace(check_environment=SimpleNamespace(
                    inspect_environment=lambda root: {'passed': True, 'checked_package_count': 43,
                                                      'synthetic_lifecycle_fixture': True})))
            namespace = {'argparse': argparse, 'dt': dt, 'hashlib': hashlib, 'json': json, 'os': os,
                         'Path': Path, 'signal': signal, 'subprocess': subprocess, 'time': time,
                         'worker': worker, 'reader': SimpleNamespace(), '__file__': str(SOURCE)}
            exec(code, namespace)
            calls = [0]
            def snapshot(path):
                calls[0] += 1
                if calls[0] == 2 and label.startswith('resource_'):
                    if label == 'resource_KeyboardInterrupt':
                        raise KeyboardInterrupt('synthetic monitored interrupt')
                    raise OSError('synthetic unavailable resource telemetry')
                return {'f_bavail_bytes': 1024*2**20, 'estimated_unreclaimable_bytes': 2**30}
            namespace['snapshot'] = snapshot
            original_save = namespace['save']
            injected = [False]
            def save(path, value):
                if (label == 'first_post_Popen_save_OSError' and value.get('worker_started') is True
                        and not injected[0]):
                    injected[0] = True
                    raise OSError('synthetic first launched-child receipt failure')
                original_save(path, value)
            namespace['save'] = save
            output = folder/label
            def git_output(command, **kwargs):
                return HEAD+'\n' if command[-2:] == ['rev-parse', 'HEAD'] else ''
            with patch.object(subprocess, 'Popen', return_value=child) as launch, \
                    patch.object(subprocess, 'check_output', side_effect=git_output), \
                    patch.object(os, 'killpg') as kill:
                exit_code = namespace['main'](['--output-directory', str(output), '--expected-head', HEAD,
                    '--prepared-manifest', str(manifest), '--prepared-sha256', manifest_sha])
                report = json.loads((output/'controller.json').read_text())
                assert exit_code == 2 and report['completed'] is False
                assert report['resource_stop_reason'] == 'supervisor_exception_cleanup'
                assert report['worker_started'] is True and launch.call_count == 1
                assert kill.call_count == 1 and kill.call_args.args == (child.pid, signal.SIGTERM)
                assert child.wait_count >= 1 and child.poll() is not None
                results.append({'case': label, 'original_exception_preserved': report['supervisor_exception'],
                                'fake_child_stop_requested_and_reaped': True, 'completion': False,
                                'controller_exit_code': exit_code})
        namespace = {'os': os, 'signal': signal, 'subprocess': subprocess}
        terminate_ast = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                                       and node.name == 'terminate'], type_ignores=[])
        exec(compile(terminate_ast, str(SOURCE), 'exec'), namespace)
        child = FakeChild()
        waits = [0]
        def raced_wait(timeout=None):
            waits[0] += 1
            if waits[0] == 1:
                raise subprocess.TimeoutExpired('synthetic child', timeout)
            child.returncode = -9
            return -9
        child.wait = raced_wait
        with patch.object(os, 'killpg', side_effect=ProcessLookupError) as kill:
            assert namespace['terminate'](child) == -9 and waits[0] == 2 and kill.call_count == 2
        results.append({'case': 'TERM_and_KILL_exit_races', 'ProcessLookupError_handled': True,
                        'fake_child_reaped': True})
    assert SOURCE.read_bytes() == raw
    record = {'schema': 'razr-seating-v2-supervisor-independent-lifecycle-review-v1',
              'source': str(SOURCE), 'sha256_before': digest, 'sha256_after': digest,
              'original_function_AST_executed': True, 'cases': results,
              'specific_regression_cases_passed': len(results),
              'resource_environment_and_children_are_synthetic': True,
              'real_subprocesses_or_native_CAD_started': False,
              'resource_availability_proved': False, 'complete_G2_qualification': False}
    target = BASE/'ci_audit/seating-v2-supervisor-lifecycle-independent-review.json'
    target.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({'review': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'cases_passed': len(results)}))


if __name__ == '__main__':
    main()
