"""Freeze final scratch SLIDE r3 and run small contracts only, never native CAD."""
from pathlib import Path
import argparse
import ast
from collections import Counter
import datetime as dt
import json
import resource
import sys
import time
import unittest

BASE = Path(__file__).resolve().parent.parent
STUDY = BASE/'g2_slide_r3'
sys.path.insert(0, str(STUDY))
resource.setrlimit(resource.RLIMIT_AS, (512*2**20, 512*2**20))
import verify_slide_native as worker


def ids(suite):
    result = []
    for item in suite:
        result.extend(ids(item) if isinstance(item, unittest.TestSuite) else [item.id()])
    return result


def preservation():
    old = BASE/'g2_slide/prepared-v2'
    manifest_path = old/'executed-source-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    originals = []
    for row in manifest['sources']:
        source, copied = Path(row['path']), old/row['copy']
        originals.append({'path': str(source), 'prepared_copy': str(copied), 'sha256': row['sha256'],
            'current_source_and_original_prepared_copy_unchanged':
                worker.sha(source) == worker.sha(copied) == row['sha256']})
    names = ('slide_domain.py', 'slide_evidence.py', 'check_slide_report.py', 'test_slide_domain.py')
    unchanged_files = {name: worker.sha(BASE/'g2_slide'/name) == worker.sha(STUDY/name) for name in names}
    test_name = 'test_slide_native_contracts.py'
    original_test = (BASE/'g2_slide'/test_name).read_text()
    updated_test = (STUDY/test_name).read_text()
    source_count_assertion_only = (original_test.count('self.assertEqual(len(paths), 11)') == 1
        and updated_test == original_test.replace('self.assertEqual(len(paths), 11)',
                                                  'self.assertEqual(len(paths), 17)'))
    old_tree = ast.parse((BASE/'g2_slide/verify_slide_native.py').read_text())
    new_tree = ast.parse((STUDY/'verify_slide_native.py').read_text())
    def functions(tree):
        return {node.name: ast.dump(node, include_attributes=False) for node in tree.body
                if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    a, b = functions(old_tree), functions(new_tree)
    names = ('BoundedBodies', 'Budget', 'BudgetExceeded', 'atomic_json', 'complete_difference',
             'evaluate_interval', 'preparation', 'profile_records', 'resource_snapshot', 'sha',
             'verify_factory_laws')
    unchanged_definitions = {name: a[name] == b[name] for name in names}
    require = worker.evidence.require
    require(all(row['current_source_and_original_prepared_copy_unchanged'] for row in originals)
            and all(unchanged_files.values()) and source_count_assertion_only
            and all(unchanged_definitions.values()),
            'original v2 or original geometry/budget definitions changed')
    return {'original_v2_prepared_manifest': str(manifest_path),
        'original_v2_prepared_manifest_sha256': worker.sha(manifest_path),
        'original_source_rows': originals, 'byte_identical_math_reader_and_test_files': unchanged_files,
        'original_native_contract_tests_only_source_count_assertion_updated_11_to_17': source_count_assertion_only,
        'AST_identical_native_geometry_and_budget_definitions': unchanged_definitions,
        'changed_worker_definitions': ['source_identity', 'run_native', 'main'],
        'added_worker_definitions': ['execution_limits', 'pair_visit_order'],
        'changes_are_source_binding_evidence_persistence_and_before_native_handshake': True,
        'original_v2_execution_has_not_been_retagged_r3': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=STUDY/'prepared-r3')
    args = parser.parse_args()
    output = args.output.resolve()
    worker.evidence.require(not output.exists() and not output.is_relative_to(worker.ROOT),
                            'fresh preparation output outside frozen repository required')
    output.mkdir(parents=True)
    before = worker.source_identity()
    worker.evidence.require(len(before) == 17, 'exact final 17-source scratch closure required')
    current = worker.evidence.postguard.current_identity(worker.ROOT, worker.DEFAULT_HEAD)
    original_before = preservation()
    harness = str(Path(__file__).resolve())
    all_sources = {**before, harness: worker.sha(harness)}
    copies = output/'executed-source-bytes'; copies.mkdir()
    manifest = []
    for i, (path, digest) in enumerate(sorted(all_sources.items())):
        copy = copies/(str(i).zfill(2)+'-'+Path(path).name)
        copy.write_bytes(Path(path).read_bytes())
        worker.evidence.require(worker.sha(copy) == worker.sha(path) == digest,
                                'execution-source copy differs from its frozen bytes')
        manifest.append({'path': path, 'sha256': digest, 'copy': str(copy.relative_to(output))})
    worker.atomic_json(output/'executed-source-manifest.json', {'sources': manifest})
    worker.atomic_json(output/'runner-preparation.json', worker.preparation(worker.DEFAULT_HEAD))
    suite = unittest.defaultTestLoader.discover(str(STUDY), pattern='test_*.py')
    test_ids = ids(suite)
    groups = dict(Counter(item.split('.')[0] for item in test_ids))
    expected = {'test_slide_domain': 9, 'test_slide_native_contracts': 18,
                'test_slide_checkpoint': 11, 'test_owned_process': 17,
                'test_slide_supervisor_lifecycle': 10}
    worker.evidence.require(groups == expected and len(test_ids) == len(set(test_ids)) == 65,
                            'unexpected or duplicate final small-contract test inventory')
    started = time.monotonic()
    with (output/'small-contract-tests.log').open('w') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    elapsed = time.monotonic()-started
    after = worker.source_identity()
    current_after = worker.evidence.postguard.current_identity(worker.ROOT, worker.DEFAULT_HEAD)
    original_after = preservation()
    CAD = any(name == 'cadquery' or name == 'OCP' or name.startswith('OCP.') for name in sys.modules)
    receipt = {'schema': 'razr-slide-r3-final-source-bound-small-contract-preparation',
        'utc_finished': dt.datetime.now(dt.timezone.utc).isoformat(),
        'functional_commit': worker.DEFAULT_HEAD, 'tests_run': result.testsRun, 'test_ids': test_ids,
        'counts_by_test_module': groups, 'failures': len(result.failures), 'errors': len(result.errors),
        'skipped': len(result.skipped), 'expected_failures': len(result.expectedFailures),
        'unexpected_successes': len(result.unexpectedSuccesses), 'elapsed_seconds': elapsed,
        'preparation_address_space_limit_bytes': 512*2**20,
        'peak_RSS_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'scratch_source_sha256_before': before, 'scratch_source_sha256_after': after,
        'repository_and_environment_before': current, 'repository_and_environment_after': current_after,
        'source_and_runtime_unchanged': before == after and current == current_after
            and all(worker.sha(path) == digest for path, digest in all_sources.items()),
        'original_v2_preservation_before': original_before,
        'original_v2_preservation_after': original_after,
        'original_v2_sources_and_prepared_copies_unchanged': original_before == original_after,
        'CAD_imported': CAD, 'native_execution_started': False, 'matrix_solver_executed': False,
        'test_raw_geometry_records_are_synthetic': True,
        'journal_tests_include_one_small_stdlib_os_exit_loss_probe': True,
        'production_worker_or_geometry_not_started_by_tests': True,
        'preliminary_test_runs_not_added_again_to_this_count': True,
        'tests_added_to_current_repository_1558_count': False,
        'complete_native_diagnostic_executed': False, 'complete_external_pair_native_clearance_proved': False,
        **{key: False for key in worker.evidence.FALSE_FLAGS}}
    receipt['small_contract_preparation_passed'] = bool(result.wasSuccessful()
        and result.testsRun == len(test_ids) == 65 and not result.skipped and not result.expectedFailures
        and not result.unexpectedSuccesses and receipt['source_and_runtime_unchanged']
        and receipt['original_v2_sources_and_prepared_copies_unchanged'] and not CAD)
    worker.atomic_json(output/'small-contract-preparation-report.json', receipt)
    print(json.dumps({key: receipt[key] for key in ('tests_run', 'elapsed_seconds', 'peak_RSS_KiB',
          'small_contract_preparation_passed', 'CAD_imported', 'native_execution_started')}))
    return 0 if receipt['small_contract_preparation_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
