"""Explicitly start one bounded scratch SLIDE run; never retries automatically."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import verify_slide_native as worker


def child_memory(pid):
    fields = {}
    try:
        for line in Path('/proc/'+str(pid)+'/status').read_text().splitlines():
            key, _, value = line.partition(':')
            if key in ('VmHWM', 'VmRSS'):
                fields[key] = int(value.split()[0])*1024
    except FileNotFoundError:
        pass
    return fields


def terminate_group(child):
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait()


def main(argv=None):
    worker.evidence.require(Path(__file__).resolve() == worker.HERE/'supervise_slide_native.py',
                            'executed supervisor differs from its explicit source-bound path')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-head', default=worker.DEFAULT_HEAD)
    parser.add_argument('--maximum-subdivision-depth', type=int, default=2, choices=range(4))
    args = parser.parse_args(argv)
    folder = args.output.resolve()
    worker.evidence.require(not folder.exists() and not folder.is_relative_to(worker.ROOT),
                            'new private native output outside frozen repository required')
    head = subprocess.check_output(['git', '-C', str(worker.ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    worker.evidence.require(head == args.expected_head and len(head) == 40, 'exact expected current HEAD required')
    worker.evidence.require(not subprocess.check_output(['git', '-C', str(worker.ROOT), 'status', '--porcelain'], text=True).strip(),
                            'clean frozen repository required')
    folder.mkdir(parents=True)
    sources = worker.source_identity()
    first = worker.resource_snapshot(folder)
    receipt = {'schema': 'razr-scratch-slide-bounded-controller-v1', 'expected_head': args.expected_head,
               'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'scratch_source_sha256_before': sources, 'worker_started': False,
               'resource_observations': [first], 'hard_wall_limit_seconds': 1800,
               'worker_peak_RSS_limit_MiB': 1536, 'shared_unreclaimable_limit_GiB': 6.8,
               'ordinary_disk_reserve_MiB': 100, 'startup_ordinary_disk_reserve_MiB': 200,
               'startup_estimated_additional_memory_reserve_MiB': 1536,
               'hosted_execution': False, **{key: False for key in worker.evidence.FALSE_FLAGS}}

    def save():
        worker.atomic_json(folder/'controller.json', receipt)

    save()
    if (first['f_bavail_bytes'] < 200*2**20
            or first['estimated_unreclaimable_bytes']+1536*2**20 > 6.8*2**30):
        receipt.update(resource_start_refused=True, completed=False)
        save()
        return 3
    copy_dir = folder/'executed-source-bytes'
    copy_dir.mkdir()
    copies = []
    for index, (path, digest) in enumerate(sorted(sources.items())):
        source = Path(path)
        destination = copy_dir/(str(index).zfill(2)+'-'+source.name)
        destination.write_bytes(source.read_bytes())
        worker.evidence.require(worker.sha(destination) == digest and worker.sha(source) == digest,
                                'source changed while freezing executed bytes')
        copies.append({'source': path, 'copy': str(destination.relative_to(folder)), 'sha256': digest})
    worker.atomic_json(folder/'executed-source-manifest.json', {'sources': copies})
    command = [str(worker.ROOT/'.venv/bin/python'), '-B', str(worker.HERE/'verify_slide_native.py'),
               '--native', '--expected-head', args.expected_head, '--output', str(folder/'report.json'),
               '--maximum-subdivision-depth', str(args.maximum_subdivision_depth)]
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1',
           'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
    receipt.update(command=command, working_directory=str(worker.ROOT))
    started = time.monotonic(); recorded = started; reason = None
    child = None
    try:
        with (folder/'native.log').open('wb') as log:
            child = subprocess.Popen(command, cwd=worker.ROOT, env=env, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            receipt.update(worker_started=True, worker_pid=child.pid)
            save()
            while child.poll() is None:
                now = worker.resource_snapshot(folder)
                memory = child_memory(child.pid)
                sample = {**now, 'elapsed_seconds': time.monotonic()-started, 'worker_memory': memory}
                if sample['elapsed_seconds'] > 1800:
                    reason = 'hard 1800-second wall budget exceeded'
                elif now['f_bavail_bytes'] < 100*2**20:
                    reason = 'ordinary-user runtime disk reserve below 100 MiB'
                elif now['estimated_unreclaimable_bytes'] > 6.8*2**30:
                    reason = 'shared estimated unreclaimable memory exceeded 6.8 GiB'
                elif max(memory.values(), default=0) > 1536*2**20:
                    reason = 'worker observed peak RSS exceeded 1536 MiB'
                if reason or time.monotonic()-recorded >= 10:
                    receipt['resource_observations'].append(sample); recorded = time.monotonic(); save()
                if reason:
                    terminate_group(child)
                    break
                time.sleep(1)
            exit_code = child.wait()
    except BaseException as exc:
        if child is not None:
            terminate_group(child)
            receipt['worker_exit_code'] = child.returncode
        receipt.update(completed=False, execution_failure=type(exc).__name__+': '+str(exc))
        # A failed disk write must not mask the original exception after the
        # owned process has been stopped and reaped. The prior receipt stays
        # incomplete if even this best-effort failure record cannot be saved.
        try:
            save()
        except BaseException:
            pass
        raise
    after = worker.source_identity()
    receipt.update(worker_exit_code=exit_code, elapsed_seconds=time.monotonic()-started,
                   scratch_source_sha256_after=after, scratch_sources_unchanged=after == sources,
                   finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                   head_after=subprocess.check_output(['git', '-C', str(worker.ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
                   worktree_clean_after=not subprocess.check_output(['git', '-C', str(worker.ROOT), 'status', '--porcelain'], text=True).strip())
    if reason:
        receipt.update(capacity_or_wall_stop=reason,
                       last_complete_checkpoint_is_partial_diagnostic_only=True)
    report_path = folder/'report.json'
    if report_path.is_file():
        receipt['report_sha256'] = worker.sha(report_path)
        try:
            report = json.loads(report_path.read_text())
            receipt['reported_complete_native_diagnostic_executed'] = report.get('complete_native_diagnostic_executed')
            receipt['reported_external_pair_domain_clear'] = report.get('whole_declared_slide_external_pair_domain_clear')
        except Exception as exc:
            receipt['report_parse_failure'] = type(exc).__name__+': '+str(exc)
    receipt['completed'] = bool(not reason and exit_code == 0 and receipt.get('reported_complete_native_diagnostic_executed') is True
                                and after == sources and receipt['head_after'] == args.expected_head
                                and receipt['worktree_clean_after'])
    receipt['resource_observations'].append(worker.resource_snapshot(folder)); save()
    print(json.dumps({key: receipt.get(key) for key in ('completed', 'worker_exit_code', 'elapsed_seconds',
          'capacity_or_wall_stop', 'reported_external_pair_domain_clear')}), flush=True)
    return 0 if receipt['completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
