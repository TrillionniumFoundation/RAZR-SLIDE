"""Package frozen SLIDE r3 preparation; preserve failed attempts and exact bytes."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import shutil
import tarfile

BASE = Path(__file__).resolve().parent.parent
STUDY = BASE/'g2_slide_r3'
OUT = BASE/'ci_audit/slide-r3-preparation-delivery'
PAYLOAD = OUT/'payload'
HEAD = '042b768903cccbd7a0995317c8598401e0318e2a'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def copy_tree(source, destination):
    source = Path(source); destination = Path(destination)
    for path in sorted(source.rglob('*')):
        if path.is_file():
            if path.is_symlink():
                raise ValueError('linked evidence is not permitted')
            target = destination/path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
            if sha(path) != sha(target):
                raise ValueError('copied evidence differs')


def main():
    OUT.mkdir(exist_ok=False); PAYLOAD.mkdir()
    prepared = STUDY/'prepared-r3-final'
    passed = json.loads((prepared/'small-contract-preparation-report.json').read_text())
    failed = json.loads((STUDY/'prepared-r3/small-contract-preparation-report.json').read_text())
    if not (passed['small_contract_preparation_passed'] is True and passed['tests_run'] == 65
            and failed['small_contract_preparation_passed'] is False and failed['errors'] == 1):
        raise ValueError('actual success and original failure receipts required')
    copies = json.loads((prepared/'executed-source-manifest.json').read_text())['sources']
    for row in copies:
        if sha(row['path']) != row['sha256'] or sha(prepared/row['copy']) != row['sha256']:
            raise ValueError('final executed source or frozen copy changed')
    copy_tree(prepared, PAYLOAD/'prepared-r3-final')
    copy_tree(STUDY/'prepared-r3', PAYLOAD/'historical/first-joint-small-test-failure')
    copy_tree(BASE/'ci_audit/slide-r3-lifecycle-preparation', PAYLOAD/'historical/initial-lifecycle-counterexample-and-fix')
    copy_tree(BASE/'input_recovery/slide-r3-journal-candidate-1', PAYLOAD/'historical/journal-candidate-1')
    copy_tree(BASE/'input_recovery/slide-r3-journal-candidate-2', PAYLOAD/'historical/journal-candidate-2')
    reviews = [BASE/'ci_audit/slide-r3-journal-independent-review.json',
               BASE/'input_recovery/slide-r3-owned-process-integration-readonly-review.json',
               BASE/'gates_audit/owned-process-helper-smoke/independent-source-review.json']
    (PAYLOAD/'reviews').mkdir()
    for path in reviews:
        shutil.copyfile(path, PAYLOAD/'reviews'/path.name)
    shutil.copyfile(__file__, PAYLOAD/'package_slide_r3_preparation.py')
    layout = [{'workspace_relative_path': str(Path(row['path']).relative_to(BASE)),
               'original_execution_path': row['path'], 'sha256': row['sha256'],
               'archive_member': 'prepared-r3-final/'+row['copy']} for row in copies]
    save(PAYLOAD/'SOURCE_LAYOUT.json', {'functional_repository_head': HEAD,
        'repository_workspace_relative_path': 'RAZR-SLIDE', 'sources': layout,
        'scratch_execution_source_count': 17, 'extra_preparation_harness_count': 1})
    stage = BASE/'evidence042-stage/engineering/gate-closure-20261023/geometry-followon-042b7689'
    references = []
    for folder, names in (
        ('slide-prepared-v2', ('results.tar.gz', 'SUMMARY.json', 'attempt1-controller.json')),
        ('slide-v2-attempt2-stopped', ('results.tar.gz', 'SUMMARY.json', 'controller.json')),
        ('owned-child-procfs-probes', ('results.tar.gz', 'original-failed-probe.json', 'successful-probe.json', 'PROTOCOL.md')),
        ('owned-process-helper-smoke', ('results.tar.gz', 'result.json', 'independent-source-review.json')),
    ):
        for name in names:
            path = stage/folder/name
            references.append({'repository_path': str(path.relative_to(BASE/'evidence042-stage')),
                               'bytes': path.stat().st_size, 'sha256': sha(path)})
    save(PAYLOAD/'REFERENCES.json', {'separate_preserved_repository_evidence': references,
        'old_native_v2_execution_is_not_relabelled_r3': True})
    smoke = json.loads((stage/'owned-process-helper-smoke/result.json').read_text())
    summary = {'schema': 'razr-slide-r3-preparation-delivery-summary',
        'functional_head': HEAD, 'state': 'prepared_only_no_r3_native_or_preflight_execution',
        'final_small_contract_tests': {'passed': True, 'count': 65,
            'components': passed['counts_by_test_module'], 'failures': 0, 'errors': 0, 'skipped': 0,
            'seconds': passed['elapsed_seconds'], 'peak_RSS_KiB': passed['peak_RSS_KiB'],
            'AS_limit_bytes': passed['preparation_address_space_limit_bytes'],
            'requested_math_threads': 1, 'raw_geometry_fixture_records_are_synthetic': True,
            'source_bound_receipt': 'prepared-r3-final/small-contract-preparation-report.json',
            'source_bound_receipt_sha256': sha(prepared/'small-contract-preparation-report.json')},
        'not_added_to_repository_1558_tests': True,
        'not_additive_with_SEATING_shared_17_helper_tests': True,
        'historical_test_runs_not_added_again': True,
        'final_scratch_source_count': 17,
        'final_source_manifest_sha256': sha(prepared/'executed-source-manifest.json'),
        'additional_preparation_harness_copied': True,
        'original_v2_sources_and_prepared_copies_unchanged': True,
        'source_and_43_package_locked_environment_unchanged_during_final_tests': True,
        'original_math_and_raw_reader_unchanged': True,
        'original_test_only_explicit_source_count_assertion_updated_11_to_17': True,
        'concrete_changes': [
            'post-Popen initial-write and monitor exceptions stop and reap the original owned process',
            'ready/release identity handshake precedes native work and verifies actual procfs PID before positive RSS sampling',
            'durable pair-start and completed-pair journal plus independently checked full publication chain',
            'original report/index digests remain bound across the raw reader; post-validation edits cannot be rebaselined'],
        'original_native_limits_unchanged': {'hard_wall_seconds': 1800, 'worker_peak_RSS_MiB': 1536,
            'shared_unreclaimable_GiB': 6.8, 'startup_disk_MiB': 200, 'runtime_disk_MiB': 100,
            'startup_incremental_memory_MiB': 1536, 'default_maximum_subdivision_depth': 2},
        'original_joint_test_failure_preserved': {'tests_run': 65, 'errors': 1,
            'failure': 'MemoryError in full synthetic pair fixture under 512 MiB AS',
            'path': 'historical/first-joint-small-test-failure',
            'correction': 'only external preparation harness now sets BLAS/math threads to one before imports',
            'same_AS_limit_retained': True, 'native_budget_or_geometry_changed': False},
        'actual_helper_end_to_end_smoke': {'passed': smoke['diagnostic_passed'],
            'child_count': smoke['child_count'], 'elapsed_seconds': smoke['elapsed_seconds'],
            'worker_native_or_CAD': False, 'child_exit_code': smoke['child_exit_code'],
            'child_reaped': smoke['child_reaped'], 'all_parent_channel_FDs_closed': smoke['all_parent_channel_FDs_closed'],
            'helper_sha256': smoke['helper_sha256_after'],
            'repository_reference': 'engineering/gate-closure-20261023/geometry-followon-042b7689/owned-process-helper-smoke/result.json'},
        'actual_original_v2_attempt2': {'worker_started': True, 'worker_exit_code': -15,
            'stop_reason': 'original shared 6.8 GiB guard', 'completed_construction_probes': 5,
            'persisted_completed_pair_records': 0, 'expected_pair_records': 11781,
            'in_memory_pair_progress_before_stop': 'unknown', 'r3_result': False},
        'r3_preflight_executed': False, 'r3_native_started': False, 'CAD_or_matrix_executed_by_final_preparation': False,
        'complete_native_diagnostic_executed': False, 'whole_declared_slide_external_pair_domain_clear': False,
        'canonical_execution_checks_passed': False, 'complete_G2_qualification': False,
        'physical_qualification': False, 'candidate_go': False,
        'fixture_fabrication_go': False, 'manufacturing_go': False}
    save(PAYLOAD/'SUMMARY.json', summary)
    readme = '''# SLIDE r3: prepared diagnostic, no r3 native execution

This successor preserves the original SLIDE mathematics, full 154-material /
11,781-pair scope, native numerical tolerances and resource limits. It adds
durable pair evidence and a verified owned-child memory sampler. The final
65 small contracts passed in the exact frozen source/runtime identity. Their
geometry rows are synthetic. They do not establish native clearance or G2.

The 65 tests consist of the original 27 arithmetic/raw contracts, 11 journal
contracts, 17 shared process controls and 10 SLIDE supervisor lifecycle controls.
The shared 17 also appear in the separate SEATING r3 preparation; do not add
them as different tests. None changes the repository's existing 1,558-test result.
The first combined preparation's actual MemoryError and all preliminary
receipts remain under `historical/`. Only the external preparation harness's
math-thread environment was corrected; its 512 MiB address-space cap stayed.

`prepared-r3-final/executed-source-manifest.json` binds the 17 execution sources
and the additional preparation harness. `SOURCE_LAYOUT.json` maps their copied
bytes to the original workspace layout. Four original math/reader/test files
are byte-identical. The copied native-contract test changes only its explicit
source-count assertion from 11 to 17. The original geometry/budget helper
definitions retain their ASTs; worker changes bind sources, persist evidence
and perform the early ready/release handshake. Original v2 sources and their
prepared copies have not changed.

The parent verifies a fresh nonce, worker source hash, original Popen PID,
procfs-visible PID, parent PID, NSpid chain, starttime and namespaces before
releasing the worker. Each later positive RSS/HWM observation is bracketed by
identity checks. Missing live-child memory is an error. Signals still target
the original Popen process group. Initial writes, pipe failures and monitor
exceptions all stop/reap that child and close owned descriptors. The separately
archived real stdlib smoke exercised this exact helper once; it was not CAD.

`pairs.jsonl` durably records pair selection before evaluation and completed
raw evidence after return. A start does not prove entry into a kernel call.
An intact prefix reports persisted progress only and never qualifies resume
or completion. Final qualification additionally needs the full report, final
commit, atomic index, stable byte hashes and the unchanged independent raw
geometry/source/runtime reader. Positive conservative enclosures remain
unresolved; a persisted record is not automatically a clear pair.

## Reproduction

Use a clean checkout of functional commit
`042b768903cccbd7a0995317c8598401e0318e2a` as `RAZR-SLIDE` beneath a workspace
containing the source layout. Restore every mapped source from the copied bytes
and verify its SHA-256 before use. The original source/runtime checks still
require the exact locked 43-package environment. Keep outputs outside the repo.

To run only the small preparation contracts in a fresh output directory:

```bash
RAZR-SLIDE/.venv/bin/python -B ci_audit/run_slide_r3_preparation.py --output /tmp/razr-slide-r3-new-preparation
```

When resources permit a separately recorded native attempt, the reviewed entry
point is the supervisor. The worker's native mode requires its private handshake:

```bash
RAZR-SLIDE/.venv/bin/python -B g2_slide_r3/supervise_slide_native.py --output /tmp/razr-slide-r3-new-native --expected-head 042b768903cccbd7a0995317c8598401e0318e2a --maximum-subdivision-depth 2
```

The original 1,800-second wall, 1,536 MiB worker RSS, 6.8 GiB shared memory,
200 MiB startup disk and 100 MiB runtime disk limits remain. Do not infer a
completed native run from this preparation bundle or from a startup refusal.
After interruption, use `check_slide_checkpoint.py --prefix ... --expected-head
... --output ...`; after normal publication use its `--report` mode. Both require
the same source layout and exact functional checkout. Never edit old receipts.

`REFERENCES.json` binds the separately preserved v2 preparation/start refusal,
the actual v2 attempt2 resource stop, both original procfs probes, and the real
final-helper smoke. The v2 native attempt completed five construction probes
but retained zero completed pair records before its shared-memory stop. That
actual result remains v2; r3 has not undergone preflight or native execution.
All canonical/full-G2/physical and fabrication/go flags remain false.
'''
    (PAYLOAD/'README.md').write_text(readme)
    members = [{'path': str(path.relative_to(PAYLOAD)), 'bytes': path.stat().st_size, 'sha256': sha(path)}
               for path in sorted(PAYLOAD.rglob('*')) if path.is_file()]
    archive = OUT/'slide-r3-prepared-042b7689.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
        for row in members:
            tar.add(PAYLOAD/row['path'], arcname=row['path'], recursive=False)
    with tarfile.open(archive, 'r:gz') as tar:
        actual = tar.getmembers()
        if len(actual) != len(members) or len({m.name for m in actual}) != len(actual):
            raise ValueError('archive member coverage differs')
        expected = {row['path']: row for row in members}
        for member in actual:
            raw = tar.extractfile(member).read(); row = expected[member.name]
            if not member.isfile() or len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('archive member failed byte readback')
    index = {'schema': 'razr-slide-r3-preparation-delivery-index',
        'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'functional_head': HEAD,
        'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
        'member_count': len(members), 'all_members_read_back_and_SHA256_verified': True, 'members': members,
        'standalone_summary': str(PAYLOAD/'SUMMARY.json'), 'standalone_readme': str(PAYLOAD/'README.md'),
        'recommended_repository_directory': 'engineering/gate-closure-20261023/geometry-followon-042b7689/slide-prepared-r3',
        'no_matrix_or_native_geometry_payload': True, 'r3_native_execution_started': False}
    save(OUT/'DELIVERY_INDEX.json', index)
    print(json.dumps({key: index[key] for key in ('archive', 'archive_bytes', 'archive_sha256',
                                               'member_count', 'all_members_read_back_and_SHA256_verified')}))


if __name__ == '__main__':
    main()
