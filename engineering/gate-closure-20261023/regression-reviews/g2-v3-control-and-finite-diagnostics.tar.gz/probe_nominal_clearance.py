"""Six explicit finite diagnostic scenes; never a continuous-domain pass."""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import math
import sys
import time

HERE=Path(__file__).resolve().parent
BOOTSTRAP=HERE/'run_overlay.py'
exec(compile(BOOTSTRAP.read_text().split("if sys.argv[1:2] == ['--tests']:")[0],str(BOOTSTRAP),'exec'))
import product_nominal_motion as motion
import verify_cam_coupling as cam
p=motion.p


def cases():
    crosshead=(cam.G-cam.R)*math.hypot(1,cam.K)
    yoke=(cam.G-cam.R)*math.sqrt(2)
    maximum=crosshead+yoke
    result=[]
    for mirror in (False,True):
        sign=-1 if mirror else 1
        result.append({'label':'MID_SLIDE_'+('RL' if mirror else 'LR'),
            'slide':39.875,'descent':0.,'tabs':[3.,3.],
            'kwargs':{'flanks':[-sign,sign],'key_offsets':[sign*maximum,-sign*maximum],
                'crosshead_offsets':[sign*crosshead,-sign*crosshead],
                'telescope_offsets':{'L':[2.7,2.9,2.9] if mirror else [2.9,2.9,2.7],
                                     'R':[2.9,2.9,2.7] if mirror else [2.7,2.9,2.9]}}})
        result.append({'label':'MID_SEAT_'+('RL' if mirror else 'LR'),
            'slide':79.75,'descent':4.1,'tabs':[3.,3.],
            'kwargs':{'flanks':[-sign,sign],
                'key_offsets':[crosshead-yoke,-maximum] if mirror else [-maximum,crosshead-yoke],
                'crosshead_offsets':[crosshead,-crosshead] if mirror else [-crosshead,crosshead],
                'telescope_offsets':{'L':[2.9,1.4,.1] if mirror else [.1,1.4,2.9],
                                     'R':[.1,1.4,2.9] if mirror else [2.9,1.4,.1]}}})
    result.append({'label':'STOW_POSITIVE_KEY_BRANCH','slide':0.,'descent':0.,'tabs':[1.125,2.375],
        'kwargs':{'flanks':[-1.,1.],'key_offsets':[maximum,yoke-crosshead],
            'crosshead_offsets':[crosshead,-crosshead],
            'telescope_offsets':{'L':[2.9,2.9,2.7],'R':[2.7,2.9,2.9]}}})
    result.append({'label':'OPEN_NEGATIVE_KEY_BRANCH','slide':79.75,'descent':8.2,'tabs':[3.,3.],
        'kwargs':{'flanks':[1.,-1.],'key_offsets':[-maximum,crosshead-yoke],
            'crosshead_offsets':[-crosshead,crosshead],
            'telescope_offsets':{'L':[.1,.1,.1],'R':[.1,.1,.1]},
            'open_hold':True,'open_support':True}})
    return result,{'crosshead_halfwidth_mm':crosshead,'yoke_halfwidth_mm':yoke,
                   'KEY_combined_halfwidth_mm':maximum}


def check_case(case):
    started=time.perf_counter()
    parts,metadata=motion.full_scene(case['slide'],case['descent'],*case['tabs'],**case['kwargs'])
    expected=161 if case['kwargs'].get('open_hold') else 154
    if len(parts)!=expected:raise ValueError('complete scene inventory differs')
    metrics={}
    for name,body in parts.items():
        p.single(body)
        metrics[name]={'bounds_mm':p.bounds(body),'volume_mm3':p.volume(body)}
    rows=[];errors=[];positive=[];native_count=0
    for a,b in itertools.combinations(sorted(parts),2):
        aa,bb=metrics[a]['bounds_mm'],metrics[b]['bounds_mm']
        gap=max(max(aa[2*i]-bb[2*i+1],bb[2*i]-aa[2*i+1]) for i in range(3))
        if gap>0:
            row={'a':a,'b':b,'common_mm3':0.,'method':'positive_axis_gap','rejected':False}
        else:
            native_count+=1
            try:
                result=p.strict_common(parts[a],parts[b])
                row={'a':a,'b':b,**result,'rejected':result['common_mm3']>motion.TOL}
                if row['rejected']:positive.append(row)
            except Exception as exc:
                row={'a':a,'b':b,'evaluation_failed':True,'error':type(exc).__name__+': '+str(exc)}
                errors.append(row)
        rows.append(row)
    # Confirm every positive result in a second complete actual construction.
    confirmations=[]
    if positive:
        actual,_=motion.full_scene(case['slide'],case['descent'],*case['tabs'],**case['kwargs'])
        if set(actual)!=set(parts):raise ValueError('fresh collision scene inventory differs')
        for row in positive:
            common=p.strict_common(actual[row['a']],actual[row['b']])['common_mm3']
            confirmations.append({'a':row['a'],'b':row['b'],'fresh_actual_common_mm3':common,
                'real_pose_native_common_confirmed':common>motion.TOL})
            if common<=motion.TOL:raise ValueError('positive Common did not reproduce in fresh actual scene')
    result={'case':case,'participant_count':len(parts),'parts':metrics,'native_scene_metadata':metadata,
        'pair_count':len(rows),'expected_pair_count':expected*(expected-1)//2,'pairs':rows,
        'native_common_evaluations':native_count,'evaluation_failures':errors,
        'rejected_pairs':positive,'fresh_actual_scene_confirmations':confirmations,
        'all_declared_finite_pairs_clear':not errors and not positive,'seconds':time.perf_counter()-started}
    if result['pair_count']!=result['expected_pair_count']:raise ValueError('pair inventory incomplete')
    print(json.dumps({'case':case['label'],'participants':len(parts),'pairs':len(rows),
        'native_common_evaluations':native_count,'positive_pairs':len(positive),
        'evaluation_failures':len(errors),'seconds':result['seconds']}),flush=True)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--expected-head',required=True)
    args=parser.parse_args()
    target=args.output.resolve()
    if target.exists() or target.is_relative_to(p.ROOT.resolve()):raise ValueError('new external diagnostic output required')
    source_files=[Path(__file__),BOOTSTRAP]
    before_extra={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in source_files}
    before=motion.execution_identity(args.expected_head)
    configurations,limits=cases()
    report={'schema':'razr-ep5-six-finite-clearance-probes-v1','identity_before':before,
        'expected_head':args.expected_head,'script_source_sha256_before':before_extra,
        'declared_groove_halfwidths':limits,'scenes':[],
        'finite_diagnostic_only':True,'complete_product_motion_proved':False,
        'full_KEY_telescope_domain_clear':False,'physical_qualification':False,
        'candidate_go':False,'fixture_fabrication_go':False,'manufacturing_go':False,
        'executed_source_overlay':True,'execution_checks_passed':False}
    failures=[]
    for case in configurations:
        try:report['scenes'].append(check_case(case))
        except Exception as exc:
            failures.append({'case':case,'error':type(exc).__name__+': '+str(exc)})
            print(json.dumps({'case':case['label'],'failure':failures[-1]['error']}),flush=True)
    after=motion.execution_identity(args.expected_head)
    after_extra={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in source_files}
    report.update(identity_after=after,script_source_sha256_after=after_extra,failed_scene_executions=failures)
    report['source_bytes_unchanged']=(before==after and before_extra==after_extra)
    report['diagnostic_execution_checks_passed']=(report['source_bytes_unchanged'] and len(report['scenes'])==6
        and not failures and all(not scene['evaluation_failures'] for scene in report['scenes']))
    report['all_six_finite_scenes_clear']=(report['diagnostic_execution_checks_passed']
        and all(scene['all_declared_finite_pairs_clear'] for scene in report['scenes']))
    with target.open('x') as stream:json.dump(report,stream,allow_nan=False,separators=(',',':'));stream.write('\n')
    print(json.dumps({'scenes':len(report['scenes']),'diagnostic_execution_checks_passed':report['diagnostic_execution_checks_passed'],
        'all_six_finite_scenes_clear':report['all_six_finite_scenes_clear'],
        'positive_pairs':sum(len(scene['rejected_pairs']) for scene in report['scenes'])}),flush=True)
    return 0 if report['diagnostic_execution_checks_passed'] else 2


if __name__=='__main__':raise SystemExit(main())
