"""Explicit scratch-code executor; repository files are not modified."""
import importlib.util
import importlib.abc
import pathlib
import runpy
import sys

ROOT = pathlib.Path('/workspace/scratch/95cd2986fdf2/RAZR-SLIDE')
DEV = pathlib.Path(__file__).resolve().parent
sys.path[:0] = [str(DEV/'integration'), str(ROOT/'integration'), str(ROOT)]
class ScratchLoader(importlib.abc.Loader):
    def create_module(self, spec):return None
    def exec_module(self,module):
        source=DEV/'integration'/(module.__name__+'.py')
        # Evaluate repository-relative path constants against original inputs;
        # retain actual executed scratch paths in every evidence receipt.
        module.__file__=str(ROOT/'integration'/source.name)
        exec(compile(source.read_text(),str(source),'exec'),module.__dict__)
        module.__file__=str(source)

class ScratchFinder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        source=DEV/'integration'/(fullname+'.py')
        if '.' not in fullname and fullname!='product_nominal_motion' and source.is_file():
            return importlib.util.spec_from_loader(fullname,ScratchLoader(),origin=str(source))

sys.meta_path.insert(0,ScratchFinder())
if sys.argv[1:2] == ['--tests']:
    import unittest
    suite = unittest.defaultTestLoader.discover(str(DEV/'tests'))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
sys.argv = [str(DEV/'integration/product_nominal_motion.py'), *sys.argv[1:]]
runpy.run_path(sys.argv[0], run_name='__main__')
