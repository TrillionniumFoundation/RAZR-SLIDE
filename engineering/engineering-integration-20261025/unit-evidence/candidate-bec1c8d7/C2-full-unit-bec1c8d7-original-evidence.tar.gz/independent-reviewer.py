"""Independent read-only C2 unit evidence checks and lossless packaging.

No suites, geometry, native applications, or numerical solvers are rerun.
"""
from pathlib import Path
import ast
from collections import Counter, defaultdict
import gzip
import hashlib
import importlib.metadata
import io
import json
import os
import platform
import re
import shutil
import subprocess
import tarfile
import time
import tomllib

ROOT = Path('/workspace/scratch/fea78049c104/RAZR-SLIDE')
RAW = ROOT.parent / 'full-unit-bec1c8d7'
OUT = Path(__file__).resolve().parent
HEAD = 'bec1c8d79a37b4ba387d606cd7ea1c5867f3f9eb'
TREE = '0eb5fb6c13645b6ce6ff9aec765d5465007efc13'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(ROOT), *args])


def main():
    started = time.monotonic()
    report = json.loads((RAW / 'report.json').read_text())
    progress = json.loads((RAW / 'progress.json').read_text())
    config = json.loads((ROOT / 'tools/test_suites.json').read_text())
    context_path = ROOT.parent / 'full-unit-bec1c8d7-context.json'
    identity_path = ROOT.parent / 'audit-work/candidate2-identity.json'
    context = json.loads(context_path.read_text())
    identity = json.loads(identity_path.read_text())
    require(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'current HEAD differs')
    require(git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE, 'current tree differs')
    require(not git('status', '--porcelain').strip(), 'worktree is not clean')
    require(report['schema'] == 'razr-unit-execution-v2' and report['scope'] == 'all_current_unit_suites', 'unsupported/full-run scope')
    require(all(report[k] == HEAD for k in ('base_commit', 'source_head_after', 'expected_head')), 'report HEAD identity differs')
    for key in ('environment_verified', 'present_tracked_bytes_match_head', 'source_bytes_unchanged',
                'source_identity_verified', 'execution_completed', 'test_checks_passed', 'passed'):
        require(report.get(key) is True, 'required report flag false: ' + key)
    for key in ('full_motion_reexecuted', 'native_KiCad_reexecuted', 'hardware_qualification',
                'candidate_go', 'manufacturing_go', 'diagnostic_unlocked', 'full_checkout_verified'):
        require(report.get(key) is False, 'scope/diagnostic flag differs: ' + key)
    for key in ('source_paths_differing_from_head', 'syntax_errors', 'changed_during_tests'):
        require(report.get(key) == [], 'nonempty report diagnostics: ' + key)
    wanted = [x['id'] for x in config['suites']]
    require(len(wanted) == len(set(wanted)) == 36, '36 unique manifest suites required')
    require(report['selected_suite_ids'] == wanted == [x['id'] for x in report['suite_results']], 'suite coverage/order differs')
    require(config['minimum_total_tests'] == sum(x['minimum_tests'] for x in config['suites']) == report['configured_minimum_tests'] == 1641, 'manifest minimum differs')
    require(progress['suite_results'] == report['suite_results'] and progress['source_hashes_before'] == report['source_hashes_before'], 'final progress differs')
    for key, path in [('suite_manifest_sha256', 'tools/test_suites.json'), ('uv_lock_sha256', 'uv.lock'), ('pyproject_sha256', 'pyproject.toml')]:
        require(report[key] == digest(ROOT / path), key + ' differs')

    qualified_ids = []
    raw_ids = defaultdict(list)
    suite_checks = []
    raw_files = {}
    zero_fields = ('failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes')
    for spec, row in zip(config['suites'], report['suite_results']):
        name = spec['id']
        child_path = RAW / (name + '.json')
        log_path = RAW / (name + '.log')
        child = json.loads(child_path.read_text())
        log = log_path.read_text()
        require(all(row[k] == value for k, value in child.items()), 'child/parent result differs: ' + name)
        require(row['exit_code'] == 0 and row['passed'] is True, 'suite unsuccessful: ' + name)
        require(all(type(row[k]) is int and row[k] == 0 for k in zero_fields), 'suite has failures/errors/skips: ' + name)
        ids = child['test_ids']
        require(len(ids) == len(set(ids)) == row['tests_run'] and all(isinstance(x, str) and x for x in ids), 'test identities invalid: ' + name)
        require(row['minimum_tests'] == spec['minimum_tests'] <= row['tests_run'], 'suite minimum differs: ' + name)
        expected_command = [report['python_executable'], '-B', str(ROOT / 'tools/run_suite.py'),
                            '--directory', str(ROOT / spec['directory']), '--minimum', str(spec['minimum_tests']),
                            '--report', str(child_path)]
        for extra in spec.get('extra_paths', []):
            expected_command += ['--extra-path', str(ROOT / extra)]
        require(row['command'] == expected_command, 'worker argv differs: ' + name)
        # unittest moves the ellipsis to a second description line when a
        # method has a docstring; the first line still contains its full id.
        logged_ids = re.findall(r'^test[^\n]*? \(([^()\n]+)\)(?: \.\.\.|$)', log, re.M)
        require(logged_ids == ids, 'raw log ordered identities differ: ' + name)
        summaries = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', log, re.M)
        require(len(summaries) == 1 and int(summaries[0][0]) == len(ids), 'raw log count differs: ' + name)
        require(re.search(r'\nOK\s*$', log) is not None, 'raw log lacks successful terminal summary: ' + name)
        for test_id in ids:
            qualified_ids.append((name, test_id))
            raw_ids[test_id].append(name)
        suite_checks.append({'id': name, 'tests_run': len(ids), 'minimum_tests': spec['minimum_tests'],
                             'raw_log_ordered_test_ids_match': True, 'raw_log_successful': True,
                             'seconds': row['seconds'], 'log_sha256': digest(log_path), 'json_sha256': digest(child_path)})
        raw_files['raw/' + log_path.name] = log_path
        raw_files['raw/' + child_path.name] = child_path
    require(len(qualified_ids) == len(set(qualified_ids)) == report['tests_run'] == 1641, 'whole-run qualified identity/count differs')

    source_map = report['source_hashes_before']
    require(source_map == report['source_hashes_after'], 'before/after source inventory differs')
    tree = {}
    for entry in git('ls-tree', '-rz', HEAD).split(b'\0'):
        if entry:
            metadata, path = entry.split(b'\t', 1)
            mode, kind, oid = metadata.split()
            tree[os.fsdecode(path)] = (mode, kind, oid.decode())
    present = set()
    for entry in git('ls-files', '-z').split(b'\0'):
        if entry:
            path = ROOT / os.fsdecode(entry)
            if path.is_file() and not path.is_symlink():
                present.add(path.relative_to(ROOT).as_posix())
    for directory in ('tools', 'tests', 'integration'):
        for path in (ROOT / directory).rglob('*'):
            if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
                present.add(path.relative_to(ROOT).as_posix())
    require(present == set(source_map), 'current present-source inventory differs')
    source_bytes = 0
    python_count = 0
    for name, expected in source_map.items():
        path = ROOT / name
        mode, kind, oid = tree[name]
        require(mode in (b'100644', b'100755') and kind == b'blob', 'nonregular source identity: ' + name)
        size = path.stat().st_size
        actual_sha = hashlib.sha256()
        actual_git = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
        with path.open('rb') as stream:
            while data := stream.read(1024 * 1024):
                actual_sha.update(data); actual_git.update(data)
        require(actual_sha.hexdigest() == expected and actual_git.hexdigest() == oid, 'source bytes differ from report or C2: ' + name)
        source_bytes += size
        if name.endswith('.py'):
            ast.parse(path.read_bytes(), filename=name)
            python_count += 1
    require(len(source_map) == 4788 and python_count == report['python_files_parsed'] == 1205, 'source/AST inventory differs')

    lock = tomllib.loads((ROOT / 'uv.lock').read_text())
    normalize = lambda s: re.sub(r'[-_.]+', '-', s).lower()
    packages = {normalize(p['name']): p['version'] for p in lock['package'] if 'registry' in p.get('source', {})}
    env = report['environment']
    require(env['passed'] is True and env['errors'] == [] and env['checked_package_count'] == len(packages) == 43, 'environment report incomplete')
    require(env['python_version'] == platform.python_version() and report['python'] == __import__('sys').version, 'Python differs')
    require(env['uv_lock_sha256'] == report['uv_lock_sha256'] and env['pyproject_sha256'] == report['pyproject_sha256'], 'environment lock binding differs')
    require(set(env['checked_packages']) == set(packages), 'locked package coverage differs')
    for name, version in packages.items():
        checked = env['checked_packages'][name]
        require(checked['expected'] == checked['observed'] == importlib.metadata.version(name) == version and checked['matches'] is True, 'locked installed version differs: ' + name)
    require(identity['candidate_source_commit'] == context['source_commit'] == HEAD and identity['candidate_source_tree'] == TREE, 'execution context/candidate identity differs')
    require(context['all_36_suites_requested'] is True and context['configured_minimum_tests'] == 1641, 'context suite scope differs')
    require(context['argv'] == [report['python_executable'], '-B', 'tools/verify.py', '--expected-head', HEAD, '--output', str(RAW)], 'context controller argv differs')
    ancestors = {}
    for name, item in identity['required_ancestors'].items():
        code = subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', item['commit'], HEAD]).returncode
        require(code == item['merge_base_exit_code'] == 0, 'required ancestry differs: ' + name)
        ancestors[name] = item['commit']
    independent = identity['PR35_independent']
    require(subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', independent['commit'], HEAD]).returncode == 1, 'PR35 ancestry differs')
    require(git('rev-parse', 'HEAD').decode().strip() == HEAD and not git('status', '--porcelain').strip(), 'repository changed during independent verification')

    receipt = {'schema': 'razr-independent-complete-unit-receipt-review-v1', 'source_commit': HEAD, 'source_tree': TREE,
               'passed': True, 'suites': 36, 'actual_test_invocations': 1641,
               'unique_suite_qualified_test_identities': len(set(qualified_ids)), 'unique_bare_test_id_strings': len(raw_ids),
               'cross_suite_repeated_bare_ids': {k: v for k, v in raw_ids.items() if len(v) > 1},
               'zero_failures_errors_skips_expected_failures_unexpected_successes': True,
               'all_36_original_log_ordered_test_ids_match_child_and_parent_receipts': True,
               'all_manifest_worker_commands_and_minima_match': True, 'all_final_progress_suite_rows_match': True,
               'present_source_paths_verified_against_report_and_exact_git_blobs': len(source_map),
               'present_source_bytes_rehashed': source_bytes, 'python_AST_reparsed': python_count,
               'full_repository_checkout_claimed': False, 'locked_packages_rechecked_from_metadata_and_uv_lock': len(packages),
               'original_report_sha256': digest(RAW / 'report.json'), 'original_context_sha256': digest(context_path),
               'original_candidate_identity_sha256': digest(identity_path), 'required_ancestors_rechecked': ancestors,
               'PR35_not_ancestor_rechecked': True, 'sum_suite_seconds': sum(row['seconds'] for row in report['suite_results']),
               'source_code_or_git_index_modified': False, 'test_or_geometry_reexecution_performed': False,
               'candidate_go': False, 'manufacturing_go': False,
               'scope': 'independent consistency and current exact-source checks of retained complete C2 unit execution evidence; no hardware or complete motion qualification',
               'suite_checks': suite_checks, 'review_seconds': time.monotonic() - started}
    receipt_path = OUT / 'INDEPENDENT_REVIEW.json'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    raw_files.update({'raw/report.json': RAW / 'report.json', 'raw/progress.json': RAW / 'progress.json',
                      'execution-context.json': context_path, 'candidate-identity.json': identity_path,
                      'INDEPENDENT_REVIEW.json': receipt_path, 'independent-reviewer.py': Path(__file__)})
    for name in ('tools/verify.py', 'tools/run_suite.py', 'tools/check_environment.py', 'tools/test_suites.json', 'uv.lock', 'pyproject.toml'):
        raw_files['controller/' + name] = ROOT / name
    members = {name: {'bytes': path.stat().st_size, 'sha256': digest(path)} for name, path in sorted(raw_files.items())}
    manifest_bytes = (json.dumps({'schema': 'razr-complete-unit-raw-member-manifest-v1', 'source_commit': HEAD, 'members': members}, indent=2) + '\n').encode()
    archive = OUT / 'C2-full-unit-bec1c8d7-original-evidence.tar.gz'
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for name, path in sorted(raw_files.items()):
                    info = tarfile.TarInfo(name); info.size = members[name]['bytes']; info.mode = 0o644
                    with path.open('rb') as stream: tar.addfile(info, stream)
                info = tarfile.TarInfo('ARCHIVE_MANIFEST.json'); info.size = len(manifest_bytes); info.mode = 0o644
                tar.addfile(info, io.BytesIO(manifest_bytes))
    with tarfile.open(archive, 'r:gz') as tar:
        actual = tar.getmembers()
        require(len(actual) == len(members) + 1 and len({x.name for x in actual}) == len(actual), 'archive member coverage differs')
        for member in actual:
            require(member.isfile(), 'archive member is not regular')
            if member.name == 'ARCHIVE_MANIFEST.json':
                require(tar.extractfile(member).read() == manifest_bytes, 'archive manifest changed')
            else:
                entry = members[member.name]
                require(member.size == entry['bytes'] and hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest() == entry['sha256'], 'archive raw bytes differ: ' + member.name)
    package = {'schema': 'razr-independent-complete-unit-raw-package-v1', 'source_commit': HEAD,
               'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive),
               'members': len(members) + 1, 'all_members_decompressed_and_hash_verified': True,
               'all_36_original_log_and_json_pairs_included': True, 'original_report_and_progress_included': True,
               'context_candidate_identity_controller_lock_and_independent_review_included': True,
               'independent_review_sha256': digest(receipt_path), 'complete_run_qualified': True,
               'candidate_go': False, 'manufacturing_go': False}
    (OUT / 'PACKAGE_RECEIPT.json').write_text(json.dumps(package, indent=2) + '\n')
    print(json.dumps(package, indent=2))
    print(json.dumps({'suite_qualified_test_ids': len(qualified_ids), 'bare_ids': len(raw_ids),
                      'cross_suite_repeated_strings': sum(len(v) - 1 for v in raw_ids.values()),
                      'source_paths': len(source_map), 'source_bytes': source_bytes, 'AST': python_count,
                      'seconds': time.monotonic() - started}))


if __name__ == '__main__':
    main()
