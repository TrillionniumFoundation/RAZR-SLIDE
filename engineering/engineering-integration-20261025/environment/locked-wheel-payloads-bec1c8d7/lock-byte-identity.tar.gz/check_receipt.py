"""Offline evidence checker for the completed inherited-wheel byte audit.

This checks structured results and exact tuple membership in the saved lock.
It does not reinstall, import audited packages, or prove installer history.
The original execution script's exit status denotes completion only.
"""
from pathlib import Path
import copy
import hashlib
import json
import sys
import tomllib

BASE = Path(__file__).resolve().parent


def check(plan, summary, reports, lock_bytes):
    errors = []

    def require(condition, message):
        if not condition:
            errors.append(message)

    lock = tomllib.loads(lock_bytes.decode())
    tuples = {
        (p['name'], p['version'], w['url'], w['hash'], w['size'])
        for p in lock['package'] for w in p.get('wheels', [])
    }
    lock_sha = hashlib.sha256(lock_bytes).hexdigest()
    require(plan['uv_lock_sha256'] == summary['uv_lock_sha256'] == lock_sha,
            'saved lock SHA differs from planned or executed lock')
    require(len(plan['packages']) == len(reports) == 21,
            'exactly 21 planned and completed package reports required')
    require(len({p['name'] for p in plan['packages']}) == 21,
            'planned package names must be unique')
    require(summary['error'] is None, 'execution reported an error')
    require(summary['completed_packages'] == 21 and summary['all_21_packages_completed'],
            'execution did not complete every inherited package')
    require(summary['uv_lock_unchanged'], 'lock changed during execution')
    require(summary['repository_head_before'] == summary['repository_head_after'],
            'repository HEAD changed during execution')
    require(not summary['installation_performed'] and
            not summary['environment_or_repository_modified'] and
            not summary['historical_installation_event_proved'] and
            not summary['runtime_generated_bytecode_proven_equal'],
            'read-only scope / excluded-history flags invalid')
    expected_names = {p['name'] for p in plan['packages']}
    require(set(reports) == expected_names, 'package report identities differ from plan')
    payload_total = metadata_total = payload_bytes = 0
    downloaded_bytes = 0
    for p in plan['packages']:
        name = p['name']
        r = reports[name]
        wheel = p['selected_wheel']
        selected = (name, p['version'], wheel['url'], wheel['hash'], wheel['size'])
        require(selected in tuples, name + ': exact selected tuple is absent from uv.lock')
        require(r['name'] == name and r['version'] == p['version'],
                name + ': report distribution identity differs')
        require(r['selected_wheel'] == wheel, name + ': report selection differs from plan')
        require(r['wheel_lock_size_and_sha256_verified'], name + ': wheel archive was not verified')
        require(not r['unmapped_wheel_members'], name + ': wheel member mapping is incomplete')
        require(not r['mismatched_payload_files'] and
                not r['mismatched_distribution_metadata_files'], name + ': original file mismatch')
        require(r['all_mapped_payload_bytes_identical'] and
                r['all_mapped_distribution_metadata_bytes_identical'], name + ': result was not equal')
        require(r['installed_payload_files_rechecked_unchanged'], name + ': installed recheck absent')
        require(not r['installation_performed'] and not r['target_package_imported'] and
                not r['historical_installation_event_proved'], name + ': forbidden scope claim')
        comparisons = r['mapped_file_comparisons']
        require(len({x['wheel_member'] for x in comparisons}) == len(comparisons),
                name + ': repeated original wheel member')
        payload = [x for x in comparisons if not x['is_distribution_metadata']]
        metadata = [x for x in comparisons if x['is_distribution_metadata']]
        require(len(payload) == r['mapped_payload_file_count'] > 0,
                name + ': empty or inconsistent payload count')
        require(len(metadata) == r['mapped_distribution_metadata_file_count'],
                name + ': inconsistent original metadata count')
        require(len(comparisons) == r['mapped_wheel_file_count'], name + ': inconsistent file count')
        require(len(r['rewritten_RECORD_comparison']) == 1 and
                r['rewritten_RECORD_comparison'][0]['wheel_member'].endswith('.dist-info/RECORD'),
                name + ': exactly one excluded installation RECORD expected')
        for item in comparisons:
            require(item['byte_identical'] and
                    item['wheel_sha256'] == item['installed_sha256'] and
                    item['wheel_bytes'] == item['installed_bytes'],
                    name + ': per-file equality evidence inconsistent at ' + item['wheel_member'])
        count_bytes = sum(x['wheel_bytes'] for x in payload)
        require(count_bytes == r['mapped_payload_bytes'], name + ': inconsistent payload byte count')
        payload_total += len(payload)
        metadata_total += len(metadata)
        payload_bytes += count_bytes
        downloaded_bytes += wheel['size']
    require(downloaded_bytes == plan['download_bytes'] == summary['planned_download_bytes'],
            'download total inconsistent')
    require(payload_total == summary['completed_original_payload_files'], 'payload total inconsistent')
    require(summary['total_unmapped_wheel_members'] == summary['total_payload_mismatch_files'] == 0,
            'summary records missing or mismatched originals')
    require(summary['all_completed_wheels_match_lock'] and
            summary['all_completed_mapped_payloads_identical'], 'summary equality flags false')
    return {'passed_current_original_wheel_file_evidence': not errors, 'errors': errors,
            'lock_sha256': lock_sha, 'packages': len(reports), 'download_bytes': downloaded_bytes,
            'payload_files': payload_total, 'original_metadata_files': metadata_total,
            'payload_bytes': payload_bytes,
            'historical_installation_event_proved': False,
            'generated_bytecode_or_entrypoint_bytes_proved': False,
            'unrecorded_files_or_loaded_memory_proved': False}


def main():
    plan = json.loads((BASE / 'plan.json').read_text())
    summary = json.loads((BASE / 'summary.json').read_text())
    reports = {name: json.loads((BASE / path).read_text())
               for name, path in summary['package_reports'].items()}
    lock_bytes = (BASE / 'inputs' / 'uv.lock').read_bytes()
    result = check(plan, summary, reports, lock_bytes)
    # Small negative checks cover the completion-only exit-code hazard and exact lock membership.
    negatives = {}
    for scenario in ('wrong_locked_tuple', 'unmapped_original', 'payload_mismatch',
                     'per_file_hash_disagreement', 'incomplete_run'):
        p = copy.deepcopy(plan)
        s = copy.deepcopy(summary)
        r = copy.deepcopy(reports)
        first = p['packages'][0]['name']
        if scenario == 'wrong_locked_tuple':
            p['packages'][0]['selected_wheel']['hash'] = 'sha256:' + '0' * 64
            r[first]['selected_wheel'] = copy.deepcopy(p['packages'][0]['selected_wheel'])
        elif scenario == 'unmapped_original':
            r[first]['unmapped_wheel_members'] = [{'wheel_member': 'missing.py'}]
        elif scenario == 'payload_mismatch':
            r[first]['all_mapped_payload_bytes_identical'] = False
            r[first]['mismatched_payload_files'] = [{'wheel_member': 'changed.py'}]
        elif scenario == 'per_file_hash_disagreement':
            r[first]['mapped_file_comparisons'][0]['installed_sha256'] = '0' * 64
        elif scenario == 'incomplete_run':
            s['completed_packages'] = 20
        negatives[scenario] = not check(p, s, r, lock_bytes)['passed_current_original_wheel_file_evidence']
    result['negative_checks'] = negatives
    result['all_negative_checks_rejected'] = all(negatives.values())
    result['checker_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (BASE / 'receipt-check.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if result['passed_current_original_wheel_file_evidence'] and all(negatives.values()) else 1


if __name__ == '__main__':
    raise SystemExit(main())
