"""Read-only current installed files versus hash-locked wheel members.
No installation, extraction, target-package import or environment mutation.
"""
from pathlib import Path, PurePosixPath
import argparse, base64, csv, datetime, hashlib, importlib.metadata as metadata
import io, json, os, re, stat, subprocess, sys, sysconfig, time, urllib.request, zipfile

BASE=Path(__file__).resolve().parent
PLAN=BASE/'plan.json'
WHEELS=Path('/dev/shm/razr-lock-byte-identity-20261025')
ROOT=Path('/workspace/scratch/fea78049c104/RAZR-SLIDE')
LIMIT=6.3*1024**3
CHUNK=1024**2

class ResourcePause(Exception): pass

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while data:=stream.read(CHUNK): digest.update(data)
    return digest.hexdigest()

def resources():
    data={line.split()[0]:int(line.split()[1]) for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines()}
    disk=os.statvfs(ROOT); memory=os.statvfs('/dev/shm')
    return {'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'cgroup_current_bytes':int(Path('/sys/fs/cgroup/memory.current').read_text()),
        'shared_unreclaimable_bytes':sum(data.get(k,0) for k in ('anon','shmem','kernel_stack','pagetables','sock','slab_unreclaimable')),
        **{k+'_bytes':data.get(k) for k in ('anon','shmem','file','inactive_file','active_file')},
        'ordinary_filesystem_available_bytes':disk.f_bavail*disk.f_frsize,
        'tmpfs_available_bytes':memory.f_bavail*memory.f_frsize}

def guard(samples):
    sample=resources(); samples.append(sample)
    if sample['ordinary_filesystem_available_bytes']<500*1024**2:
        raise ResourcePause('ordinary filesystem below 500 MiB reserve')
    if sample['shared_unreclaimable_bytes']>=LIMIT:
        raise ResourcePause('shared unreclaimable memory reached 6.3 GiB pause threshold')

def compare_streams(left,right,samples):
    lh=hashlib.sha256();rh=hashlib.sha256();ln=rn=0;equal=True
    while True:
        guard(samples)
        a=left.read(CHUNK);b=right.read(CHUNK)
        if not a and not b:break
        lh.update(a);rh.update(b);ln+=len(a);rn+=len(b)
        if a!=b:equal=False
    return {'wheel_bytes':ln,'installed_bytes':rn,'wheel_sha256':lh.hexdigest(),'installed_sha256':rh.hexdigest(),'byte_identical':equal}

def mapped_path(member,dist,site,package):
    parts=PurePosixPath(member).parts
    if PurePosixPath(member).is_absolute() or '..' in parts or not parts:
        raise ValueError('unsafe wheel member name')
    if parts[0].endswith('.data'):
        if len(parts)<3:return None,'unsupported data directory'
        kind=parts[1];relative=Path(*parts[2:])
        if kind in ('purelib','platlib'):return site/relative,'site spread'
        prefix=site.parents[2]
        if kind=='scripts':return prefix/'bin'/relative,'script spread; installer may rewrite shebang'
        if kind=='data':return prefix/relative,'prefix data spread'
        return None,'unmapped wheel data category '+kind
    return site/Path(*parts),'wheel root'

def run_package(row,samples):
    selected=row['selected_wheel']; target=WHEELS/selected['filename'];partial=target.with_suffix('.whl.part')
    started=time.monotonic(); guard(samples)
    if not selected['url'].startswith('https://files.pythonhosted.org/'):
        raise ValueError('only original locked public PyPI file URLs accepted')
    if not target.exists():
        if partial.exists():raise ValueError('unreviewed prior partial wheel exists')
        h=hashlib.sha256();count=0
        with urllib.request.urlopen(selected['url'],timeout=30) as response,partial.open('xb') as sink:
            while data:=response.read(CHUNK):
                guard(samples);sink.write(data);h.update(data);count+=len(data)
        if count!=selected['size'] or h.hexdigest()!=selected['hash'].split(':',1)[1]:
            raise ValueError('wheel size/hash does not match uv.lock')
        partial.rename(target)
    if target.stat().st_size!=selected['size'] or sha(target)!=selected['hash'].split(':',1)[1]:
        raise ValueError('retained wheel size/hash mismatch')
    dist=metadata.distribution(row['name']);site=Path(dist.locate_file('')).resolve()
    if str(dist._path)!=row['installed_distribution_metadata'] or dist.version!=row['version'] or str(site)!=row['installed_site_root']:
        raise ValueError('installed distribution identity changed after planning')
    if Path(sys.base_prefix).resolve() not in site.parents:
        raise ValueError('expected inherited base site package')
    mapped=[];unmapped=[];symlinks=[];metadata_changes=[];declared_record={};expected_installed=set()
    with zipfile.ZipFile(target) as wheel:
        infos=wheel.infolist();names=[x.filename for x in infos]
        if len(names)!=len(set(names)):raise ValueError('duplicate wheel archive members')
        records=[n for n in names if n.endswith('.dist-info/RECORD')]
        if len(records)!=1:raise ValueError('one original wheel RECORD required')
        for path,digest,size in csv.reader(io.StringIO(wheel.read(records[0]).decode())):
            if path in declared_record:raise ValueError('duplicate original wheel RECORD row')
            declared_record[path]=(digest,size)
        for info in infos:
            if info.is_dir():continue
            guard(samples)
            if stat.S_ISLNK(info.external_attr>>16):raise ValueError('wheel symbolic-link member unsupported')
            if info.filename not in declared_record:raise ValueError('wheel file missing from original RECORD')
            installed,mapping=mapped_path(info.filename,dist,site,row['name'])
            item={'wheel_member':info.filename,'mapping':mapping}
            if installed is None:
                unmapped.append(item);continue
            item['installed_path']=str(installed);expected_installed.add(Path(os.path.abspath(installed)))
            if not installed.is_file():item['reason']='installed path missing';unmapped.append(item);continue
            if installed.is_symlink():symlinks.append({'path':str(installed),'target':str(installed.resolve())})
            with wheel.open(info) as original,installed.open('rb') as current:
                item.update(compare_streams(original,current,samples))
            expected_hash,expected_size=declared_record[info.filename]
            if expected_hash:
                algorithm,value=expected_hash.split('=',1)
                if algorithm!='sha256' or base64.urlsafe_b64encode(bytes.fromhex(item['wheel_sha256'])).decode().rstrip('=')!=value:
                    raise ValueError('wheel member differs from original RECORD digest')
                if expected_size and int(expected_size)!=item['wheel_bytes']:raise ValueError('wheel member size differs from original RECORD')
            if info.filename.endswith('.dist-info/RECORD'):
                item['classification']='installation RECORD is rewritten by installers; excluded from payload equivalence'
                metadata_changes.append(item)
            else:
                item['is_distribution_metadata']='.dist-info/' in info.filename
                mapped.append(item)
    extras=[]
    for f in dist.files or []:
        path=Path(os.path.abspath(dist.locate_file(f)))
        if path in expected_installed:continue
        s=str(f)
        if s.endswith('.pyc') and '__pycache__' in s:classification='generated bytecode not present in wheel; not recompiled or executed by this audit'
        elif '/.dist-info/' in '/'+s or '.dist-info/' in s:classification='installer-added distribution metadata; not proof of historical installation'
        else:classification='installed RECORD entry absent from selected wheel; not mapped or silently accepted'
        extras.append({'installed_record_path':s,'installed_path':str(path),'classification':classification,'exists':path.is_file()})
    for item in mapped+metadata_changes:
        if sha(item['installed_path'])!=item['installed_sha256']:raise ValueError('installed bytes changed during comparison')
    payload=[x for x in mapped if not x['is_distribution_metadata']];distmeta=[x for x in mapped if x['is_distribution_metadata']]
    result={'name':row['name'],'version':row['version'],'selected_wheel':selected,'wheel_local_path':str(target),'wheel_lock_size_and_sha256_verified':True,'installed_distribution_metadata':str(dist._path),
        'mapped_wheel_file_count':len(mapped),'mapped_payload_file_count':len(payload),'mapped_distribution_metadata_file_count':len(distmeta),
        'mapped_payload_bytes':sum(x['wheel_bytes'] for x in payload),'all_mapped_payload_bytes_identical':all(x['byte_identical'] for x in payload),
        'all_mapped_distribution_metadata_bytes_identical':all(x['byte_identical'] for x in distmeta),'unmapped_wheel_members':unmapped,
        'mismatched_payload_files':[x for x in payload if not x['byte_identical']],
        'mismatched_distribution_metadata_files':[x for x in distmeta if not x['byte_identical']],
        'installed_payload_files_rechecked_unchanged':True,'installed_symlinks':symlinks,'rewritten_RECORD_comparison':metadata_changes,'installed_extra_record_entries':extras,
        'mapped_file_comparisons':mapped,'seconds':time.monotonic()-started,'installation_performed':False,'target_package_imported':False,'historical_installation_event_proved':False,
        'scope':'current installed wheel-owned original file bytes compared with one platform-compatible lock-pinned wheel; generated bytecode/entrypoints and in-memory execution are outside equivalence claim'}
    (BASE/(row['name']+'-comparison.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result

def main():
    plan=json.loads(PLAN.read_text());samples=[];rows=[];error=None
    if not plan['under_300MiB_budget'] or plan['download_bytes']>300*1024**2:raise ValueError('download budget exceeded')
    started=time.monotonic();lock_before=sha(ROOT/'uv.lock');head_before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    try:
        guard(samples)
        if lock_before != plan['uv_lock_sha256']:raise ValueError('uv.lock changed since selection plan')
        if sha(Path(plan['overlay_requirements_path'])) != plan['overlay_requirements_sha256']:raise ValueError('overlay requirements changed since selection plan')
        if len(plan['packages']) != 21 or len({row['name'] for row in plan['packages']}) != 21:raise ValueError('exactly 21 unique inherited packages required')
        WHEELS.mkdir(exist_ok=False)
        for row in plan['packages']:
            result=run_package(row,samples);rows.append(result)
            print(json.dumps({'package':result['name'],'payload_files':result['mapped_payload_file_count'],'payload_bytes_identical':result['all_mapped_payload_bytes_identical'],'unmapped_wheel_members':len(result['unmapped_wheel_members']),'mismatches':len(result['mismatched_payload_files'])}),flush=True)
    except Exception as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
    finally:
        end=resources();samples.append(end)
        source=sha(Path(__file__))
        summary={'schema':'razr-inherited-locked-wheel-byte-comparison-v1','python':sys.version,'script_sha256':source,'uv_lock_sha256':lock_before,'uv_lock_unchanged':sha(ROOT/'uv.lock')==lock_before,
            'repository_head_before':head_before,'repository_head_after':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'planned_packages':21,'completed_packages':len(rows),'planned_download_bytes':plan['download_bytes'],
            'all_21_packages_completed':len(rows)==21 and error is None,'all_completed_wheels_match_lock':bool(rows) and all(x['wheel_lock_size_and_sha256_verified'] for x in rows),'all_completed_mapped_payloads_identical':bool(rows) and all(x['all_mapped_payload_bytes_identical'] for x in rows),
            'total_unmapped_wheel_members':sum(len(x['unmapped_wheel_members']) for x in rows),'total_payload_mismatch_files':sum(len(x['mismatched_payload_files']) for x in rows),'completed_original_payload_files':sum(x['mapped_payload_file_count'] for x in rows),
            'generated_and_installer_added_entries_outside_equivalence_claim':sum(len(x['installed_extra_record_entries']) for x in rows),'historical_installation_event_proved':False,'installation_performed':False,'environment_or_repository_modified':False,
            'runtime_generated_bytecode_proven_equal':False,'error':error,'seconds':time.monotonic()-started,'resources_start':samples[0],'resources_end':end,'peak_observed_shared_unreclaimable_bytes':max(x['shared_unreclaimable_bytes'] for x in samples),
            'ordinary_filesystem_minimum_available_bytes':min(x['ordinary_filesystem_available_bytes'] for x in samples),'resource_sample_count':len(samples),'scope':'current installed original wheel-owned files only; generated bytecode, entry points not shipped as wheel members, in-memory execution, unrecorded files and historical installer provenance are not established','package_reports':{x['name']:x['name']+'-comparison.json' for x in rows}}
        (BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(BASE/'resource-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
        print(json.dumps({k:summary[k] for k in ('completed_packages','all_completed_mapped_payloads_identical','total_unmapped_wheel_members','total_payload_mismatch_files','error','seconds','peak_observed_shared_unreclaimable_bytes')},indent=2),flush=True)
    return 0 if error is None and len(rows)==21 else 2

if __name__=='__main__':raise SystemExit(main())
