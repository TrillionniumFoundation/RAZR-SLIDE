"""External readback launcher preserving the frozen supervisor import order.
The standalone checkpoint-reader CLI defect is separately retained unchanged.
No repository source, identity check, or physical criterion is modified.
"""
import sys
from pathlib import Path
here = Path("/workspace/scratch/fea78049c104/RAZR-SLIDE/engineering/engineering-integration-20261025/geometry/slide")
sys.path.insert(0, str(here))
import supervise_slide_native as supervisor
raise SystemExit(supervisor.reader.main(sys.argv[1:]))
