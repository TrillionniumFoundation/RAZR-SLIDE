"""Readback using the frozen supervisor module's import order, in a new process.
The original standalone reader CLI failure remains separately recorded.
No repository source, identity check, or physical criterion is modified.
"""
import sys
from pathlib import Path
here = Path("/workspace/scratch/fea78049c104/RAZR-SLIDE/engineering/engineering-integration-20261025/geometry/slide")
sys.path.insert(0, str(here))
import supervise_slide_native
import check_slide_checkpoint as checkpoint_reader
raise SystemExit(checkpoint_reader.main(sys.argv[1:]))
