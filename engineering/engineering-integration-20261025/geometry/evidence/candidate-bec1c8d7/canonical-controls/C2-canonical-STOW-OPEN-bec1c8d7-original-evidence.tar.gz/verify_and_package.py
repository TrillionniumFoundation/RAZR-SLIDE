"""Independently audit and archive existing C2 canonical control receipts.

This does not run CAD, change repository files, or promote fixed-pose coverage
to a whole-product, physical, fabrication, or manufacturing qualification.
"""
from __future__ import annotations

import collections
import gzip
import hashlib
import importlib.metadata
import io
import itertools
import json
from pathlib import Path
import platform
import subprocess
import tarfile
import tomllib

ROOT = Path('/workspace/scratch/fea78049c104/RAZR-SLIDE')
OUT = Path(__file__).resolve().parent
HEAD = 'bec1c8d79a37b4ba387d606cd7ea1c5867f3f9eb'
TREE = '0eb5fb6c13645b6ce6ff9aec765d5465007efc13'


def need(value, explanation):
    if not value:
        raise ValueError(explanation)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def check_clean():
    need(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'C2 HEAD changed')
    need(git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE, 'C2 tree changed')
    need(git('status', '--porcelain=v1') == b'', 'repository is not clean')


def main():
    check_clean()
    context = json.loads((OUT / 'CONTEXT.json').read_bytes())
    need(context['source_commit'] == HEAD and context['diagnostic_overlay'] is False,
         'wrong context identity or diagnostic overlay')
    need(context['source_or_repo_writes'] is False, 'context allows repository writes')
    reports = {pose: json.loads((OUT / f'{pose}-report.json').read_bytes())
               for pose in ('STOW', 'OPEN')}
    identities = [report[key] for report in reports.values()
                  for key in ('identity_before', 'identity_after')]
    need(all(value == identities[0] for value in identities),
         'before/after/between-pose source or environment identity differs')
    ident = identities[0]
    need(ident['repository_head'] == HEAD, 'report HEAD is not C2')
    need(ident['executed_source_overlay'] is False
         and ident['outside_repository_executed_files'] == [], 'source overlay/outside import')

    # Rehash every source path from both recorded identity maps and independently
    # bind its exact Git blob to the immutable local C2 tree.
    tree = {}
    for item in git('ls-tree', '-r', '-z', HEAD).split(b'\0'):
        if not item:
            continue
        header, path = item.split(b'\t', 1)
        mode, kind, blob = header.decode().split()
        if kind == 'blob':
            tree[path.decode()] = {'mode': mode, 'git_blob_sha1': blob}
    wanted = dict(ident['head_bound_source_sha256'])
    for absolute, expected in ident['executed_source_sha256'].items():
        rel = str(Path(absolute).relative_to(ROOT))
        need(rel not in wanted or wanted[rel] == expected, f'inconsistent source hashes: {rel}')
        wanted[rel] = expected
    sources = {}
    for rel, expected in sorted(wanted.items()):
        path = ROOT / rel
        need(not path.is_symlink(), f'source symlink: {rel}')
        data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        need(sha(data) == expected, f'current source SHA differs: {rel}')
        need(rel in tree and blob == tree[rel]['git_blob_sha1'], f'C2 Git blob differs: {rel}')
        sources[rel] = {'bytes': len(data), 'sha256': expected, 'git_blob_sha1': blob}

    env = ident['environment']
    lock_bytes = (ROOT / 'uv.lock').read_bytes()
    lock = tomllib.loads(lock_bytes.decode())
    registry = {package['name']: package['version'] for package in lock['package']
                if 'registry' in package.get('source', {})}
    need(env['passed'] is True and env['errors'] == [], 'original environment failed')
    need(env['checked_package_count'] == len(registry) == 43, 'wrong lock package coverage')
    need(env['uv_lock_sha256'] == sha(lock_bytes), 'lock changed')
    need(env['pyproject_sha256'] == sha((ROOT / 'pyproject.toml').read_bytes()), 'pyproject changed')
    need(env['python_version'] == platform.python_version() == '3.12.14', 'interpreter mismatch')
    need(set(env['checked_packages']) == set(registry), 'recorded package inventory differs')
    for name, version in registry.items():
        record = env['checked_packages'][name]
        need(record == {'expected': version, 'observed': version, 'matches': True},
             f'recorded version mismatch: {name}')
        need(importlib.metadata.version(name) == version, f'current installed version differs: {name}')

    poses = {}
    for pose, count in (('STOW', 154), ('OPEN', 161)):
        report = reports[pose]
        postguard = json.loads((OUT / f'{pose}-postguard.json').read_bytes())
        execution = json.loads((OUT / f'{pose}-postguard-execution.json').read_bytes())
        supervisor = json.loads((OUT / f'{pose}-supervisor.json').read_bytes())
        raw = (OUT / f'{pose}-report.json').read_bytes()
        need(report['schema'] == 'razr-ep5-independent-control-domain-v2', 'wrong raw schema')
        need(report['pose'] == pose and report['expected_head'] == HEAD, 'wrong pose/head')
        for key in ('execution_completed', 'execution_checks_passed',
                    'all_unordered_pairs_present_once', 'source_bytes_unchanged',
                    'whole_declared_control_domain_clear'):
            need(report[key] is True, f'{pose}: {key} did not pass')
        for key in ('executed_source_overlay', 'complete_product_motion_proved',
                    'physical_qualification', 'candidate_go', 'fixture_fabrication_go',
                    'manufacturing_go', 'formal_directed_rounding_certificate'):
            need(report[key] is False, f'{pose}: improper scope promotion: {key}')
        names = report['complete_participant_names']
        need(len(set(names)) == len(names) == report['participant_count'] == count,
             f'{pose}: participant coverage')
        expected_pairs = set(itertools.combinations(sorted(names), 2))
        seen_pairs = [tuple(sorted((pair['a'], pair['b']))) for pair in report['pairs']]
        need(len(seen_pairs) == len(set(seen_pairs)) == len(expected_pairs)
             and set(seen_pairs) == expected_pairs, f'{pose}: pair coverage')
        need(report['pair_count'] == report['expected_pair_count'] == len(expected_pairs),
             f'{pose}: pair totals')
        counts = dict(collections.Counter(pair['disposition'] for pair in report['pairs']))
        need(counts == report['counts'] == {'clear': len(expected_pairs)}, f'{pose}: not all clear')
        for key in ('unresolved_pairs', 'confirmed_collision_witnesses', 'evaluation_failures'):
            need(report[key] == [], f'{pose}: {key} nonempty')
        need(report['evaluation_failure_count'] == 0, f'{pose}: evaluation failures')
        need(supervisor['exit_code'] == 0 and supervisor['resource_stop_reason'] is None
             and supervisor['supervisor_error'] is None, f'{pose}: worker/supervisor failed')
        need(supervisor['log_sha256'] == sha((OUT / f'{pose}-worker.log').read_bytes()),
             f'{pose}: worker log hash differs')
        helper = ROOT / 'engineering/engineering-integration-20261025/numerics/run_bounded.py'
        need(supervisor['supervisor_source_sha256'] == supervisor['supervisor_source_sha256_after']
             == sha(helper.read_bytes()) and supervisor['supervisor_source_unchanged'] is True,
             f'{pose}: supervisor source differs')
        need(supervisor['sampled_peak_nonreclaimable_budget_bytes']
             <= context['shared_nonreclaimable_budget_bytes'], f'{pose}: shared budget exceeded')
        need(supervisor['minimum_filesystem_available_bytes']
             >= context['task_filesystem_reserve_bytes'], f'{pose}: reserve violated')
        need(execution['exit_code'] == 0 and execution['report_sha256'] == sha(raw),
             f'{pose}: original postguard did not accept these bytes')
        stdout = (OUT / f'{pose}-postguard.stdout.log').read_bytes()
        stderr = (OUT / f'{pose}-postguard.stderr.log').read_bytes()
        need(stdout == (OUT / f'{pose}-postguard.json').read_bytes() and stderr == b'',
             f'{pose}: original postguard streams differ')
        need(execution['postguard_stdout_sha256'] == sha(stdout)
             and execution['postguard_stderr_sha256'] == sha(stderr), f'{pose}: postguard stream hashes')
        need(execution['validator_sha256'] == sha((ROOT / 'tools/validate_product_nominal_report.py').read_bytes()),
             f'{pose}: validator source differs')
        need(postguard['bounded_control_receipt_checks_passed'] is True
             and postguard['source_commit'] == HEAD and postguard['pose'] == pose
             and postguard['participant_count'] == count
             and postguard['unique_unordered_pairs'] == len(expected_pairs),
             f'{pose}: original postguard coverage does not match')
        need(postguard['geometry_recomputed_by_postcheck'] is False
             and postguard['complete_product_motion_proved'] is False
             and postguard['physical_qualification'] is False, f'{pose}: postguard scope differs')
        poses[pose] = {
            'participant_count': count, 'unique_unordered_pairs': len(expected_pairs),
            'counts_independently_rederived': counts,
            'raw_report_bytes': len(raw), 'raw_report_sha256': sha(raw),
            'whole_declared_control_domain_clear': True, 'evaluation_failure_count': 0,
            'geometry_seconds': report['seconds'], 'postguard_exit_code': 0,
            'postguard_stdout_sha256': sha(stdout),
            'supervisor': {key: value for key, value in supervisor.items() if key != 'samples'},
            'supervisor_sample_count': len(supervisor['samples']),
            'domain': report['domain'],
        }

    write_json(OUT / 'SOURCE_IDENTITY_RECHECK.json', {
        'schema': 'razr-canonical-control-source-recheck-v1', 'source_commit': HEAD,
        'source_tree': TREE, 'source_path_count': len(sources),
        'source_total_bytes': sum(value['bytes'] for value in sources.values()),
        'head_bound_map_path_count': len(ident['head_bound_source_sha256']),
        'executed_map_path_count': len(ident['executed_source_sha256']),
        'all_current_bytes_and_C2_git_blobs_match': True, 'sources': sources,
    })
    summary = {
        'schema': 'razr-canonical-control-pair-independent-archive-summary-v1',
        'source_commit': HEAD, 'source_tree': TREE, 'source_clean_before_and_after': True,
        'original_reports_modified': False, 'geometry_recomputed_by_this_review': False,
        'original_generator_and_original_postguard_used': True,
        'before_after_and_between_pose_identities_exactly_equal': True,
        'all_current_source_bytes_and_C2_git_blobs_match': True,
        'source_path_count_independently_rehashed': len(sources),
        'locked_registry_package_versions_rechecked': len(registry),
        'python_version': platform.python_version(),
        'installation_artifact_provenance_verified_by_this_check': False,
        'scope': 'Complete declared independent control domains at fixed STOW and OPEN poses.',
        'not_covered': ['slide and seating paths', 'KEY backlash', 'accessory assembly',
                        'manufacturing tolerances', 'forces', 'physical operation'],
        'same_CAD_kernel': True, 'formal_directed_rounding_certificate': False,
        'complete_product_motion_proved': False, 'physical_qualification': False,
        'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False,
        'poses': poses,
    }
    check_clean()
    write_json(OUT / 'SUMMARY.json', summary)

    # Include original bytes plus the exact entry points, identity checker and lock;
    # the remaining immutable repository sources/inputs are referenced by C2/SHA.
    snapshots = [
        'integration/product_nominal_motion.py', 'integration/translation_regions.py',
        'integration/product_assembly.py', 'tools/validate_product_nominal_report.py',
        'tools/check_environment.py', 'tools/verify.py',
        'engineering/engineering-integration-20261025/numerics/run_bounded.py',
        'uv.lock', 'pyproject.toml', '.python-version',
    ]
    members = {path.name: path.read_bytes() for path in OUT.iterdir()
               if path.is_file() and path.suffix not in ('.gz',)
               and path.name not in ('PACKAGE_RECEIPT.json', 'MEMBER_SHA256.json')}
    for rel in snapshots:
        members['sources/' + rel] = (ROOT / rel).read_bytes()
    manifest = {name: {'bytes': len(data), 'sha256': sha(data)}
                for name, data in sorted(members.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    (OUT / 'MEMBER_SHA256.json').write_bytes(manifest_bytes)
    members['MEMBER_SHA256.json'] = manifest_bytes
    archive = OUT / 'C2-canonical-STOW-OPEN-bec1c8d7-original-evidence.tar.gz'
    with archive.open('wb') as dest:
        with gzip.GzipFile(filename='', mode='wb', fileobj=dest, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, data in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        names = tar.getnames()
        need(len(names) == len(set(names)) == len(members) and set(names) == set(members),
             'archive membership differs')
        for member in tar.getmembers():
            need(member.isfile(), 'non-regular archive member')
            data = tar.extractfile(member).read()
            need(data == members[member.name], f'archive bytes differ: {member.name}')
    receipt = {
        'schema': 'razr-canonical-control-original-evidence-package-v1',
        'source_commit': HEAD, 'source_tree': TREE, 'archive': str(archive),
        'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive.read_bytes()),
        'member_count': len(members), 'uncompressed_member_bytes': sum(map(len, members.values())),
        'all_members_decompressed_and_byte_verified': True,
        'member_manifest_sha256': sha(manifest_bytes),
        'summary_sha256': sha((OUT / 'SUMMARY.json').read_bytes()),
        'original_raw_report_sha256': {pose: poses[pose]['raw_report_sha256'] for pose in poses},
        'complete_product_motion_proved': False, 'physical_qualification': False,
        'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False,
    }
    write_json(OUT / 'PACKAGE_RECEIPT.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
