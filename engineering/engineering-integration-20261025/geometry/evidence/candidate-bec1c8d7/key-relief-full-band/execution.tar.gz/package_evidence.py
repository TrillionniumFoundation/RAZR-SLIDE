#!/usr/bin/env python3
"""Package completed finite KEY research evidence without changing its source checkout."""
from __future__ import annotations
import argparse
import datetime as dt
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--candidate', required=True)
    p.add_argument('--trial', type=Path, required=True)
    p.add_argument('--reader', type=Path, required=True)
    p.add_argument('--launch', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    repo = a.repo.resolve()
    assert not a.output.exists(), 'new package directory required'
    a.output.mkdir(parents=True)
    git = lambda *v: subprocess.check_output(['git', '-C', str(repo), *v])
    assert git('rev-parse', 'HEAD').decode().strip() == a.candidate
    assert not git('status', '--porcelain').strip(), 'source checkout must remain frozen'
    report = json.loads((a.trial/'trial/report.json').read_text())
    reader = json.loads((a.reader/'readback.json').read_text())
    controllers = [json.loads((q/'controller.json').read_text()) for q in (a.trial, a.reader)]
    assert report['execution_completed'] and report['all_unordered_pairs_present_once']
    assert reader['passed'] and reader['native_readback_executed']
    assert reader['report_sha256'] == digest((a.trial/'trial/report.json').read_bytes())
    assert all(c['completed'] and c['worker_exit_code'] == 0 and c['source_bytes_unchanged']
               and c['locked_environment_unchanged'] for c in controllers)
    assert report['identity_before']['repository_head_at_start'] == a.candidate
    assert report['identity_before']['worktree_status_at_start'] == ''
    assert report['identity_after']['repository_head_at_finish'] == a.candidate
    assert report['identity_after']['source_bytes_and_locked_environment_unchanged']
    assert report['identity_after']['changed_or_late_sources'] == []
    tree = {}
    for entry in git('ls-tree', '-rz', a.candidate).split(b'\0'):
        if not entry:
            continue
        header, path = entry.split(b'\t', 1)
        mode, kind, sha = header.decode().split()
        tree[path.decode()] = (mode, kind, sha)
    identities = dict(report['identity_after']['executed_source_and_input_sha256'])
    for c in controllers:
        for path, sha in c['source_sha256_before'].items():
            assert identities.get(path, sha) == sha
            identities[path] = sha
    for path, sha in reader['source_sha256'].items():
        assert identities.get(path, sha) == sha
        identities[path] = sha
    members = {}
    for role, directory in (('execution', a.trial), ('independent-reader', a.reader)):
        for path in sorted(directory.rglob('*')):
            assert not path.is_symlink()
            if path.is_file():
                members[role+'/'+str(path.relative_to(directory))] = path.read_bytes()
    members['launch.json'] = a.launch.read_bytes()
    records = []
    for path, sha in sorted(identities.items()):
        path = Path(path)
        rel = str(path.relative_to(repo))
        data = path.read_bytes()
        git_sha = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert digest(data) == sha, rel
        assert tree[rel][1] == 'blob' and tree[rel][2] == git_sha, rel
        textual = path.suffix in ('.py', '.json', '.toml', '.lock')
        if textual:
            members['source/'+rel] = data
        records.append({'path': rel, 'bytes': len(data), 'sha256': sha,
                        'git_blob_sha': git_sha, 'matches_frozen_candidate': True,
                        'source_snapshot_in_bundle': textual,
                        'immutable_source': 'https://github.com/TrillionniumFoundation/RAZR-SLIDE/blob/'+a.candidate+'/'+rel})
    identity = {
        'schema': 'razr-postexecution-finite-source-binding-v1',
        'verified_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'candidate_source_commit': a.candidate,
        'candidate_tree': git('rev-parse', a.candidate+'^{tree}').decode().strip(),
        'original_worker_exact_commit_execution_claimed': report['identity_after']['exact_commit_execution_claimed'],
        'original_worker_flag_modified': False,
        'post_execution_source_binding_is_independent_supplement': True,
        'clean_head_before_and_after_recorded_by_worker': True,
        'executed_sources_and_inputs_match_candidate_git_blobs': True,
        'source_count': len(records), 'sources': records,
        'external_archived_native_inputs_are_linked_to_exact_git_blob_not_duplicated': True}
    members['SOURCE_BINDING.json'] = encoded(identity)
    summary = {
        'schema': 'razr-completed-finite-KEY-research-evidence-v1',
        'candidate_source_commit': a.candidate,
        'trial': report['trial'],
        'participant_count': report['participant_count'],
        'expected_pair_count': report['expected_pair_count'],
        'persisted_completed_pair_count': report['persisted_completed_pair_count'],
        'all_unordered_pairs_present_once': report['all_unordered_pairs_present_once'],
        'method_counts': report['method_counts'],
        'evaluation_failure_count': len(report['evaluation_failures']),
        'positive_actual_Common': report['positive_actual_Common'],
        'positive_STEP_readbacks': reader['positive_STEP_readbacks'],
        'execution_completed': report['execution_completed'],
        'finite_trial_clear': report['finite_trial_clear'],
        'original_v4_execution_claimed': False,
        'original_worker_exact_commit_execution_claimed': report['identity_after']['exact_commit_execution_claimed'],
        'supplementary_executed_source_binding_to_C2_verified': True,
        'source_binding': 'SOURCE_BINDING.json',
        'independent_reader_passed': reader['passed'],
        'independent_reader_is_independent_process_not_independent_kernel': True,
        'full_pair_journal_readback': reader['journal_readback'],
        'native_material_accounting_executed': reader['candidate_material_readback']['native_material_accounting_executed'],
        'material_part_count': len(reader['candidate_material_readback']['parts']),
        'production_default_changed': False,
        'trial_elapsed_seconds': controllers[0]['elapsed_seconds'],
        'independent_reader_elapsed_seconds': controllers[1]['elapsed_seconds'],
        'trial_peak_sampled_worker_VmHWM_bytes': max(r.get('worker_memory', {}).get('VmHWM', 0) for r in controllers[0]['resource_observations']),
        'trial_peak_shared_unreclaimable_bytes': max(r['shared_unreclaimable_bytes'] for r in controllers[0]['resource_observations']),
        'trial_min_available_disk_bytes': min(r['available_disk_bytes'] for r in controllers[0]['resource_observations']),
        'limits_unchanged': controllers[0]['limits'],
        'continuous_backlash_domain_proved': False,
        'complete_product_motion_proved': False,
        'strength_or_tolerance_qualified': False,
        'physical_qualification': False,
        'candidate_go': False, 'fixture_fabrication_go': False, 'manufacturing_go': False}
    members['SUMMARY.json'] = encoded(summary)
    members['package_evidence.py'] = Path(__file__).read_bytes()
    manifest = {'schema': 'razr-raw-evidence-members-v1', 'members': [
        {'path': n, 'bytes': len(data), 'sha256': digest(data)} for n, data in sorted(members.items())]}
    members['MEMBERS.json'] = encoded(manifest)
    out = a.output/'execution.tar.gz'
    with out.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tf:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            tf.addfile(info, io.BytesIO(data))
    with tarfile.open(out, 'r:gz') as tf:
        assert set(tf.getnames()) == set(members)
        for name, data in members.items():
            assert tf.extractfile(name).read() == data, name
    receipt = {'schema': 'razr-package-receipt-v1', 'file': out.name,
               'bytes': out.stat().st_size, 'sha256': digest(out.read_bytes()),
               'members': len(members), 'member_raw_bytes': sum(map(len, members.values())),
               'all_members_reextracted_and_verified_byte_for_byte': True}
    for name, value in (('SUMMARY.json', summary), ('SOURCE_BINDING.json', identity), ('ARCHIVE_RECEIPT.json', receipt)):
        (a.output/name).write_bytes(encoded(value))
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
