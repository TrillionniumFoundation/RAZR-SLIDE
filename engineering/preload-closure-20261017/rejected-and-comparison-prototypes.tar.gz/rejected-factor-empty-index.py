"""Research optimization: exact active-system solve with verified Cholesky reuse.

No change to Q, equality constraints, tolerances or complementarity checks.
Failure to preserve the active-system residual falls back to the original
complete pivoted solve. This module has no global state or cached physics.
"""
import numpy as np
from scipy.linalg import cholesky,cho_solve,solve_triangular,solve,LinAlgWarning
import warnings

class WorkingFactor:
    def __init__(self):
        self.indices=None;self.L=None
        self.counts={'refactor':0,'append':0,'delete':0,'fallback':0}

    def _factor(self,Q,indices):
        ids=tuple(int(i) for i in indices)
        if self.indices==ids and self.L is not None:return
        old=self.indices;L=self.L;built=None
        if old is not None and L is not None and len(ids)==len(old)+1 and ids[:-1]==old:
            w=solve_triangular(L,Q[np.asarray(old),ids[-1]],lower=True,check_finite=False)
            diag=float(Q[ids[-1],ids[-1]]-w@w)
            if diag>1e-13*max(abs(Q[ids[-1],ids[-1]]),1e-300):
                built=np.zeros((len(ids),len(ids)));built[:-1,:-1]=L;built[-1,:-1]=w;built[-1,-1]=np.sqrt(diag)
                self.counts['append']+=1
        elif old is not None and L is not None and len(ids)==len(old)-1:
            mismatch=next((i for i in range(len(ids)) if ids[i]!=old[i]),len(ids))
            if old[:mismatch]+old[mismatch+1:]==ids:
                U=np.array(np.delete(L.T,mismatch,axis=1),order='C')
                for j in range(mismatch,len(ids)):
                    a,b=U[j,j],U[j+1,j];norm=np.hypot(a,b)
                    if norm==0:raise np.linalg.LinAlgError('singular factor deletion')
                    c,s=a/norm,b/norm;row=U[j,j:].copy();other=U[j+1,j:].copy()
                    U[j,j:]=c*row+s*other;U[j+1,j:]=-s*row+c*other
                built=np.array(U[:-1,:].T,order='F');self.counts['delete']+=1
        if built is None:
            built=cholesky(Q[np.ix_(ids,ids)],lower=True,check_finite=False)
            self.counts['refactor']+=1
        self.indices=ids;self.L=built

    def solve(self,Q,indices,E,p,b,tolerance):
        ix=np.asarray(indices,dtype=int);EF=E[:,ix];rank=len(b)
        A=np.block([[Q[np.ix_(ix,ix)],-EF.T],[EF,np.zeros((rank,rank))]])
        rhs=np.r_[p[ix],b]
        try:
            self._factor(Q,ix)
            dual=cho_solve((self.L,True),np.column_stack([p[ix],EF.T]),check_finite=False)
            x0=dual[:,0];X=dual[:,1:]
            if rank:
                schur=EF@X
                with warnings.catch_warnings():
                    warnings.simplefilter('error',LinAlgWarning)
                    nu=solve((schur+schur.T)/2,b-EF@x0,assume_a='sym',check_finite=False)
            else:nu=np.empty(0)
            result=np.r_[x0+X@nu,nu]
            residual=np.max(abs(A@result-rhs),initial=0.)
            if not np.isfinite(result).all() or residual>tolerance*10*max(np.max(abs(rhs),initial=0.),1.):
                raise np.linalg.LinAlgError('incremental active-system residual')
            return result
        except (np.linalg.LinAlgError,LinAlgWarning,ValueError):
            self.indices=None;self.L=None;self.counts['fallback']+=1
            with warnings.catch_warnings():
                warnings.simplefilter('error',LinAlgWarning)
                return solve(A,rhs,assume_a='gen',check_finite=False)
