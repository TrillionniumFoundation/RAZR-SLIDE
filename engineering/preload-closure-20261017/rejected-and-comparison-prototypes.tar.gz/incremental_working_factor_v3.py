"""Exact active-set factor/RHS updates; residual-checked original-solve fallback.

Used only within one fixed Q,p,E problem. No regularization or stiffness change.
The triangular RHS is updated with the SAME rotations as a factor deletion.
"""
import numpy as np
from scipy.linalg import cholesky,solve_triangular,solve,LinAlgWarning
import warnings

class WorkingFactor:
    def __init__(self):
        self.indices=None;self.L=None;self.T=None
        self.counts={'refactor':0,'append':0,'delete':0,'fallback':0}
    def _factor(self,Q,indices,p,E):
        ids=tuple(int(i) for i in indices)
        if self.indices==ids and self.L is not None:return
        old=self.indices;L=self.L;T=self.T;built=None;newT=None
        if old is not None and L is not None and len(ids)==len(old)+1 and ids[:-1]==old:
            w=solve_triangular(L,Q[np.asarray(old,dtype=int),ids[-1]],lower=True,check_finite=False)
            diag=float(Q[ids[-1],ids[-1]]-w@w)
            if diag>1e-13*max(abs(Q[ids[-1],ids[-1]]),1e-300):
                root=np.sqrt(diag);built=np.zeros((len(ids),len(ids)));built[:-1,:-1]=L;built[-1,:-1]=w;built[-1,-1]=root
                row=(np.r_[p[ids[-1]],E[:,ids[-1]]]-w@T)/root
                newT=np.vstack([T,row]);self.counts['append']+=1
        elif old is not None and L is not None and len(ids)==len(old)-1:
            k=next((i for i in range(len(ids)) if ids[i]!=old[i]),len(ids))
            if old[:k]+old[k+1:]==ids:
                U=np.array(np.delete(L.T,k,axis=1),order='C');W=T.copy()
                for j in range(k,len(ids)):
                    a,b=U[j,j],U[j+1,j];norm=np.hypot(a,b)
                    if norm==0:raise np.linalg.LinAlgError('singular factor deletion')
                    c,s=a/norm,b/norm;row=U[j,j:].copy();other=U[j+1,j:].copy()
                    U[j,j:]=c*row+s*other;U[j+1,j:]=-s*row+c*other
                    row=W[j].copy();other=W[j+1].copy();W[j]=c*row+s*other;W[j+1]=-s*row+c*other
                built=np.array(U[:-1,:].T,order='F');newT=W[:-1].copy();self.counts['delete']+=1
        if built is None:
            built=cholesky(Q[np.ix_(ids,ids)],lower=True,check_finite=False)
            newT=solve_triangular(built,np.column_stack([p[list(ids)],E[:,list(ids)].T]),lower=True,check_finite=False)
            self.counts['refactor']+=1
        self.indices=ids;self.L=built;self.T=newT
    def solve(self,Q,indices,E,p,b,tolerance,A,rhs):
        try:
            self._factor(Q,indices,p,E);t=self.T[:,0];W=self.T[:,1:]
            if len(b):
                schur=W.T@W
                with warnings.catch_warnings():
                    warnings.simplefilter('error',LinAlgWarning)
                    nu=solve(schur,b-W.T@t,assume_a='sym',check_finite=False)
            else:nu=np.empty(0)
            x=solve_triangular(self.L.T,t+W@nu,lower=False,check_finite=False)
            result=np.r_[x,nu]
            if not np.isfinite(result).all() or np.max(abs(A@result-rhs),initial=0.)>tolerance*10*max(np.max(abs(rhs),initial=0.),1.):
                raise np.linalg.LinAlgError('updated active-system residual')
            return result
        except (np.linalg.LinAlgError,LinAlgWarning,ValueError):
            self.indices=None;self.L=None;self.T=None;self.counts['fallback']+=1
            with warnings.catch_warnings():
                warnings.simplefilter('error',LinAlgWarning)
                return solve(A,rhs,assume_a='gen',check_finite=False)
