"""Actual frozen body meshes: four-child internal refinement, fixed case6 forces.

Reequilibrates each ELASTIC BODY under unchanged applied nodal forces. It does
not re-solve contact/springs on the refined operator. Faces and geometry stay
unchanged. This is a nested interior-energy sensitivity, not complete mesh
convergence and not a new accepted coupled solution.
"""
from pathlib import Path
import sys,argparse,json,hashlib,time,gc
import numpy as np
from scipy.sparse import coo_matrix,load_npz,save_npz
from scipy.sparse.linalg import splu
from skfem import MeshTet,Basis,ElementVector,ElementTetP2,asm
from skfem.models.elasticity import lame_parameters,linear_elasticity
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'integration'))
import tetra_star_refinement as star
from contact_exchange import sha256

def dump(path,data):path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--body',choices=['panel','frame'],required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 out=a.output.resolve();assert not out.exists();out.mkdir(parents=True)
 src=a.inputs/a.body;reg=ROOT/'engineering/spatial-contact-integration-20261015'/f'{a.body}-elastic-input.json';registered=json.loads(reg.read_text())
 for n,key in [('K.npz','K_sha256'),('loads.npz','loads_sha256'),('mesh.npz','mesh_sha256')]:assert sha256(src/n)==registered[key]
 hashes={str(src/n):sha256(src/n) for n in ('K.npz','loads.npz','mesh.npz')}
 fp=ROOT/'engineering/preload-closure-20261017/case-6/full-fields.npz';hashes[str(fp)]=sha256(fp)
 data=np.load(src/'mesh.npz',allow_pickle=False);mesh=MeshTet(data['points'].T,data['tetra'].T)
 basis=Basis(mesh,ElementVector(ElementTetP2()),intorder=4)
 ld=np.load(src/'loads.npz',allow_pickle=False);assert np.array_equal(basis.doflocs,ld['xyz'])
 fields=np.load(fp,allow_pickle=False);force=fields['load_'+a.body];assert force.shape==(basis.N,)
 boundary=basis.get_dofs(facets=mesh.boundary_facets()).all();interior=np.setdiff1d(np.arange(basis.N),boundary)
 outside_force=float(np.max(abs(force[interior]),initial=0.));assert outside_force<1e-12*max(float(np.max(abs(force))),1e-30)
 # Exact zero load on new interior nodes extends the same boundary linear functional.
 ids=basis.element_dofs.T;v=mesh.p.T[mesh.t.T];n=len(v);N=basis.N
 val0=np.lib.format.open_memmap(out/'coarse-values.npy',mode='w+',dtype=float,shape=(n,30,30));val1=np.lib.format.open_memmap(out/'star-values.npy',mode='w+',dtype=float,shape=(n,30,30))
 tic=time.monotonic();embederr=0.;T=star.parent_interpolation()
 for i in range(0,n,128):
  vv=v[i:i+128];a0=star.element_stiffness(vv);a1,recovery,full=star.star_stiffness(vv,return_recovery=True)
  err=float(np.max(abs(np.einsum('ai,nab,bj->nij',T,full,T)-a0)));embederr=max(embederr,err)
  assert err<=1e-9*max(float(np.max(abs(a0))),1.)
  val0[i:i+128]=a0;val1[i:i+128]=a1
  if i%8192==0:print('ASSEMBLING',a.body,i,n,time.monotonic()-tic,flush=True)
 val0.flush();val1.flush()
 rows=np.repeat(ids,30,axis=1).ravel().astype(np.int32);cols=np.tile(ids,(1,30)).ravel().astype(np.int32)
 K0=coo_matrix((np.asarray(val0).ravel(),(rows,cols)),shape=(N,N)).tocsc()
 old=load_npz(src/'K.npz').tocsc();delta=K0-old;rel=float(np.max(abs(delta.data),initial=0.))/max(float(np.max(abs(old.data))),1e-30);assert rel<1e-10
 del delta,old;gc.collect()
 K1=coo_matrix((np.asarray(val1).ravel(),(rows,cols)),shape=(N,N)).tocsc();del rows,cols;gc.collect()
 save_npz(out/'Kstar-condensed.npz',K1,compressed=False)
 print('CONDENSED_READY',a.body,N,n,'COARSE_K_ERROR',rel,flush=True)
 D=ld['D'];free=np.setdiff1d(np.arange(N),D);solutions=[];stats=[]
 for label,K in [('original',K0),('interior_star',K1)]:
  tick=time.monotonic();fac=splu(K[free][:,free],permc_spec='MMD_AT_PLUS_A',diag_pivot_thresh=0.,options={'SymmetricMode':True})
  u=np.zeros(N);u[free]=fac.solve(force[free]);res=K@u-force
  e=float(u@(K@u));w=float(u@force);err=abs(e-w)/max(abs(e),abs(w),1e-30)
  assert err<1e-5 and np.max(abs(res[free]))<1e-9
  if a.body=='panel':assert np.max(abs(res[D]))<1e-9
  stats.append({'label':label,'compliance_work':w,'strain_energy':e/2,'work_relative_error':err,'free_residual_max':float(np.max(abs(res[free]))),'gauge_or_fixture_reaction_max':float(np.max(abs(res[D]))),'seconds':time.monotonic()-tick})
  solutions.append(u);del fac;gc.collect();print('BODY_SOLVED',a.body,stats[-1],flush=True)
 u0,u1=solutions;extra=np.empty((n,15));energy_recovered=0.;resint=0.;rigid=fields['rigid']
 for i in range(0,n,128):
  k,rec,full=star.star_stiffness(v[i:i+128],return_recovery=True);ub=u1[ids[i:i+128]];ui=np.einsum('nij,nj->ni',rec,ub);z=np.concatenate([ub,ui],axis=1)
  extra[i:i+128]=ui;rz=np.einsum('nij,nj->ni',full,z);resint=max(resint,float(np.max(abs(rz[:,30:]))));energy_recovered+=float(np.einsum('ni,ni->',z,rz)/2)
 assert resint<1e-9 and abs(energy_recovered-stats[1]['strain_energy'])/max(abs(energy_recovered),1e-30)<1e-5
 # Restore exactly the OLD rigid field only for inspecting what the fixed-force
 # trial does to contact; it is not a newly solved contact rigid equilibrium.
 if a.body=='panel':
  shift=ld['R']@rigid;u0=u0+shift;u1=u1+shift
 np.savez_compressed(out/'body-fields.npz',u_original=u0,u_star=u1,new_internal_dofs=extra,force=force,D=D)
 increase=(stats[1]['compliance_work']-stats[0]['compliance_work'])/abs(stats[0]['compliance_work']);assert increase>=-1e-7
 # Independent library assembly for a complete four-child physical tetrahedron.
 check=[];la,mu=lame_parameters(1.,.3)
 for ix in np.linspace(0,n-1,8,dtype=int):
  vv=v[ix];xyz=np.vstack([vv,vv.mean(axis=0)]);tt=star.CHILD_VERTICES.copy();tt[tt==10]=4
  mm=MeshTet(xyz.T,tt.T);bb=Basis(mm,ElementVector(ElementTetP2()),intorder=4);kk=asm(linear_elasticity(la,mu),bb).toarray();ax=bb.split_indices();coords=bb.doflocs[:,ax[0]].T
  _,rec,k=star.star_stiffness(vv,return_recovery=True);J=(vv[1:]-vv[0]).T;target=vv[0]+star.STAR_NODES@J.T
  nearest=np.argmin(np.max(abs(target[:,None,:]-coords[None,:,:]),axis=2),axis=1)
  assert len(set(nearest))==15
  perm=np.column_stack([axis[nearest] for axis in ax]).ravel();err=float(np.max(abs(kk[np.ix_(perm,perm)]-k)))/max(float(np.max(abs(k))),1e-30);assert err<1e-10;check.append({'parent':int(ix),'independent_relative_error':err})
 report={'body':a.body,'source_sha256':sha256(__file__),'core_sha256':sha256(ROOT/'integration/tetra_star_refinement.py'),'input_sha256':hashes,'parent_tetrahedra':n,'refined_child_tetrahedra':4*n,'original_retained_DOFs':N,'new_interior_DOFs':15*n,'represented_full_refined_DOFs':N+15*n,'exact_static_condensation':True,'original_boundary_P2_traces_unchanged':True,'global_h_convergence':False,'contact_and_bolt_forces_frozen_from_case':6,'coupled_contact_reequilibrated':False,'force_off_boundary_max':outside_force,'coarse_K_relative_error_to_frozen':rel,'nested_energy_embedding_absolute_error_max':embederr,'full_internal_residual_max':resint,'independent_child_matrix_checks':check,'solutions':stats,'relative_compliance_increase':increase,'recovered_strain_energy':energy_recovered,'fields_sha256':sha256(out/'body-fields.npz'),'condensed_K_sha256':sha256(out/'Kstar-condensed.npz'),'passed_scope':'exact interior refinement and two fixed-force body solutions; not a refined contact solution','passed':True,'candidate_go':False,'fixture_fabrication_go':False,'manufacturing_go':False}
 for f,h in hashes.items():assert sha256(f)==h
 dump(out/'report.json',report);print('BODY_TERMINAL',a.body,'INCREASE',increase,'FULL_DOF',N+15*n,flush=True)
if __name__=='__main__':main()
