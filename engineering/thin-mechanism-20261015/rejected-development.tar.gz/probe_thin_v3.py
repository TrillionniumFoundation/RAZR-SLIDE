from pathlib import Path
import sys,json,itertools,time
R=Path('/home/qian-qi/RAZR-SLIDE-thin-20261015');sys.path.insert(0,str(R/'integration'))
import cover_capture as c
n=c.n
side='L';old=c.build(side)[1];new=dict(old);rows=[]
def box(*b):return n.box(side,*b)
def cyl(rad,length,e,q,r):return n.single(n.cq.Solid.makeCylinder(rad,length,n.world(side,e,q,r),n.cq.Vector(0,0,1)))
def fuse(parts):return n.fuse(parts)
def crop(body,a,b):return body.intersect(box(a,b,-40,40,-40,40)).clean()
# Fixed declared redesign stock planes, never pose-dependent cutting.
for name in c.ROOT_NAMES: new[name]=crop(c.baseline(side)[name],-3.5,3.1)
for i in (0,1):new['CAP_'+str(i)]=crop(old['CAP_'+str(i)],-3.5,3.1)
new['OLD_COVER']=crop(old['OLD_COVER'],-3.5,2.77)
for i in (0,1):
 off=5*i;ec=2.2;qc=(16.5,10.5)[i];sc=(19.,22.)[i]
 seat=fuse([box(.25,2.5,1.26,1.38,2.64+off,2.94+off),box(2.2,2.5,1.3,qc+.15,2.64+off,2.94+off),cyl(.55,.3,ec,qc,2.64+off)])
 new['STOP_'+str(i)]=fuse([crop(old['STOP_'+str(i)],-1,.4),seat])
 guide=cyl(.8,3.,ec,qc,1.4+off).cut(cyl(.6,3.1,ec,qc,1.35+off)).cut(box(ec-.31,ec+.31,qc-1,qc,1.35+off,3.21+off)).clean()
 new['SPRING_GUIDE_'+str(i)]=n.single(guide)
 new[f'SPRING_{i}_OD_TOL_ENVELOPE']=cyl(.43,1.46,ec,qc,2.94+off)
 cap=box(1.3,3.1,qc-.8,sc+.9,4.4+off,4.7+off).cut(cyl(.55,.7,ec,sc,4.3+off)).clean();new['SPRING_CAP_'+str(i)]=n.single(cap)
 new[f'SPRING_SCREW_{i}_M1x3_NOMINAL']=fuse([cyl(.5,3.,ec,sc,1.7+off),cyl(.9,.45,ec,sc,4.7+off)])
 post=box(1.7,2.7,sc-.5,sc+.5,-11.06,4.4+off).cut(cyl(.5,3.,ec,sc,1.7+off)).clean()
 tie=box(.7,3.05,2.98,sc+.5,-11.06,-10.76)
 support=box(2.8,3.05,qc-.8,qc+.8,-11.06,1.4+off)
 bed=box(1.3,3.1,qc-.8,qc+.8,1.1+off,1.4+off)
 try:new[c.ROOT_NAMES[1]]=fuse([new[c.ROOT_NAMES[1]],post,tie,support,bed])
 except Exception as e:
  print('ROOT_FUSE_FAIL',i,str(e),flush=True);raise
for name,(ea,eb,pa,pb) in {c.ROOT_NAMES[0]:(-3.5,-2.2,-3.5,-3.25),c.ROOT_NAMES[1]:(2.2,3.1,2.87,3.1)}.items():
 ch=fuse([box(ea,eb,6.5,7.,-6.34,-6.04),box(pa,pb,6.5,7.,-7.64,-6.04),box(ea,eb,6.5,7.,-7.64,-7.26)])
 if name==c.ROOT_NAMES[1]:ch=fuse([ch,box(2.87,3.1,6.5,7.,-11.06,-7.26)])
 print('CHANNEL_JOINT',name,n.common(new[name],ch),flush=True);new[name]=fuse([new[name],ch])
for name,shape in new.items():
 try:n.single(shape)
 except Exception as e:print('INVALID',name,len(shape.Solids()),shape.isValid(),str(e),flush=True)
 print('PART',name,n.bounds(side,shape),flush=True)
for a,b in itertools.combinations(new,2):
 try:
  v=n.common(new[a],new[b])
  if v>1e-7:rows.append({'pair':[a,b],'common':v});print('COLLISION',a,b,v,flush=True)
 except Exception as e: print('COMMON_FAIL',a,b,str(e),flush=True)
for i in (0,1):
 stop=new['STOP_'+str(i)]
 parked=new['PAWL'].translate((-1.1,0,0))
 for shift in (0,-.58,-1.16):
  v=n.common(stop.translate((0,0,shift)),parked);print('STOP_PARKED',i,shift,v,flush=True)
Path('/tmp/razr-slide-thin-20261015/probe-v3.json').write_text(json.dumps(rows,indent=2))

for name in c.ROOT_NAMES:
 print('CAPTURE',name,'nominal',n.common(new['OLD_COVER'],new[name]),'uplift.12',n.common(new['OLD_COVER'].translate((0,0,.12)),new[name]),flush=True)
