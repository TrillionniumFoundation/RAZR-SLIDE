from pathlib import Path
import sys,json,itertools,time
R=Path('/home/qian-qi/RAZR-SLIDE-thin-20261015');sys.path.insert(0,str(R/'integration'))
import thin_mechanism as t
n=t.n
from translation_regions import regions,checks
side='L';new=t.scene(side);report={'source_sha256':t.sha(t.__file__),'motion':[],'assembly':[]}
# Validate all participants before geometry shortcuts.
for body in new.values():n.single(body)

def test(name,moving,vec,fixed):
 rr=None if name.startswith('ROOT_') else regions(moving,vec)[0];bad=[]
 for key,shape in fixed.items():
  rec=checks(regions(shape,tuple(-v for v in vec))[0],moving) if rr is None else checks(rr,shape)
  if not rec['all_regions_clear']:bad.append({'fixed':key,**rec})
 print(name,'PAIRS',len(fixed),'BAD',[(b['fixed'],max(b['region_common_mm3'])) for b in bad],flush=True)
 return {'name':name,'pairs':len(fixed),'bad':bad}

fixed={k:v for k,v in new.items() if k not in ('PAWL','KEY','STOP_0','STOP_1','SPRING_0_OD_TOL_ENVELOPE','SPRING_1_OD_TOL_ENVELOPE')}
fixed['PARKED_PAWL']=t.parked(side,new['PAWL'])
for i in (0,1):report['motion'].append(test('STOP'+str(i),new['STOP_'+str(i)],(0,0,-1.16),fixed))
report['motion'].append(test('KEY',new['KEY'],(0,-12,0),fixed))
report['motion'].append(test('PAWL',new['PAWL'],(-1.1,0,0),{k:v for k,v in new.items() if k not in ('PAWL',)}))
# Declared bench sequence only; fixed upper STOP preload is an unqualified fixture assumption.
parts=dict(new);parts['PARKED_PAWL']=t.parked(side,new['PAWL'])
parts['JAW_LOWER']=t.box(side,-.8,.8,12.15,12.55,-3.4,-2.9)
parts['JAW_UPPER']=t.box(side,-.8,.8,12.15,12.55,-2.5,-2.)
installed={'JAW_LOWER':parts['JAW_LOWER']}
stages=[('OLD_COVER',(0,0,5)),('JAW_UPPER',(0,0,3)),('ROOT_INNER',(10,0,0)),('PARKED_PAWL',(0,0,-25)),('STOP_0',(-10,0,0)),('STOP_1',(-10,0,0)),('ROOT_OUTER_CONNECTED_ALL_FRAGMENTS',(-10,0,0)),('ROOT_JOIN_SCREW_0_M1x3_NOMINAL',(-10,0,0)),('ROOT_JOIN_SCREW_1_M1x3_NOMINAL',(-10,0,0))]
for i in (0,1):
 stages.extend([(f'CAP_{i}',(-10,0,0)),(f'SCREW_{i}_0',(0,0,25)),(f'SCREW_{i}_1',(0,0,25))])
for i in (0,1):
 stages.extend([(f'SPRING_GUIDE_{i}',(0,0,25)),(f'SPRING_{i}_OD_TOL_ENVELOPE',(0,0,25)),(f'SPRING_CAP_{i}',(0,0,25)),(f'SPRING_SCREW_{i}_M1x3_NOMINAL',(0,0,25))])
for name,vec in stages:
 report['assembly'].append(test(name,parts[name],vec,installed));installed[name]=parts[name]
 Path('/tmp/razr-slide-thin-20261015/motion-install-v4.json').write_text(json.dumps(report,indent=2))
print('COMPLETE',flush=True)
