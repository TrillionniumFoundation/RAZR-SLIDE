from pathlib import Path
import sys,types
r=Path('/home/qian-qi/RAZR-SLIDE-thin-20261015');sys.path.insert(0,str(r/'integration'))
p=r/'integration/thin_mechanism.py';s=p.read_text()
a='    new[ROOT_NAMES[1]]=n.fuse([opened,*bypass])'
b='''    assembled=opened
    for part in bypass:assembled=assembled.fuse(part)
    assembled=assembled.clean()
    print('OPENED_FRAGMENTS',[(body.Volume(),n.bounds(side,body)) for body in n.whole_material(opened)[0]],flush=True)
    print('JOINED_FRAGMENTS',[(body.Volume(),n.bounds(side,body)) for body in n.whole_material(assembled)[0]],flush=True)
    n.cq.exporters.export(assembled,'/tmp/razr-slide-thin-20261015/root-fragments-v6.step')
    raise SystemExit(0)'''
assert a in s;mod=types.ModuleType('diagnostic_thin');mod.__file__=str(p);exec(compile(s.replace(a,b,1),str(p),'exec'),mod.__dict__);mod.design('L')
